

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Meeting Detail</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">

                <?php if($meeting_detail[0]['host_id'] == session('user_session')): ?>
                    <?php if($meeting_detail[0]['meeting_status'] == '1'): ?>
                        <div class="m-0">
                            <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#add-user-meeting">											
                                <span class="svg-icon svg-icon-2">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                        <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                                    </svg>
                                </span>
                                Add New User</a>   
                        </div>
                    <?php endif; ?>
                    
                    <?php if($meeting_detail[0]['meeting_status'] == '2' || $meeting_detail[0]['meeting_status'] == '3'): ?>
                        <div class="m-0">
                            <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#re-schedule-meeting">											
                                <span class="svg-icon svg-icon-2">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                        <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                                    </svg>
                                </span>
                                Re-Schedule Meeting</a>   
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="m-0">
                     <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
                </div>
         
            </div>
           
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
      
        <div id="kt_app_content_container" class="app-container">
          
            <div class="row">
                <div class="col-md-4 card mb-5">
                    <div class="card-body p-5">
                        
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Meeting Time</span>
                                    </div>
                                    
                                    
                                    <span class="fs-6"> 
                                            <?php if(!empty($meeting_detail[0]['meeting_time'])): ?>
                                            <?php echo e($meeting_detail[0]['meeting_time']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                    </span>
                               
                                    
                                </div>
                                
                         </div>
                        
                        
                         <div class="separator separator-dashed my-4"></div>
                        
                         
                         <div class="d-flex flex-stack">
                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                 <div class="flex-grow-1 me-2">
                                     <span class="text-gray-800  fs-6 fw-bold">Meeting Host</span>
                                 </div>

                                    <?php echo CustomHelper::getEmpProfileDiv($meeting_detail[0]['host_id']); ?>

                               
                             </div>
                            
                         </div>
                        
                        
                         <div class="separator separator-dashed my-4"></div>
                        
     
                         
                        <div class="d-flex flex-stack">
                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                 <div class="flex-grow-1 me-2">
                                     <span class="text-gray-800  fs-6 fw-bold">Created At</span>
                                 </div>
                                
                                
                                <span class="fs-6"><?php echo e(date('d, F Y h:i A', strtotime($meeting_detail[0]['meeting_created_at']))); ?></span>
                               
                                
                             </div>
                            
                        </div>
                        
                        
                         <div class="separator separator-dashed my-4"></div>
                        
                         
                         <div class="d-flex flex-stack">
                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                 <div class="flex-grow-1 me-2">
                                     <span class="text-gray-800  fs-6 fw-bold">Meeting Total Employees</span>
                                 </div>
                                
                                
                                <span class="fs-6">
                                        <?php if(!empty($meeting_users)): ?>
                                            <?php echo e(count($meeting_users)); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                </span>
                               
                                
                             </div>
                            
                         </div>
                        
                        
                         <div class="separator separator-dashed my-4"></div>
                        
                         

                         <?php if(!empty($meeting_users)): ?>	
                            <?php $key = 0; 
                            $chat_members = [$meeting_detail[0]['host_id']];
                            ?>
                            <?php $__currentLoopData = $meeting_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex flex-stack">
                                    <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                        <div class="flex-grow-1 me-2">
                                            <span class="text-gray-800  fs-6 fw-bold">User <?php echo e(++$key); ?></span>
                                        </div>
                                        
                                    
                                    
                                    <?php echo CustomHelper::getEmpProfileDiv($meeting_user['user_id']); ?>

                                    
                                    
                                    
                                    </div>
                                
                                </div>
                                <div class="separator separator-dashed my-4"></div>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?> 
                            
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card card-flush mb-10">
                        <div class="card-body">
                            <div class="row g-9">
                                <label class="text-dark fw-bold">Meeting Title </label> 
                                <p>
                                    <?php if(!empty($meeting_detail[0]['meeting_title']) && $meeting_detail[0]['meeting_title'] != ''): ?>
                                        <?php echo e($meeting_detail[0]['meeting_title']); ?>

                                    <?php else: ?>
                                        Meeting title is not available.
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="card card-flush mb-10">
                        <div class="card-body">
                            <div class="row g-9">
                                
                                    <label class="text-dark fw-bold"> Meeting Description </label> 
                                    <p>
                                       <?php if(!empty($meeting_detail[0]['meeting_description']) && $meeting_detail[0]['meeting_description'] != ''): ?>
                                            <?php echo e($meeting_detail[0]['meeting_description']); ?>

                                        <?php else: ?>
                                            Meeting description is not available.
                                        <?php endif; ?>
                                    </p>
                                
                            </div>
                        </div>
                    </div>


                    <div class="flex-lg-row-fluid card card-flush mb-10">
                            
                        <div class="card direct-chat direct-chat-primary">
                                        
                            <div class="card-header" id="kt_chat_messenger_header">
                                
                                <div class="card-title">
                                    
                                    <div class="d-flex justify-content-center flex-column me-3">
                                        <p class="fs-4 fw-bold text-gray-900 me-1 mb-2 lh-1">Meeting Chat</p>
                                        
                                    </div>
                                    
                                </div>
                                
                                
                            </div>
                            
                            
                            <div class="card-body" id="kt_chat_messenger_body">
                                
                                <div class="scroll-y me-n5 pe-5 h-300px h-lg-auto " data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-max-height="auto" data-kt-scroll-dependencies="#kt_header, #kt_app_header, #kt_app_toolbar, #kt_toolbar, #kt_footer, #kt_app_footer, #kt_chat_messenger_header, #kt_chat_messenger_footer" data-kt-scroll-wrappers="#kt_content, #kt_app_content, #kt_chat_messenger_body" data-kt-scroll-offset="5px" style="max-height: 151px;" id="chat-message">
                                    <!--begin::Message(in)-->
                                    <div class="direct-chat-messages">

                                    </div>
                        
                                </div>  
                            </div>
                            
                                    
                            <div class="card-footer pt-4" >
                                <form id="sendChatMessage">
                                    
                                    
                                    <input type="hidden" name="meeting_id" value="<?php echo e(Request::segment(2)); ?>">
                                    <?php if($meeting_detail[0]['meeting_status'] == '1'): ?>
                                        <div class="input-group">
                                            <input type="hidden" id="fileHolder" name="chat_file" >
                                            <textarea class="form-control form-control-flush mb-3" id="messageInputBox"  name="message" rows="1" data-kt-element="input" placeholder="Type a message"></textarea>
                                            
                                            
                                            <div class="d-flex flex-stack">
                                                <button type="submit" id="sendMessageBtn"class="btn btn-primary">
                                                    <span class="indicator-label">Submit</span>
                                                    <span class="indicator-progress">Please wait... 
                                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                                </button>
                                                
                                                
                                            </div>
                                        </div>  
                                    <?php endif; ?>
                                    
                                </form>    
                            </div>
                                    
                        </div>
                                
                    </div>
                </div>
            </div>
          
        </div>
    </div>


    
    <div class="modal fade" id="add-user-meeting" tabindex="-1" aria-hidden="true">
        
        <div class="modal-dialog modal-dialog-top mw-600px">
            
            <div class="modal-content rounded">
                
                <div class="modal-content rounded">
                    
                    <div class="modal-header">
                    <h4 class="modal-title pl-4">Add New User</h4>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                    </div>
                    
                </div>
                
                
                <div class="modal-body scroll-y pt-0 pb-15">
                    
                    <form id="update_schedule_meeting_form" class="form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="update_meeting_id" value="<?php echo e($meeting_detail[0]['meeting_id']); ?>"/>
                        
                        <div class="row g-9 mb-8 mt-1" >
                            <div class="col-md-12 fv-row">
                                <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                  <span class="required">Meeting With</span>
                                </label>
                               
                                <div class="position-relative d-flex align-items-center mb-2">
                                    <select class="form-select myselect2" data-control="select2" multiple="multiple" data-close-on-select="false" data-hide-search="false" data-placeholder="Select Employees For Meeting Invitation" name="meeting_users[]" required=""> 
                                        <?php if(!empty($active_employees)): ?>
                                            <?php $__currentLoopData = $active_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $active_employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(in_array($active_employee['employee_id'],$users_id)): ?>
                                                    <?php if($active_employee['employee_id'] != session('user_session')): ?>
                                                        <option value="<?php echo e($active_employee['employee_id']); ?>" selected><?php echo e($active_employee['employee_code']); ?> - <?php echo e($active_employee['employee_name']); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($active_employee['employee_id'] != session('user_session')): ?>
                                                        <option value="<?php echo e($active_employee['employee_id']); ?>"><?php echo e($active_employee['employee_code']); ?> - <?php echo e($active_employee['employee_name']); ?></option>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                               
                            </div>
                        </div>
                       
                        
                        <div class="text-center">
                        
                            <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="new_user_submit_btn" class="btn btn-primary">
                                <span class="indicator-label">Submit</span>
                                <span class="indicator-progress">Please wait... 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                        
                    </form>
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
    

     
    <form id="re_schedule_meeting_form" class="form">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="re-schedule-meeting" tabindex="-1" aria-hidden="true">
            
            <div class="modal-dialog modal-dialog-scrollable mw-800px">
                
                <div class="modal-content rounded">
                    
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Re-Schedule a meeting</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                        </button>
                    </div>
                    
                    
                    <div class="modal-body scroll-y pt-0 pb-15">
                        
                        <div class="row g-9 mb-8 mt-2">
                            <div class="col-md-12 fv-row">
                                <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                <span class="required">Meeting Type</span>
                                </label>

                                <div class="position-relative d-flex align-items-center">
                                    <select class="form-select myselect2" data-control="select2" data-hide-search="false" data-placeholder="Select Meeting Type" id="meeting_type" name="meeting_type" required=""> 
                                        <option value="">Select Meeting Type</option>
                                        <option value="Online" <?php if($meeting_detail[0]['meeting_type'] == 'Online'): ?> selected <?php endif; ?>>Online Meeting</option>
                                        <option value="Physical" <?php if($meeting_detail[0]['meeting_type'] == 'Physical'): ?> selected <?php endif; ?>>Physical Meeting</option>
                                        
                                            
                                    </select>
                                </div>
                            
                            </div>
                        </div>
                        <div class="row g-9 mb-8 child-div-meeting-type" >
                            
                            <div class="col-md-6 fv-row">
                                
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required" id="label-meeting-room">Room No/Location</span>
                                </label>

                                <div class="position-relative d-flex align-items-center">
                                    <input type="text" class="form-control" id="meeting_room" name="meeting_room" required="required" placeholder="Meeting Room/Location" value="<?php echo e($meeting_detail[0]['meeting_room'] ?? ''); ?>">
                                </div>

                            </div>
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                    <span class="required" id="label-meeting-link">Meeting Link</span>
                                </label>
                                <div class="position-relative d-flex align-items-center">
                                    <input type="url" class="form-control" id="meeting_link" name="meeting_link" required="required" placeholder="Meeting Link" value="<?php echo e($meeting_detail[0]['meeting_link'] ?? ''); ?>">
                                </div>
                                
                                
                            </div>
                        </div>
                        <div class="row g-9 mb-8" >
                            
                            <div class="col-md-6 fv-row">
                                
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Meeting Title</span>
                                </label>

                                <div class="position-relative d-flex align-items-center">
                                    <input type="text" class="form-control" name="meeting_title" required="required" placeholder="For eg : Policy Planning" value="<?php echo e($meeting_detail[0]['meeting_title']); ?>">
                                </div>

                            </div>
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                    <span class="required">Meeting With</span>
                                </label>

                                <div class="position-relative d-flex align-items-center">
                                    <select class="form-select myselect2" data-control="select2" multiple="multiple" data-hide-search="false" data-close-on-select="false" data-placeholder="Select Employees For Meeting Invitation" name="meeting_users[]" required=""> 
                                        <?php if(!empty($active_employees)): ?>
                                            <?php $__currentLoopData = $active_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $active_employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(in_array($active_employee['employee_id'],$users_id)): ?>
                                                    <?php if($active_employee['employee_id'] != session('user_session')): ?>
                                                        <option value="<?php echo e($active_employee['employee_id']); ?>" selected><?php echo e($active_employee['employee_name']); ?> - <?php echo e($active_employee['employee_code']); ?></option>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($active_employee['employee_id'] != session('user_session')): ?>
                                                        <option value="<?php echo e($active_employee['employee_id']); ?>"><?php echo e($active_employee['employee_name']); ?> - <?php echo e($active_employee['employee_code']); ?></option>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                
                            </div>
                        </div>
                        <div class="row g-9 mb-8" >
                            <div class="col-md-12 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span>Meeting Description</span>
                                </label>
                                    <textarea class="form-control " rows="6" placeholder="Enter Meeting Description" name="meeting_description"><?php echo e($meeting_detail[0]['meeting_description'] ?? ''); ?></textarea>
                            </div>
                        </div>
                        <div class="row g-9 mb-8" >
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Meeting Date</span>
                                </label>
                            
                                <input type="date" class="form-control " name="meeting_date" min="<?php echo e(date('Y-m-d')); ?>"  required/>
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Meeting Time</span>
                                </label>
                            
                                <input type="time" class="form-control " name="meeting_time" required/>
                            </div>
                        </div>   
                            
                    </div>
                    
                    
                    <div class="modal-footer justify-content-center">
                    
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="re_schedule_submit_btn" class="btn btn-primary">
                            <span class="indicator-label">Submit</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                    
                </div>
                
            </div>
            
        </div>  
        
    </form>
    
</div>
    


<?php $__env->stopSection(); ?>


<?php $__env->startPush('js-link'); ?>
<script>
   var meeting_id = '<?php echo e(Request::segment(2)); ?>';
</script>
<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-database.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/firebase-meeting-chat.js"></script>

<script>
    $(function(){
		$('#meeting_type').trigger('change');
	});
    $('#meeting_type').change(function(){
        var meeting_type =  $('#meeting_type').find(":selected").val();
        
        $('.child-div-meeting-type').removeClass('d-none')
        
        if(meeting_type == 'Online'){
            $('#label-meeting-room').removeClass('required');
            $('#label-meeting-link').addClass('required');
            $('#meeting_room').prop('required',false);
            $('#meeting_link').prop('required',true);

        }else{
        $('#label-meeting-link').removeClass('required');
        $('#label-meeting-room').addClass('required');
        $('#meeting_link').prop('required',false);
        $('#meeting_room').prop('required',true);

        }
    })
    $('#re_schedule_meeting_form').submit(function(e) {
        $('#re_schedule_submit_btn').prop('disabled', true);
        $('#re_schedule_submit_btn').attr('data-kt-indicator', 'on');
        $('#re_schedule_submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('schedule_meeting')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#re_schedule_submit_btn').prop('disabled', false);
                    $('#re_schedule_submit_btn').removeAttr('data-kt-indicator');
                    $('#re_schedule_submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#re_schedule_submit_btn').prop('disabled', false);
                $('#re_schedule_submit_btn').removeAttr('data-kt-indicator');
                $('#re_schedule_submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });

    $('#update_schedule_meeting_form').submit(function(e) {
        $('#new_user_submit_btn').prop('disabled', true);
        $('#new_user_submit_btn').attr('data-kt-indicator', 'on');
        $('#new_user_submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('add_another_user_schedule_meeting')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 3000,
                    })
                    $('#new_user_submit_btn').prop('disabled', false);
                    $('#new_user_submit_btn').removeAttr('data-kt-indicator');
                    $('#new_user_submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#new_user_submit_btn').prop('disabled', false);
                $('#new_user_submit_btn').removeAttr('data-kt-indicator');
                $('#new_user_submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/meeting/meeting-detail.blade.php ENDPATH**/ ?>