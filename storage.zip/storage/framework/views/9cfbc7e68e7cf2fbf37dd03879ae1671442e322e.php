

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
						 
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
    
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">All Employee Resignation</h1>   
            </div>

            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department'] == 2): ?>
                    <div class="m-0">   
                        <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#rejectresignation" >
                            <span class="svg-icon svg-icon-2">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                    <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                                </svg>
                            </span>
                            Reject Resignation
                        </a>
                    </div>
                <?php endif; ?>
                    
            </div>   
        </div>
    </div>
       
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">
            
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                   
                </div> 
                <div class="card-body ">
                    							
                    <div class="table-responsive popup-visible ">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer table-row-bordered"><div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer" id="system_datatable" aria-describedby="tableEmployee_info">
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4">Employee Name</th>
                                        <th>Start Date</th>
                                        <th>End Date</th>
                                        <th>Total Day(s)</th>
                                        <th>Description</th>
                                        <th data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Response By Junior Manager">Response (JM)</th>
                                        <th data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Response By Senior Manager">Response (SM)</th>
                                        <th data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Response By HR">Response (HR)</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($all_resignations)): ?>
                                        <?php $__currentLoopData = $all_resignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_resignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-6"><?php echo CustomHelper::getEmpProfileDiv($all_resignation['resignation_employee']); ?></td>
                                                
                                                <td><?php echo e($all_resignation['resignation_from_date']); ?></td>
                                                <td><?php echo e($all_resignation['resignation_to_date']); ?></td>
                                                <td class="ps-10">
                                                    <?php
                                                        $startDate = new DateTime($all_resignation['resignation_from_date']); 
                                                        $endDate = new DateTime($all_resignation['resignation_to_date']);
                                                        
                                                        $total_days = $endDate->diff($startDate)->format("%a");
                                                        echo $total_days+1;
                                                         
                                                    ?>
                                                </td>
                                                <td class="ps-8">
                                                    <a href="javascript:void(0);" class="message_btn" data-bs-toggle="modal" data-bs-target="#message_modal" data-message="<?php echo e($all_resignation['resignation_description']); ?>">
                                                        <span class="svg-icon svg-icon-1" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="View Description" aria-hidden="true">
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="currentColor"></path>
                                                                <rect x="6" y="12" width="7" height="2" rx="1" fill="currentColor"></rect>
                                                                <rect x="6" y="7" width="12" height="2" rx="1" fill="currentColor"></rect>
                                                            </svg>
                                                        </span>
                                                    </a>
                                                </td>
                                                <td class="text-center" >
                                                    <?php if($all_resignation['request_approved_by_jm'] == 1): ?>
                                                        <span class="badge badge-light-secondary text-center text-muted font-weight-bold">Pending</span>
                                                    <?php elseif($all_resignation['request_approved_by_jm'] == 2): ?>
                                                        <span class="badge badge-light-success text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_jm']); ?>">Approved</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-light-danger text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_jm']); ?>" >Disapproved</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php if($all_resignation['request_approved_by_sm'] == 1): ?>
                                                        <span class="badge badge-light-secondary text-center text-muted font-weight-bold">Pending</span>
                                                    <?php elseif($all_resignation['request_approved_by_sm'] == 2): ?>
                                                        <span class="badge badge-light-success text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_sm']); ?>">Approved</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-light-danger text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_sm']); ?>">Disapproved</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="text-center">
                                                    <?php if($all_resignation['request_approved_by_hr'] == 1): ?>
                                                        <span class="badge badge-light-secondary text-center text-muted font-weight-bold">Pending</span>
                                                    <?php elseif($all_resignation['request_approved_by_hr'] == 2): ?>
                                                        <span class="badge badge-light-success text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_sm']); ?>">Approved</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-light-danger text-center font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($all_resignation['request_approved_date_sm']); ?>">Disapproved</span>
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <td class="text-center">
                                                    <?php if($login_user[0]['employee_department'] == 2 || $login_user[0]['employee_department'] == 1): ?>
                                                    

                                                            <?php if($all_resignation['request_approved_by_jm'] == 1 || $all_resignation['request_approved_by_sm'] == 1 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>
                                                                
                                                                <i class="fa-regular fa-circle-check  text-success mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                            <?php else: ?>

                                                                <i class="fa-regular fa-circle-check resignation_request text-success mx-2"  data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-value="Approve" data-bs-toggle="tooltip" data-bs-placement="top" title="Approve Request" style="font-size: 20px;cursor: pointer;"></i>
                                                                
                                                            <?php endif; ?>

                                                            <?php if($all_resignation['request_approved_by_jm'] == 1 || $all_resignation['request_approved_by_sm'] == 1 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>

                                                                <i class="fa-regular fa-circle-xmark  text-warning mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                                
                                                            
                                                            <?php else: ?>
                                                                
                                                                <i class="fa-regular fa-circle-xmark resignation_request text-warning mx-2" data-value="DisApprove" data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Disapprove Request" style="font-size: 20px;cursor: pointer;"></i>

                                                            <?php endif; ?>

                                                    <?php else: ?>
                                                        <?php if($all_resignation['employee_ra'] == $login_user[0]['employee_id']): ?>
                                                           

                                                                <?php if($all_resignation['request_approved_by_jm'] == 2 || $all_resignation['request_approved_by_jm'] == 3 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>
                                                                    <i class="fa-regular fa-circle-check  text-success mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                                <?php else: ?>

                                                                    <i class="fa-regular fa-circle-check resignation_request text-success mx-2"  data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-value="LeadApprove" data-bs-toggle="tooltip" data-bs-placement="top" title="Approve Request" style="font-size: 20px;cursor: pointer;"></i>

                                                                <?php endif; ?>

                                                           
                                                                <?php if($all_resignation['request_approved_by_jm'] == 2 || $all_resignation['request_approved_by_jm'] == 3 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>

                                                                    <i class="fa-regular fa-circle-xmark  text-warning mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>

                                                                <?php else: ?>
                                                                    
                                                                    <i class="fa-regular fa-circle-xmark resignation_request text-warning mx-2" data-value="LeadDisApprove" data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Disapprove Request" style="font-size: 20px;cursor: pointer;"></i>

                                                                <?php endif; ?>

                                                            <?php elseif($all_resignation['employee_ra2'] == $login_user[0]['employee_id']): ?>
                                                           

                                                                <?php if($all_resignation['request_approved_by_sm'] == 2 || $all_resignation['request_approved_by_sm'] == 3 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>
                                                                    <i class="fa-regular fa-circle-check  text-success mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                                <?php else: ?>

                                                                    <i class="fa-regular fa-circle-check resignation_request text-success mx-2"  data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-value="LeadApprove" data-bs-toggle="tooltip" data-bs-placement="top" title="Approve Request" style="font-size: 20px;cursor: pointer;"></i>

                                                                <?php endif; ?>


                                                           

                                                                <?php if($all_resignation['request_approved_by_sm'] == 2 || $all_resignation['request_approved_by_sm'] == 3 || $all_resignation['request_approved_by_hr'] == 2 || $all_resignation['request_approved_by_hr'] == 3): ?>

                                                                    <i class="fa-regular fa-circle-xmark  text-warning mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                                    
                                                                <?php else: ?>

                                                                    <i class="fa-regular fa-circle-xmark resignation_request text-warning mx-2" data-value="LeadDisApprove" data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Disapprove Request" style="font-size: 20px;cursor: pointer;"></i>

                                                                <?php endif; ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>


                                                    <?php if($login_user[0]['employee_department'] == 2 || $login_user[0]['employee_department'] == 1): ?>
                                                       

                                                            <?php if($all_resignation['request_approved_by_jm'] == 1 || $all_resignation['request_approved_by_sm'] == 1): ?>
                                                                
                                                                <i class="fa-regular fa-circle-check resignation_request text-success mx-2"  data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-value="ForceApprove" data-bs-toggle="tooltip" data-bs-placement="top" title="Force Approve Request" style="font-size: 20px;cursor: pointer;" data-title="Are you sure to <b>Force Approve</b> resignation ?"></i>

                                                            <?php else: ?>
                                                                <i class="fa-regular fa-circle-check  text-success mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                            <?php endif; ?>

                                                       

                                                            <?php if($all_resignation['request_approved_by_jm'] == 1 || $all_resignation['request_approved_by_sm'] == 1): ?>

                                                                <i class="fa-regular fa-circle-xmark resignation_request text-danger mx-2" data-value="ForceDisApprove" data-id="<?php echo e($all_resignation['resignation_id']); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Force DisApprove Request" data-title="Are you sure to <b>Force Dis-Approve</b> resignation ?" style="font-size: 20px;cursor: pointer;"></i>

                                                            <?php else: ?>
                                                                <i class="fa-regular fa-circle-xmark  text-danger mx-2"  style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                            <?php endif; ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>														 				
                            </table>
                        </div>
                    </div>
                    
                </div>
                 
            </div>
            
           
        </div>
        
    </div>

    
    <div class="modal fade" id="modal-success" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <form class="request_submit">
                <?php echo csrf_field(); ?>
                <div class="modal-content rounded">
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Confirmation Alert</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-white" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                </svg>
                            </span>
                        </button>
                    </div>

                    <div class="modal-body pt-0">
                        <p class="pt-4 fs-6 msg">Are you sure to <b>Approve</b>  resignation ?</p>
                    </div>

                    <div class="modal-footer">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="approve_btn" class="btn btn-primary">
                            <span class="indicator-label">Yes, Approve</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>



    <div class="modal fade" id="modal-danger" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <form class="request_submit">
                <?php echo csrf_field(); ?>
                <div class="modal-content rounded">
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Confirmation Alert</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                </svg>
                            </span>
                        </button>
                    </div>

                    <div class="modal-body pt-0 ">
                        <p class="pt-5 fs-6 msg">Are you sure to <b>Disapprove</b> resignation ?</p>
                    </div>

                    <div class="modal-footer">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="disapprove_btn" class="btn btn-primary">
                            <span class="indicator-label">Yes, Disapprove</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department'] == 2): ?>
        <form id="reject_resignation" class="form">
            <?php echo csrf_field(); ?> 
            <div class="modal fade" id="rejectresignation" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable">
                    <div class="modal-content rounded">
                        <div class="modal-header">
                            <h4 class="modal-title pl-4">Reject Resignation</h4>
                            <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                    </svg>
                                </span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-md-12 fv-row">
                                <select class="form-select" data-control="select2" data-hide-search="true" data-placeholder="Select Employee" name="resignation_id"  required="required">
                                    <option value="">Select Employee</option>
                                    <?php if(!empty($resignations_employee)): ?>
                                            <?php $__currentLoopData = $resignations_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($employee['resignation_id']); ?>">
                                                <?php echo e($employee['employee_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="reject_btn" class="btn btn-primary">
                                <span class="indicator-label">Reject</span>
                                <span class="indicator-progress">Please wait... 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>  
                    </div>
                </div>
            </div>
        </form>   
    <?php endif; ?>
    
    
        
    <div class="modal fade" id="message_modal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <div class="modal-content rounded">
                <div class="modal-content rounded">
                    <div class="modal-header">
                    <h4 class="modal-title pl-4">Resignation Description</h4>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                    </div>
                    <div class="modal-body">
                        <p id="message_body" ></p>
                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>

    var request_id = null;
    var status;
    $('.resignation_request').on('click', function(e) {
        // alert(value);
        status = $(this).attr('data-value');
        title = $(this).attr('data-title');
        request_id = $(this).attr('data-id');
       
        
       

        if(status == "ForceDisApprove" || status == "DisApprove" || status == "LeadDisApprove"){
            $('#modal-danger').modal('show');

            if(title != ''){
                $('.msg').html(title);
            }
           

        }else{
           
            $('#modal-success').modal('show');

            if(status == "ForceApprove"){
                $('.msg').html(title);
            }
          

        }
       
    });
    
    $('.request_submit').submit(function(e) {
        e.preventDefault(); 
        $('#modal-danger').modal('hide');
        $('#modal-success').modal('hide');
        
       
        // var values = [];  
        // var checkbox = document.querySelectorAll('input[type="checkbox"]:checked');
    
        // if(checkbox.length > 0){
           
        //     $(".checked:checked").each(function() {  
        //         values.push($(this).attr('data-id'));
        //     });  
        //     var value = values.join(",");
           
        // }else{
        //     ;
        // }
        value = request_id;
        
        $.ajax({
            url: '<?php echo e(url("resignations/resignationapproverequest")); ?>',
            type: 'POST',
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data: {id:value,status:status},
            success: function (data) {
                if (data.status == "TRUE") {
                    $(".checked").prop("checked", false);
                    Toast.fire({
                    icon: 'success',
                    title: data.msg,
                    timer: 5000,
                })
                setTimeout(() => {
                    location.reload();
                }, 5000);
                    
                } else if (data.status == "FALSE") {
                    Toast.fire({
                    icon: 'warning',
                    title: data.msg,
                    timer: 5000,
                })
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });

        
    });


    $('#reject_resignation').submit(function(e) {
        $('#reject_btn').prop('disabled', true);
        $('#reject_btn').attr('data-kt-indicator', 'on');
        $('#reject_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('resignations/resignation-reject')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 5000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#reject_btn').prop('disabled', false);
                    $('#reject_btn').css('cursor', 'pointer');
                    $("#reject_btn").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#reject_btn').prop('disabled', false);
                $('#reject_btn').css('cursor', 'pointer');
                $("#reject_btn").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });

    function resignationapprove(resignation_id){
        $('input[name=resignation_id]').val(resignation_id)

    }
    $('#approve_resignation').submit(function(e) {
        e.preventDefault();
        $('#approve_btn').prop('disabled', true);
        $('#approve_btn').attr('data-kt-indicator', 'on');
        $('#approve_btn').css('cursor', 'not-allowed');
        e.preventDefault();

        $.ajax({
            url: '<?php echo e(url('resignations/resignation-approval')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 5000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#approve_btn').prop('disabled', false);
                    $('#approve_btn').css('cursor', 'pointer');
                    $("#approve_btn").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#approve_btn').prop('disabled', false);
                $('#approve_btn').css('cursor', 'pointer');
                $("#approve_btn").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });


    function resignationdisapprove(resignation_id){
        $('input[name=resignation_id]').val(resignation_id)

    }
    $('#disapprove_resignation').submit(function(e) {
        e.preventDefault();
        $('#disapprove_btn').prop('disabled', true);
        $('#disapprove_btn').attr('data-kt-indicator', 'on');
        $('#disapprove_btn').css('cursor', 'not-allowed');
        e.preventDefault();

        $.ajax({
            url: '<?php echo e(url('resignations/resignation-disapproval')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 5000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#disapprove_btn').prop('disabled', false);
                    $('#disapprove_btn').css('cursor', 'pointer');
                    $("#disapprove_btn").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#disapprove_btn').prop('disabled', false);
                $('#disapprove_btn').css('cursor', 'pointer');
                $("#disapprove_btn").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });



    $('.message_btn').click(function() {
        var message = $(this).attr('data-message');
        $('#message_body').html(message);
    });

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/resignation/all-employee-resignation.blade.php ENDPATH**/ ?>