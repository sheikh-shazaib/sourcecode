



<?php $__env->startPush('css-link'); ?>
table.dataTable
{
 overflow-x:hidden !important;
 overflow-y:auto !important;
}
<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
						 
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
    
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                <?php if(empty($month) && empty($year)): ?>
                    Attendance Sheet (<?php echo e(date('F') . '-' . date('Y')); ?>)
                <?php else: ?>
                    Attendance Sheet (<?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?>)
                <?php endif; ?>
                </h1>   
            </div>
            <div>
                <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department']== 2): ?>
                    <button type="button" class="btn btn-sm fw-bold btn-primary" id="machine_records_fetcher">Fetch Attendance From Machine</button>
                    <button class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                    data-bs-target="#modal-default2">Mark Attendance</button>
                <?php endif; ?>
                    <button class=" btn btn-sm btn-info float-sm-right float-sm-right " data-bs-toggle="modal" data-bs-target="#modal_signs">Check Signs </button>
            </div>
           

        </div>
    </div>
       
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1 me-5">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                        
                    </div>

                    <?php $update_attendance = '' ?>
                    
                    <?php if(!empty($all_attendaces)): ?>
                        <div class="card-toolbar" >
                            
                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                        
                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            Filter</a>
                            
                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                    <form action="<?php echo e(url('attendance')); ?>" method="GET">
                                        <div class="px-7 py-5">
                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                        </div>
                                    
                                        <div class="separator border-gray-200"></div>
                                        <div class="px-7 py-5">
                                            <div class="mb-3">
                                            
                                                <label class="form-label fw-semibold">Status</label>
                                                
                                                <div>
                                                    <select class="form-select " data-kt-select2="true" data-placeholder="Select Name" name="is_active"
                                                    required="" id="employee_data">
                                                    <option value="1" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '1'): ?> selected <?php endif; ?>>Active
                                                        Employees</option>
                                                    <option value="2" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '2'): ?> selected <?php endif; ?>>De-active
                                                        Employees</option>
                                                </select>
                                                </div>
                                                
                                            </div>

                                            <div class="mb-3">
                                                
                                                <label class="form-label fw-semibold">
                                                    <span>By Name</span>  
                                                </label>
                                                
                                                <div>
                                                    <select class="form-select " data-kt-select2="true" data-placeholder="Select Name" name="emp_name"
                                                    id="by_name">
                                                        <?php if(!empty($all_employees)): ?>
                                                        <option value="">Select Name</option>
                                                            <?php $__currentLoopData = $all_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($data['employee_id']); ?>"<?php if(Request::get('emp_name') == $data['employee_id']): ?> selected <?php endif; ?>><?php echo e($data['employee_code']. ' - ' .$data['employee_name']); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                                
                                            </div>
                                            <div class="mb-3 row" >
                                                <div class="col-6">
                                                
                                                    <label class="form-label fw-semibold">Select Month</label>
                                                    
                                                    <div>
                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Month" name="m" required="required">
                                                            <option value="">Select Month</option>
                                                            <option value="01" <?php if(!empty($month) && $month == '01'): ?> selected  <?php elseif(empty($month) && date('m') == '01'): ?> selected  <?php endif; ?>>January
                                                            </option>
                                                            <option value="02" <?php if(!empty($month) && $month == '02'): ?> selected <?php elseif(empty($month) && date('m') == '02'): ?> selected  <?php endif; ?>>February
                                                            </option>
                                                            <option value="03" <?php if(!empty($month) && $month == '03'): ?> selected <?php elseif(empty($month) && date('m') == '03'): ?> selected  <?php endif; ?>>March
                                                            </option>
                                                            <option value="04" <?php if(!empty($month) && $month == '04'): ?> selected <?php elseif(empty($month) && date('m') == '04'): ?> selected <?php endif; ?>>April
                                                            </option>
                                                            <option value="05" <?php if(!empty($month) && $month == '05'): ?> selected <?php elseif(empty($month) && date('m') == '05'): ?> selected <?php endif; ?>>May
                                                            </option>
                                                            <option value="06" <?php if(!empty($month) && $month == '06'): ?> selected <?php elseif(empty($month) && date('m') == '06'): ?> selected <?php endif; ?>>June
                                                            </option>
                                                            <option value="07" <?php if(!empty($month) && $month == '07'): ?> selected <?php elseif(empty($month) && date('m') == '07'): ?> selected  <?php endif; ?>>July
                                                            </option>
                                                            <option value="08" <?php if(!empty($month) && $month == '08'): ?> selected <?php elseif(empty($month) && date('m') == '08'): ?> selected  <?php endif; ?>>August
                                                            </option>
                                                            <option value="09" <?php if(!empty($month) && $month == '09'): ?> selected <?php elseif(empty($month) && date('m') == '09'): ?> selected  <?php endif; ?>>September
                                                            </option>
                                                            <option value="10" <?php if(!empty($month) && $month == '10'): ?> selected  <?php elseif(empty($month) && date('m') == '10'): ?> selected <?php endif; ?>>October
                                                            </option>
                                                            <option value="11" <?php if(!empty($month) && $month == '11'): ?> selected  <?php elseif(empty($month) && date('m') == '11'): ?> selected <?php endif; ?>>November
                                                            </option>
                                                            <option value="12" <?php if(!empty($month) && $month == '12'): ?> selected <?php elseif(empty($month) && date('m') == '12'): ?> selected <?php endif; ?>>December
                                                            </option>
                                                        </select>
                                                    </div>
                                                    
                                                </div>
                                                <div class="col-6">
                                                    
                                                    <label class="form-label fw-semibold">Attendance Year</label>
                                                    
                                                    <div>
                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required">
                                                            <option value="">Select Year</option>
                                                            <option value="2020" <?php if(!empty($year) && $year == '2020'): ?> selected <?php elseif(empty($year) && date('Y') == '2020'): ?> selected  <?php endif; ?>>2020
                                                            </option>
                                                            <option value="2021" <?php if(!empty($year) && $year == '2021'): ?> selected <?php elseif(empty($year) && date('Y') == '2021'): ?> selected  <?php endif; ?>>2021
                                                            </option>
                                                            <option value="2022" <?php if(!empty($year) && $year == '2022'): ?> selected <?php elseif(empty($year) && date('Y') == '2022'): ?> selected  <?php endif; ?>>2022
                                                            </option>
                                                            <option value="2023" <?php if(!empty($year) && $year == '2023'): ?> selected <?php elseif(empty($year) && date('Y') == '2023'): ?> selected  <?php endif; ?>>2023
                                                            </option>
                                                            <option value="2024" <?php if(!empty($year) && $year == '2024'): ?> selected <?php elseif(empty($year) && date('Y') == '2024'): ?> selected  <?php endif; ?>>2024
                                                            </option>
                                                            <option value="2025" <?php if(!empty($year) && $year == '2025'): ?> selected <?php elseif(empty($year) && date('Y') == '2025'): ?> selected  <?php endif; ?>>2025
                                                            </option>
                                                            <option value="2026" <?php if(!empty($year) && $year == '2026'): ?> selected <?php elseif(empty($year) && date('Y') == '2026'): ?> selected  <?php endif; ?>>2026
                                                            </option>
                                                            <option value="2027" <?php if(!empty($year) && $year == '2027'): ?> selected <?php elseif(empty($year) && date('Y') == '2027'): ?> selected  <?php endif; ?>>2027
                                                            </option>
                                                            <option value="2028" <?php if(!empty($year) && $year == '2028'): ?> selected <?php elseif(empty($year) && date('Y') == '2028'): ?> selected  <?php endif; ?>>2028
                                                            </option>
                                                            <option value="2029" <?php if(!empty($year) && $year == '2029'): ?> selected <?php elseif(empty($year) && date('Y') == '2029'): ?> selected  <?php endif; ?>>2029
                                                            </option>
                                                            <option value="2030" <?php if(!empty($year) && $year == '2030'): ?> selected <?php elseif(empty($year) && date('Y') == '2030'): ?> selected  <?php endif; ?>>2030
                                                            </option>
                                                        
                                                        </select>
                                                    </div>

                                                </div>
                                            </div>

                                            <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department']== 2): ?>
                                                <div class="mb-3">
                                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                        <span>Department</span>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="By selecting department you will only get result of employees that are active in selected department."></i>
                                                    </label>
                                                
                                                    <div>
                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Department" name="dept" onchange="changeDepartment(this.value)">
                                                            <option value="">Select Department</option>
                                                            <?php if(!empty($all_department)): ?>
                                                                <?php $__currentLoopData = $all_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($department['department_id']); ?>" <?php if(!empty(Request::get('dept')) && Request::get('dept') == $department['department_id']): ?> selected <?php endif; ?>><?php echo e($department['department_name']); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
                                                    
                                                </div>
                                            <?php endif; ?>
                                        
                                            <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department']== 2): ?>
                                            <?php $update_attendance = 'marked-attendance' ?>
                                            <div class="mb-3">
                                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                    <span>Reporting Authority</span>
                                                    <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="By selecting reporting authority you will only get result of employees that are active in selected department and under the selected reporting authority."></i>
                                                </label>
                                            
                                                <div>
                                                    <select class="form-select  select" data-kt-select2="true" data-placeholder="Select Reporting Authority"  name="ra" id="reportingAuthority">
                                                        <option value="">Select Reporting Authority</option>
                                                    </select>
                                                </div>
                                                
                                            </div>
                                            <?php endif; ?>
                                            
                                            <div class="d-flex justify-content-end">
                                                <?php if(!empty($month) && !empty($year)): ?>
                                                    <a href="<?php echo e(url('attendance')); ?>" class="btn btn-sm btn-danger btn-active-light-danger me-2 "
                                                        >Reset Filter</a>
                                                <?php endif; ?>
                                                <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" >Close</button>
                                                <button type="submit" class="btn btn-sm btn-primary">Apply</button>
                                            </div>
                                            
                                        </div>
                                    </form>
                                </div>
                        
                        </div>
                    <?php endif; ?>
                </div> 
                <div class="card-body py-3" id="sidebarminimize">
                    							 
                    <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="table-responsive">
                        
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableAllEmployeeAttendance" aria-describedby="tableEmployee_info">
                                                                                                            
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-7">Employee</th>
										<?php for($month_count = 1; $month_count <= $month_days; ++$month_count): ?>
											<?php
											
                                            $date = '' . $month_count . '-' . $month . '-' . $year . '';
											?>
											<th><?php echo e($month_count); ?> </th>
										<?php endfor; ?>
											<th><i class="fa-solid fa-calendar-check text-success"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total On Time"
                                                ></i></th>
											<th><i class="fa-solid fa-xmark text-danger" 
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total Absent"

                                                ></i></th>
											<th><i class="fa-solid fa-calendar-check text-danger"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total Half Day"
                                                ></i></th>
											<th><i class="fa-solid fa-calendar-check text-gray"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total Late Coming"
                                                ></i></th>
											<th><i class="fa-solid fa-user-large-slash text-info"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total Leaves" 
                                                ></i></th>
                                            <th><i class="fa-solid fa-clock text-success" 
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                data-bs-title="Total Work Hours" 
                                                 ></i></th>
                                            <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php if(!empty($all_attendaces)): ?>
										<?php $__currentLoopData = $all_attendaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>

                                                <td class="ps-6"><?php echo CustomHelper::getEmpProfileDiv($all_attendance['employee_id']); ?></td>
												

												<?php 
												
													$present_count = 0;
													$absent_count = 0;
													$halfday_count = 0;
													$late_count = 0;
													$leave_count = 0;
                                                    $total_working_hours = 0;
                                                    $total_working_hours_actual = 0;
                                                    $in_day_time_actual = $out_day_time_actual = 0 ;
                                                    $day = 1;

                                                    $attendance_total_count = count($all_attendance['attendance']);

                                                    if($attendance_total_count == 0){
                                                        
                                                        $calculate_working_hour['hours_actual'] = "00:00";
                                                        $calculate_working_hour['hours_worked'] = "00:00";
                                                    }
                                                    
                                                    
												
												?>
												<?php for($month_count = 1; $month_count <= $month_days; ++$month_count): ?>
													<?php
														
                                                        $date = '' . $month_count . '-' . $month . '-' . $year . '';
														$nameOfDay = date('l', strtotime($date));
														$absent = true;
                                                        $helper_absent = false;
                                                        
                                                        $loop_count = 0;

													?>
													
													<td>

														<?php $__currentLoopData = $all_attendance['attendance']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$atty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            <?php

                                                            $calculate_working_hour = CustomHelper::calculate_working_hour($atty['att_for_year'],$atty['att_for_month'],$atty['att_for_date'],$atty['att_check_in_time'],$atty['att_check_out_time'],$atty['att_shift_start_time'],$atty['att_shift_end_time'],$month_count,$atty['att_check_overall_status'],$month,$year,$total_working_hours,$total_working_hours_actual,$all_attendance['employee_offday1'],$all_attendance['employee_offday2'],$helper_absent,$attendance_total_count,$loop_count);

                                                            $total_working_hours = $calculate_working_hour['total_working_hours'];
                                                            $total_working_hours_actual = $calculate_working_hour['total_working_hours_actual'];
                                                            $helper_absent = $calculate_working_hour['helper_absent'];
                                                            $loop_count = $calculate_working_hour['loop_count'];

                                                            ?>
															<?php if($atty['att_for_date'] != '' && $atty['att_for_date'] == $month_count): ?>  
																<?php $absent = false; 
                                                                ?>                                                                     
																
																<?php if($atty['att_check_overall_status'] == 'Present'): ?>
																	<?php $present_count++; ?>
																	<i class="fa-solid fa-calendar-check text-success <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Check In Time : <?php echo e($atty['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($atty['att_check_out_time']); ?> &nbsp; &nbsp; Work Hours : <?php echo e($calculate_working_hour['total_working_hour_of_this_day']); ?>"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Absent'): ?>
																	<?php $absent_count++; ?>
																	<i class="fa-solid fa-xmark text-danger <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top" data-bs-title="Absent"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Half day'): ?>
																	<?php $halfday_count++; ?>
																	<i class="fa-solid fa-calendar-check text-danger <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Check In Time : <?php echo e($atty['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($atty['att_check_out_time']); ?>  &nbsp; &nbsp; Work Hours : <?php echo e($calculate_working_hour['total_working_hour_of_this_day']); ?>"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Late Coming'): ?>
																	<?php $late_count++; ?>
																	<i class="fa-solid fa-calendar-check text-gray <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Check In Time : <?php echo e($atty['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($atty['att_check_out_time']); ?>  &nbsp; &nbsp; Work Hours : <?php echo e($calculate_working_hour['total_working_hour_of_this_day']); ?>"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Casual Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
																	<i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Casual Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Annual Leave'): ?>
																	<?php $leave_count++; 

                                                                    ?>
																	<i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Annual Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Sick Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
                                                                    <i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Sick Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Maternity Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
                                                                    <i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Maternity Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Paternity Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
                                                                    <i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Paternity Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Bereavement Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
                                                                    <i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Bereavement Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Compensatory Leave'): ?>
																	<?php $leave_count++;
                                                                    ?>
																	<i class="fa-solid fa-user-large-slash text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Compensatory Leave"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif($atty['att_check_overall_status'] == 'Early out'): ?>
																	<i class="fa-solid fa-clock text-info <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="Check In Time : <?php echo e($atty['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($atty['att_check_out_time']); ?>  &nbsp; &nbsp; Work Hours : <?php echo e($calculate_working_hour['total_working_hour_of_this_day']); ?>"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="<?php echo e($atty['att_check_overall_status']); ?>" style="cursor: pointer;"></i>
																<?php elseif(substr($atty['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>

																	<i class="fa-solid fa-umbrella-beach text-warning <?php echo e($update_attendance); ?>"
																		data-bs-toggle="tooltip"
																		data-bs-placement="top"
																		data-bs-title="<?php echo e($atty['att_check_overall_status']); ?>"
																		data-attendance_id="<?php echo e($atty['attendance_id']); ?>"
																		data-intime="<?php echo e($atty['att_check_in_time']); ?>"
																		data-outtime="<?php echo e($atty['att_check_out_time']); ?>"
																		data-attstatus="Present" style="cursor: pointer;"></i>
																	
																<?php endif; ?>
																<span class="d-none">
																	<?php if(substr($atty['att_check_overall_status'] , 0, 7) == 'Holiday' || in_array($atty['att_check_overall_status'], ['Casual Leave', 'Annual Leave', 'Sick Leave' , 'Maternity Leave', 'Paternity Leave', 'Bereavement Leave', 'Compensatory Leave']) ): ?> 
																	<?php echo e($atty['att_check_overall_status']); ?>

																	<?php else: ?>
																	CI: <?php echo e($atty['att_check_in_time']); ?> | CO: <?php echo e($atty['att_check_out_time']); ?> | WH: <?php echo e($calculate_working_hour['total_working_hour_of_this_day']); ?> | <?php echo e($atty['att_check_overall_status']); ?>

																	<?php endif; ?> 
																</span>
															<?php endif; ?>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<?php
															
															$date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
															$nameOfDay = date('l' , $date_filter);
															$today = strtotime(date("Y-m-d"));
														?>
														
														<?php if($absent ): ?>
															<?php if( $all_attendance['employee_offday1'] == $nameOfDay || $all_attendance['employee_offday2'] == $nameOfDay ): ?>
																<i class="fa-solid fa-sun text-warning <?php echo e($update_attendance); ?>"
																data-bs-toggle="tooltip"
																data-bs-placement="top" data-bs-title="Off Day"
																data-attendance_id="NA"
																data-intime="00:00:00"
																data-outtime="00:00:00"
																data-employeeId="<?php echo e($all_attendance['employee_id']); ?>"                                                                       
																data-date= "<?php echo e($month_count); ?>"
																data-month = "<?php echo e($month); ?>"
																data-year = "<?php echo e($year); ?>"
																data-attstatus="Off Day" style="cursor: pointer;"></i>
																
																<span class="d-none">
																   Off Day
																</span>

															<?php elseif($date_filter < $today): ?>
																<?php $absent_count++; 
                                                                ?>
																<i class="fa-solid fa-xmark text-danger <?php echo e($update_attendance); ?>"
																data-bs-toggle="tooltip"
																data-bs-placement="top" data-bs-title="Absent"
																data-attendance_id="NA"
																data-intime="00:00:00"
																data-outtime="00:00:00"
																data-employeeId="<?php echo e($all_attendance['employee_id']); ?>"                                                                       
																data-date= "<?php echo e($month_count); ?>"
																data-month = "<?php echo e($month); ?>"
																data-year = "<?php echo e($year); ?>"
																data-attstatus="Absent" style="cursor: pointer;"></i>
																
																<span class="d-none">
																	Absent
																 </span>
															<?php endif; ?>
														<?php endif; ?>
														   
													</td>
													

													
												<?php endfor; ?>
													<td><?php echo e($present_count); ?></td>
													<td><?php echo e($absent_count); ?></td>
													<td><?php echo e($halfday_count); ?></td>
													<td><?php echo e($late_count); ?></td>
													<td><?php echo e($leave_count); ?></td>
                                                    <td 
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="top"
                                                    data-bs-title="Actual Hours : 
                                                    <?php echo e($calculate_working_hour['hours_actual'] ?? '00:00'); ?>

                                                    ">
                                                    <?php echo e($calculate_working_hour['hours_worked'] ?? '00:00'); ?>


                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(url('attendance/attendance-report?employee_id='.$all_attendance['employee_id'].'&month='.$month.'&year='.$year)); ?>" target="blank">
                                                            <i class="fa fa-download"></i>
                                                        </a>
                                                        
                                                    </td>
											</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
								<tfoot>
									<tr>
										<th>Employee</th>
										<?php for($month_count = 1; $month_count <= $month_days; ++$month_count): ?>
											<?php
											
                                            $date = '' . $month_count . '-' . $month . '-' . $year . '';
											
											?>
                                            
											<th><?php echo e($month_count); ?></th>
										<?php endfor; ?>
                                        <th><i class="fa-solid fa-calendar-check text-success"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total On Time"
                                            ></i></th>
                                        <th><i class="fa-solid fa-xmark text-danger" 
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total Absent"

                                            ></i></th>
                                        <th><i class="fa-solid fa-calendar-check text-danger"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total Half Day"
                                            ></i></th>
                                        <th><i class="fa-solid fa-calendar-check text-gray"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total Late Coming"
                                            ></i></th>
                                        <th><i class="fa-solid fa-user-large-slash text-info"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total Leaves" 
                                            ></i></th>
                                        <th><i class="fa-solid fa-clock text-success" 
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="top"
                                            data-bs-title="Total Work Hours" 
                                             ></i></th>
									</tr>
								</tfoot>	
                             
                            
                            </table>
                        </div>
                    </div>  
                </div>
                 
            </div>
            
           
        </div>
       
        
    </div>
    
    
        <div class="modal fade" id="modal_signs" tabindex="-1" aria-hidden="true">
            
            <div class="modal-dialog modal-dialog-scrollable">
                
            
                    
                
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                                <h4 class="modal-title pl-4">Attendance Symbols</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-white" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                        </svg>
                                    </span>
                                </button>
                            </div>
                            
                            
                            <div class="modal-body pt-0">
                                <table class="table table-bordered">
                                    <thead>
                                        <th class="text-center">Symbol</th>
                                        <th class="text-center">Description</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-calendar-check text-success"></i></td>
                                            <td class="text-center">On Time</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-calendar-check text-gray"></i></td>
                                            <td class="text-center">Late Coming</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-calendar-check text-danger"></i></td>
                                            <td class="text-center">Half Day</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-clock text-info"></i></td>
                                            <td class="text-center">Early Out</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-xmark text-danger"></i></td>
                                            <td class="text-center">Absent</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-user-large-slash text-info"></i></td>
                                            <td class="text-center">All Leaves</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-sun text-warning"></i></td>
                                            <td class="text-center">Off Day</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center"><i class="fa-solid fa-umbrella-beach text-warning"></i></td>
                                            <td class="text-center">Holiday</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            

                            
                        </div>
                    
                
            </div>
            
        </div>
    

    
    <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department']== 2): ?>
        <form id="update_attendance" class="form">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="modal-default2" tabindex="-1" aria-hidden="true">
                
                <div class="modal-dialog modal-dialog-scrollable">
                    
                    <div class="modal-content rounded">
                        
                        <div class="modal-header">
                            <h4 class="modal-title pl-4">Mark Attendance</h4>
                            <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                    </svg>
                                </span>
                            </button>
                        </div>
                        
                        
                        
                        <div class="modal-body">
                            
                            <div class="only_date_input col-md-12 mb-8 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Attendance Date</label>
                                <div class="position-relative d-flex align-items-center">
                                    <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                            <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                            <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                        </svg>
                                    </span>
                                    <input type="date" class="form-control  ps-12" name="attenadnce_date"  max="<?php echo e(date('Y-m-d')); ?>" required/>
                                
                                </div>
                            </div>

                          

                            <div class="d-flex flex-column mb-8 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Select Employee</span>
                                    <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Please select employee name attendance mark ."></i>
                                </label>
                                            
                                <div>
                                    <select class="form-select select" data-kt-select2="true" data-placeholder="Select Employee Name" name="employee_code" required>
                                    
                                    <option value="">Select Employee</option>
                                    <?php if(!empty($all_employees)): ?>
                                        <?php $__currentLoopData = $all_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_employee['employee_id']); ?>"
                                                <?php if($all_employee['employee_code'] == '' || $all_employee['employee_code'] == 'N/A'): ?> disabled <?php endif; ?>>
                                                <?php echo e($all_employee['employee_code'] . ' - ' . $all_employee['employee_name']); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </select>
                                </div>
                            
                            </div>

                            <div class="d-flex flex-column mb-8 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Please Mark My Attendance</span>
                                    <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Please select the option below which you are willing to mark your attendance."></i>
                                </label>
                                <select class="form-select " data-control="select2" data-hide-search="true" data-placeholder="Select Attendance type"  name="attendance_status" required> 
                                    <option value="" >Select Attendance Type</option>
                                    <option value="Present">As Present</option>
                                    <option value="Half day">As Half Day</option>
                                    
                                </select>
                            </div>
                            
                        </div>
                        
                        <div class="modal-footer justify-content-center">
                            <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="mark_attendance_btn" class="btn btn-primary">
                                <span class="indicator-label">Mark Attendance</span>
                                <span class="indicator-progress">Please wait 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </div>
                    
                        
                </div>
                
            </div>
        </form>
   
    

    
        <form id="update_attendance2" class="form">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="edit_modal" tabindex="-1" aria-hidden="true">
                
                <div class="modal-dialog modal-dialog-scrollable">
                    
                    <div class="modal-content rounded">
                            
                        <div class="modal-header">
                            <h4 class="modal-title pl-4">Edit Attendance</h4>
                            <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                                    </svg>
                                </span>
                            </button>
                        </div>
                    
                        
                        
                        <div class="modal-body">
                            <div class="row d-none">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Attendance ID<span class="text-danger"> *</span></label>
                                        <input type="text" class="form-control" name="attenadnce_id"
                                            placeholder="Enter Attendance Id" required id="attendance_date">
                        
                                        <input type="text" class="form-control" name="att_employee_id"
                                        placeholder="Enter Employee Id"  id="att_employee_id">
                        
                                        <input type="text" class="form-control" name="att_for_date"
                                        placeholder="Enter Attendance Id"  id="att_for_date">
                        
                                        <input type="text" class="form-control" name="att_for_month"
                                        placeholder="Enter Attendance Id"  id="att_for_month">
                        
                                            <input type="text" class="form-control" name="att_for_year"
                                        placeholder="Enter Attendance Id" id="att_for_year">
                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 mb-8 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">In Time</label>
                                <div class="position-relative d-flex align-items-center">
                                    <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                            <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                            <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                        </svg>
                                    </span>
                                
                                    <input type="time" step="1" class="form-control  ps-12" name="check_in_time"
                                    placeholder="Enter in Time" required id="intime" >

                                </div>
                            </div>
                        
                            <div class=" col-md-12 mb-8 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Out Time</label>
                                <div class="position-relative d-flex align-items-center">
                                    <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                            <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                            <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                        </svg>
                                    </span>
                                    <input type="time" step="1" class="form-control  ps-12" name="check_out_time"
                                            placeholder="Enter out Time" required id="outtime"  >
                                </div>
                            </div>
                        
                            <div class="d-flex flex-column mb-8 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Mark Attendance Status</span>
                                    <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Please select the option below which you are willing to mark employee attendance."></i>
                                </label>
                                <select class="form-select " data-control="select2" data-hide-search="true" data-placeholder="Select Attendance Status"  name="attendance_status" id="attendance_status" required> 
                                    <option value="" >Select Status</option>
                                    <option value="Present">On Time</option>
                                    <option value="Late Coming">Late Coming</option>
                                    <option value="Half day">Half Day</option>
                                    <option value="Early out">Early out</option>
                                    <option value="Absent">Absent</option>
                                    <option value="Casual Leave">Casual Leave</option>
                                    <option value="Sick Leave">Sick Leave</option>
                                    <option value="Annual Leave">Annual Leave</option>
                                    <option value="Maternity Leave">Maternity Leave</option>
                                    <option value="Paternity Leave">Paternity Leave</option>
                                    <option value="Bereavement Leave">Bereavement Leave</option>
                                    <option value="Compensatory Leave">Compensatory Leave</option>
                                    
                                </select>
                            </div>
                    
                        </div>
                        
                        <div class="modal-footer justify-content-center">
                            <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="edit_attendance_btn" class="btn btn-primary">
                                <span class="indicator-label">Update Attendance</span>
                                <span class="indicator-progress">Please wait 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>

                    </div>
                
                    
                </div>
                
            </div>
        </form>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
    
    $(function(){
        $('.select').select2({
            dropdownParent: $('#modal-default2 .modal-content  ')
        })
        let d = new Date();
        let monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        let month = monthNames[d.getMonth()];
        let year = d.getFullYear();
        if($("select[name=m]").val()){
            month = monthNames[$("select[name=m]").val()-1];
            year = $("select[name=y]").val();
        }
        let filename = month + "-" + year + " Attendance Record";
        
        dataTable = $('#tableAllEmployeeAttendance').DataTable({

            order: false,
            aLengthMenu: [
                [10, 25, 50, 100, 500, -1],
                [10, 25, 50, 100, 500, "All"]
            ],
            iDisplayLength: 500,
            
            dom: 'B',
            buttons: [
                {
                    extend: 'excel',
                    title: filename,
                    text: "Download Attendance Records",
                    className: 'mb-5 btn-sm btn-primary'
                }
                ] 
           

        });
		
		
	});
   
    $('#update_attendance').submit(function(e) {
        $('#mark_attendance_btn').prop('disabled', true);
        $('#mark_attendance_btn').attr('data-kt-indicator', 'on');
        $('#mark_attendance_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('attendance/update_attendance')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);

                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#mark_attendance_btn').prop('disabled', false);
                    $('#mark_attendance_btn').removeAttr('data-kt-indicator');
                    $('#mark_attendance_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
                $('#mark_attendance_btn').prop('disabled', false);
                $('#mark_attendance_btn').removeAttr('data-kt-indicator');
                $('#mark_attendance_btn').css('cursor', 'pointer');
            }
        });
    });

    $('.marked-attendance').dblclick(function() {
    
        var attendance_id = $(this).attr('data-attendance_id');
       
        var intime = $(this).attr('data-intime');
        var outtime = $(this).attr('data-outtime');
        var attendance_status = $(this).attr('data-attstatus');

        var employeeId = $(this).attr('data-employeeId');
        var dates = $(this).attr('data-date');
        var month = $(this).attr('data-month');
        var year = $(this).attr('data-year');


        if(attendance_id != "NA"){
            url = '<?php echo e(url('attendance/update_marked_attendance')); ?>';
        }else{
            url = '<?php echo e(url('attendance/update_marked_attendance_absent')); ?>';
        }
        $('#edit_modal').modal('show');
        $('#attendance_date').val(attendance_id);
        $('#intime').val(intime);
        $('#outtime').val(outtime);
        $('#att_employee_id').val(employeeId);
        $('#att_for_date').val(dates);
        $('#att_for_month').val(month);
        $('#att_for_year').val(year);
        $('#attendance_status').val(attendance_status).trigger('change');
    });

    $('#update_attendance2').submit(function(e) {
        $('#edit_attendance_btn').prop('disabled', true);
        $('#edit_attendance_btn').attr('data-kt-indicator', 'on');
        $('#edit_attendance_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: url,
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == "TRUE") {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);

                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#edit_attendance_btn').prop('disabled', false);
                    $('#edit_attendance_btn').removeAttr('data-kt-indicator');
                    $('#edit_attendance_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
                $('#edit_attendance_btn').prop('disabled', false);
                $('#edit_attendance_btn').removeAttr('data-kt-indicator');
                $('#edit_attendance_btn').css('cursor', 'pointer');
            }
        });
    });

    ra ='';
    if(window.location.href.indexOf('?m=') != -1){
        changeDepartment($("select[name=dept]").val());
        var loc = window.location.href ; 
        var index = loc.indexOf("&ra=");
        ra = loc.substring(index+4)
    }
    
    function changeDepartment(dept){
        // console.log('dept', dept)
        $.ajax({
            url: "<?php echo e(url('attendance/get-department-managers')); ?>",
            type: 'GET',
                            
            data: {
                department : dept
            },
            
            success: function(response) {
               
                $('#reportingAuthority').empty()
                var newOption = new Option("Select Reporting Authority", '' , false, false);
                $('#reportingAuthority').append(newOption).trigger('change');                 
              
                response = JSON.parse(JSON.stringify(response)); 
                if(response !== ''){
                    for(i=0; i<response.data.length; i++){
                        let newOption = new Option(response.data[i]['employee_name'], response.data[i]['employee_id'] , false, false);
                        $('#reportingAuthority').append(newOption).trigger('change');
                    }
                   
                    $('#reportingAuthority').val(ra);
                    $('#reportingAuthority').trigger('change');
                }
                
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
                
            }
        });
        
       
    }
   

    $('#employee_data').change(function(){
        var selected_val = $('#employee_data').find(":selected").val();
        $('#by_name').text('');
        $.ajax({
            url: '<?php echo e(url('get_employees')); ?>/' + selected_val,
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                status: selected_val
            },
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#by_name').append(data);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
            }
        });
    });


    $('#machine_records_fetcher').click(function(e){
        $('#machine_records_fetcher').prop('disabled', true);
        $('#machine_records_fetcher').html('Please Wait');
        e.preventDefault();
        $.ajax({
            url: "<?php echo e(url('pull-attendance')); ?>",
            type: 'GET',
            success: function(response) {
                if (response.status == "TRUE") {
                    Toast.fire({
                        icon: 'success',
                        title: response.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: response.msg,
                        timer: 5000,
                    })
                    $('#machine_records_fetcher').prop('disabled', false);
                    $('#machine_records_fetcher').html('Fetch Attendance From Machine');
                }
            },
            error: function(jqXHR, textStatus) {
                $('#machine_records_fetcher').prop('disabled', false);
                $('#machine_records_fetcher').html('Fetch Attendance From Machine');
                var errorStatus = jqXHR.status;
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 5000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code' + errorStatus,
                        timer: 5000,
                    })
                }
                
            }
        });
    });
        

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/attendance/all-employees-attendance.blade.php ENDPATH**/ ?>