

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                    Office Rooms
                   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <div class="m-0">
                    <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addroom">											
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                            </svg>
                        </span>
                        Add New Room</a>   
                </div>
         
            </div>
         
        </div>
        
    </div>
   
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">

            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                </div> 
   
                <div class="card-body py-3">
                    
                    <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="system_datatable" aria-describedby="tableEmployee_info">
                            
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4">Room Code</th>
                                        <th>Room Name</th>
                                        <th>Room Date</th>
                                         <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($rooms)): ?>
                                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-4"><?php echo e($room['room_id']); ?></td>
                                                <td> <?php echo e($room['room_name']); ?> </td>
                                                <td><?php echo e(date('d-m-Y H:i:s', strtotime($room['last_updated']))); ?></td>
                                                <td>
                                                  <a href="javascript:void(0);" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" title="Edit Room Request" onclick="editroomRequest('<?php echo e($room['room_id']); ?>','<?php echo e($room['room_name']); ?>')">
                                                            <span class="svg-icon svg-icon-3">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                                </svg>
                                                            </span>
                                                        </a>

                                                        <a href="javascript:void(0);" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" title="Delete Room Request" onclick="deleteroomRequest('<?php echo e($room['room_id']); ?>')">
                                                            <span class="svg-icon svg-icon-3">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                                </svg>
                                                            </span>
                                                        </a>
                                                    </td>    
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            
                            </table>
                        </div>
                    
                    </div>
                    
                   
                
                </div>   
            </div>

            
            <form id="addroomForm" class="form">
                <?php echo csrf_field(); ?>  
                <div class="modal fade" id="addroom" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                                
                                <div class="modal-header">
                                <h4 class="modal-title pl-4">Add Room</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                                </div>
                                
                            <div class="modal-body scroll-y pt-3 pb-5">
                                
                                <div class="col-md-12 mb-8 mt-3 fv-row">
                                    <label class="fs-6 fw-semibold mb-2 required">Room Name</label>
                                    <input type="text" class="form-control " name="room_name" maxlength="50" placeholder="Enter Room" required="">
                                </div>
                               
                            </div>
                            
                            
                            <div class="modal-footer justify-content-center">
                                
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit-btn" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </form>
            

             
            <form id="updateroomForm" class="form">
                <?php echo csrf_field(); ?>  
                <div class="modal fade" id="updateroom" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                                
                                <div class="modal-header">
                                <h4 class="modal-title pl-4">Update Room</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                                </div>
                                
                            <div class="modal-body scroll-y pt-3 pb-5">
                                
                                 <input type="hidden" name="room_id" value=""/>
                                <div class="col-md-12 mb-8 mt-3 fv-row">
                                    <label class="fs-6 fw-semibold mb-2 required">Room</label>
                                    <input type="text" class="form-control " name="room_name" id="room_names" maxlength="50" placeholder="Enter Room" required="">
                                </div>
                               
                            </div>
                            
                            
                            <div class="modal-footer justify-content-center">
                                
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="update-btn" class="btn btn-primary">
                                    <span class="indicator-label">Update</span>
                                    <span class="indicator-progress">Please wait 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </form>
            

             
        <div class="modal fade" tabindex="-1" id="delete-room-request">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 class="modal-title">Confirmation Alert</h3>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1 bg-white">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                        </button>
                    </div>
                    <form id="delete_room_request" class="form" >
                        <?php echo csrf_field(); ?>
                        
                        <div class="modal-body">
                        <input type="hidden" class="form-control" name="room_id" />
                            <p>Are you sure to delete this Room Request ?</p>
                        </div>
            
                        <div class="modal-footer">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="delete_submit_btn" class="btn btn-primary">
                                <span class="indicator-label">Delete</span>
                                <span class="indicator-progress">Please wait 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </form>    
                </div>
            </div>
        </div>
        
        </div>
    
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
<script>

 $('#addroomForm').submit(function(e) { 
            $('#submit-btn').prop('disabled', true);
            $('#submit-btn').attr('data-kt-indicator', 'on');
            $('#submit-btn').css('cursor', 'not-allowed');
            e.preventDefault();  
           $.ajax({
                url: '<?php echo e(url('rooms/addroom')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#submit-btn').prop('disabled', false);
                        $("#submit-btn").removeAttr('data-kt-indicator');
                        $('#submit-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#submit-btn').prop('disabled', false);
                    $("#submit-btn").removeAttr('data-kt-indicator');
                    $('#submit-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						Toast.fire({
							icon: 'warning',
							title: 'Try Again. Error Code ' + errorStatus,
							timer: 3000,
						})
                    }
                }
            });
        });

        function editroomRequest(room_id,room_name){
        $('input[name=room_id]').val(room_id);
        $('#room_names').val(room_name);
         $('#updateroom').modal('show');

        }

        $('#updateroomForm').submit(function(e) {
            $('#update-btn').prop('disabled', true);
            $('#update-btn').attr('data-kt-indicator', 'on');
            $('#update-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('rooms/updateroom')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#update-btn').prop('disabled', false);
                        $("#update-btn").removeAttr('data-kt-indicator');
                        $('#update-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#update-btn').prop('disabled', false);
                    $("#update-btn").removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						Toast.fire({
							icon: 'warning',
							title: 'Try Again. Error Code ' + errorStatus,
							timer: 3000,
						})
                    }
                }
            });
        });

    function deleteroomRequest(room_id){
       $('input[name=room_id]').val(room_id);
       $('#delete-room-request').modal('show');

    }

      $('#delete_room_request').submit(function(e) {
        $('#delete_submit_btn').prop('disabled', true);
        $("#delete_submit_btn").attr('data-kt-indicator', 'on');
        $('#delete_submit_btn').css('cursor', 'pointer');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('rooms/deleteroom')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    if(data.autoreload == "TRUE"){
                      
                      Toast.fire({
                      icon: 'warning',
                      title: data.msg,
                      timer: 3000,
                      })
                      setTimeout(() => {
                          location.reload();
                      }, 3000);
                    }
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 3000,
                    })
                   
                    $('#delete_submit_btn').prop('disabled', false);
                    $('#delete_submit_btn').css('cursor', 'pointer');
                    $("#delete_submit_btn").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#delete_submit_btn').prop('disabled', false);
                $('#delete_submit_btn').css('cursor', 'pointer');
                $("#delete_submit_btn").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>       
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/room-screen/rooms.blade.php ENDPATH**/ ?>