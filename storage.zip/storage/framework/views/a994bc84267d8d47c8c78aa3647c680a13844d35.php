

    <?php
        $permission = CustomHelper::access_permission();
        $meetings  = CustomHelper::get_my_todays_meeting_status();
        $companySetting = CustomHelper::hcm_default_settings();
    ?>
   
    <div id="kt_app_sidebar" class="app-sidebar flex-column" data-kt-drawer="true" data-kt-drawer-name="app-sidebar" data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true" data-kt-drawer-width="225px" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_app_sidebar_mobile_toggle">

        <div class="app-sidebar-logo px-12" id="kt_app_sidebar_logo">
            <a href="<?php echo e(url('/')); ?>">
                <img alt="Logo"  src=" <?php echo e($companySetting['company_favicon']); ?>" class="h-45px app-sidebar-logo-default" />

                <img alt="Logo" src="<?php echo e($companySetting['company_favicon']); ?>" class="h-20px app-sidebar-logo-minimize" />
                <span class=" font-weight-bold text-white text-capitalize text-center">
                    <?php if(!empty($companySetting['company_name'])): ?>
                        <?php echo e($companySetting['company_name']); ?>

                    <?php else: ?>
                        Demo Company
                    <?php endif; ?>
                </span>
            </a>


            <div id="kt_app_sidebar_toggle" class="app-sidebar-toggle btn btn-icon btn-shadow btn-sm btn-color-muted btn-active-color-primary body-bg h-30px w-30px position-absolute top-50 start-100 translate-middle rotate" data-kt-toggle="true" data-kt-toggle-state="active" data-kt-toggle-target="body" data-kt-toggle-name="app-sidebar-minimize">
                <span class="svg-icon svg-icon-2 rotate-180">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path opacity="0.5" d="M14.2657 11.4343L18.45 7.25C18.8642 6.83579 18.8642 6.16421 18.45 5.75C18.0358 5.33579 17.3642 5.33579 16.95 5.75L11.4071 11.2929C11.0166 11.6834 11.0166 12.3166 11.4071 12.7071L16.95 18.25C17.3642 18.6642 18.0358 18.6642 18.45 18.25C18.8642 17.8358 18.8642 17.1642 18.45 16.75L14.2657 12.5657C13.9533 12.2533 13.9533 11.7467 14.2657 11.4343Z" fill="currentColor" />
                        <path d="M8.2657 11.4343L12.45 7.25C12.8642 6.83579 12.8642 6.16421 12.45 5.75C12.0358 5.33579 11.3642 5.33579 10.95 5.75L5.40712 11.2929C5.01659 11.6834 5.01659 12.3166 5.40712 12.7071L10.95 18.25C11.3642 18.6642 12.0358 18.6642 12.45 18.25C12.8642 17.8358 12.8642 17.1642 12.45 16.75L8.2657 12.5657C7.95328 12.2533 7.95328 11.7467 8.2657 11.4343Z" fill="currentColor" />
                    </svg>
                </span>
            </div>
        </div>


        <div class="app-sidebar-menu overflow-hidden flex-column-fluid">
            
            <div id="kt_app_sidebar_menu_wrapper" class="app-sidebar-wrapper hover-scroll-overlay-y my-5" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_app_sidebar_logo, #kt_app_sidebar_footer" data-kt-scroll-wrappers="#kt_app_sidebar_menu" data-kt-scroll-offset="5px" data-kt-scroll-save-state="true">
                
                <div class="menu menu-column menu-rounded menu-sub-indention px-3" id="#kt_app_sidebar_menu" data-kt-menu="true" data-kt-menu-expand="false">

                    <div class="mb-2">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-3">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control ps-15" placeholder="Search Menu ..." id="serachMenu" style="background: none">
                        </div>

                    </div>

                    <div class="menu-item search-item">
                        <a class="menu-link nav-link  <?php if($title == 'index'): ?> active <?php endif; ?>" href="<?php echo e(url('/')); ?>">
                            <span class="menu-icon">
                                <span class="svg-icon svg-icon-2">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect x="2" y="2" width="9" height="9" rx="2" fill="currentColor" />
                                        <rect opacity="0.3" x="13" y="2" width="9" height="9" rx="2" fill="currentColor" />
                                        <rect opacity="0.3" x="13" y="13" width="9" height="9" rx="2" fill="currentColor" />
                                        <rect opacity="0.3" x="2" y="13" width="9" height="9" rx="2" fill="currentColor" />
                                    </svg>
                                </span>
                            </span>
                            <span class="menu-title">Dashboard</span>
                        </a>
                    </div>
                    <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department'] == 2): ?>
                        <?php if(!empty($permission) && ($permission[12]['permission_status'] == 1 || $permission[12]['permission_status'] == 1 || $permission[14]['permission_status'] == 1  ||  $permission[15]['permission_status'] == 1 ||  $permission[52]['permission_status'] == 1)): ?>
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'employee' || $title == 'employee-managers' || $title == 'birthdays' || $title == 'work-anniversay' || $title == 'employee-devices'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Employees MDM.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Employee MDM</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'employee'): ?> active <?php endif; ?>" href="<?php echo e(url('/employees')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title ">Manage Employees</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[13]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link <?php if($title == 'employee-managers'): ?> active <?php endif; ?>" href="<?php echo e(url('/employees-managers')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>

                                                <span class="menu-title ">Employees Managers</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>



                                    <?php if(!empty($permission) && !empty($permission[14]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'birthdays'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-birthdays')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Employees Birthday</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    
                                    


                                    <?php if(!empty($permission) && !empty($permission[15]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'work-anniversay'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-work-anniversay')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Work Anniversery</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[52]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'employee-devices'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-devices')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Employees Devices</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    
                                </div>


                            </div>

                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && ($permission[19]['permission_status'] == 1 || $permission[20]['permission_status'] == 1 || $permission[21]['permission_status'] == 1 || $permission[1]['permission_status'] == 1 || $permission[2]['permission_status'] == 1 || $permission[54]['permission_status'] == 1 || $permission[22]['permission_status'] == 1 || $permission[22]['permission_status'] == 1)): ?> 
                        
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'manage-attendance' || $title == 'daily-attendance' || $title == 'overtime-management' || $title == 'my-attendance' || $title == 'attendance-request' || $title == 'my-attendance-request' || $title == 'wfh-request' || $title == 'my-wfh-requests'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Mark Attendance.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Attendance</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'mark-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('mark-attendance')); ?>" target="blank">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Mark Attendance.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Mark Attendance</span>
                                        </a>
                                    </div>
                                
                                    <?php if(!empty($permission) && !empty($permission[19]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('attendance')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Attendance.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Manage Attendance</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[21]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'daily-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('daily-attendance-report')); ?>">
                                                <span class="menu-icon">

                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Attendance Report.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Daily Attendance Report</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[1]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('my-attendance')); ?>">
                                                <span class="menu-icon">
                                                    <span class="menu-icon">
                                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Attendance.png')); ?>" />
                                                    </span>
                                                </span>
                                                <span class="menu-title">My Attendance</span>
                                            </a>
                                        </div>
                                        
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[20]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'attendance-request'): ?> active <?php endif; ?>" href="<?php echo e(url('attendance-requests')); ?>" >
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Attendance Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Attendance Requests</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[2]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-attendance-request'): ?> active <?php endif; ?>" href="<?php echo e(url('my-attendance-request')); ?>" >
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Attendance Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Attendance Requests</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    <?php if(!empty($permission) && !empty($permission[54]['permission_status'] == 1)): ?>
                            
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'shift-management'): ?> active <?php endif; ?>" href="<?php echo e(url('shift-management')); ?>" >
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Mark Attendance.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Shift Management</span>
                                            </a>
                                        </div>
        
                                    <?php endif; ?>
                                    <?php if(!empty($permission) && !empty($permission[56]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'overtime-management'): ?> active <?php endif; ?>" href="<?php echo e(url('overtime-management')); ?>">
                                                <span class="menu-icon">

                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Attendance Report.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Overtime Sheet</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    <?php if(!empty($permission) && !empty($permission[22]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'wfh-request'): ?> active <?php endif; ?>" href="<?php echo e(url('wfh-requests')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All WFH Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Remote Work Requests</span>
                                            </a>
                                        </div>
        
                                    <?php endif; ?>
    
                                    <?php if(!empty($permission) && !empty($permission[7]['permission_status'] == 1)): ?>
        
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-wfh-requests'): ?> active <?php endif; ?> " href="<?php echo e(url('my-wfh-requests')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My WFH Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Remote Work Request</span>
                                            </a>
                                        </div>
        
                                    <?php endif; ?>

                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[3]['permission_status'] == 1 || $permission[23]['permission_status'] == 1 || $permission[24]['permission_status'] == 1 || $permission[31]['permission_status'] == 1)): ?>
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'employees-leaves' || $title == 'my-leaves' || $title == 'manage-leaves' || $title == 'holidays'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Leave Requests.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Leave</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <?php if(!empty($permission) && !empty($permission[23]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'employees-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('employees-leaves')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Leave Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Leaves Requests</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[3]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('/my-leaves')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Leave Requests.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Leaves Requests</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[24]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('manage-leaves')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Leave Entilement.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Leaves Entitlement</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    <?php if(!empty($permission) && !empty($permission[31]['permission_status'] == 1 )): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'holidays'): ?> active <?php endif; ?>" href="<?php echo e(url('holidays')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Holidays.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Holidays</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[4]['permission_status'] == 1 || $permission[25]['permission_status'] == 1 || $permission[26]['permission_status'] == 1 || $permission[51]['permission_status'] == 1 || $permission[40]['permission_status'] == 1 || $permission[41]['permission_status'] == 1)): ?>
                            
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'manage-interviews' || $title == 'interview-candidate-list' || $title == 'my-interviews' || $title == 'employee-on-boarding' || $title == 'all-requisition' || $title == 'my-requisition'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Recruitment</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <?php if(!empty($permission) && !empty($permission[25]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-interviews'): ?> active <?php endif; ?>" href="<?php echo e(url('interviews')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Manage Interviews</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    
                                    <?php if(!empty($permission) && !empty($permission[51]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link  <?php if($title == 'interview-candidate-list'): ?> active <?php endif; ?>" href="<?php echo e(url('/candiddate-interviews')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Interview Candidates</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[4]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-interviews'): ?> active <?php endif; ?>" href="<?php echo e(url('my-interviews')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Interviews.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Interviews</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[26]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link  <?php if($title == 'employee-on-boarding'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-onboarding')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                                </span>
                                                <span class="menu-title">OnBoarding Employees</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[40]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'all-requisition'): ?> active <?php endif; ?>" href="<?php echo e(url('requisition')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Requisition</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[41]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-requisition'): ?> active <?php endif; ?>" href="<?php echo e(url('my-requisition')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Requisition</span>
                                            </a>
                                        </div>
                                    <?php endif; ?> 
                                </div>
                            </div>

                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[27]['permission_status'] == 1 || $permission[5]['permission_status'] == 1 || $permission[9]['permission_status'] == 1 || $permission[43]['permission_status'] == 1 || $permission[47]['permission_status'] == 1 || $permission[48]['permission_status'] == 1 || $permission[28]['permission_status'] == 1 || $permission[29]['permission_status'] == 1 || $permission[55]['permission_status'] == 1 || $permission[58]['permission_status'] == 1 )): ?>
                        
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'Payroll' || $title == 'my-payroll' || $title == 'all-salary-request' || $title == 'my-salary-request' || $title == 'Tax Slab' || $title == 'Tax Collection' || $title == 'cash' || $title == 'expense' || $title == 'employee-expense' || $title == 'my-expense'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Payslips.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Payroll</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">
                                    <?php if(!empty($permission) && !empty($permission[27]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'Payroll'): ?> active <?php endif; ?>" href="<?php echo e(url('payroll')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Payslips.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Manage Payroll</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[5]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'My Payslip'): ?> active <?php endif; ?>" href="<?php echo e((session('my_payroll') == "allow") ? url('my-payroll') : '#'); ?>" data-bs-toggle="<?php echo e((session('my_payroll') == "allow") ? '' : 'modal'); ?>" data-bs-target="#payslip_authentication_process">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Payslips.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Payslips</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[43]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'all-salary-request'): ?> active <?php endif; ?>" href="<?php echo e(url('all-salary-request')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Advance Salary Request</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[9]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-salary-request'): ?> active <?php endif; ?>" href="<?php echo e(url('my-salary-request')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Salary Request</span>
                                            </a>
                                        </div>
                                    <?php endif; ?> 

                                    <?php if(!empty($permission) && $permission[47]['permission_status'] == 1 ): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'Tax Slab'): ?> active <?php endif; ?>" href="<?php echo e(url('/tax-slab')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Income Tax.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Manage Income Tax</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
    
                                    <?php if(!empty($permission) && $permission[48]['permission_status'] == 1): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'Tax Collection'): ?> active <?php endif; ?>" href="<?php echo e(url('/tax-collection')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Tax Collection.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Income Tax Collection</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[28]['permission_status'] == 1)): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'cash'): ?> active <?php endif; ?>" href="<?php echo e(url('petty-cash')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Cash Inventory.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Cash Inventory</span>
                                        </a>
                                    </div>
    
                                <?php endif; ?>
    
                                <?php if(!empty($permission) && !empty($permission[29]['permission_status'] == 1)): ?>
    
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'expense'): ?> active <?php endif; ?>" href="<?php echo e(url('daily-expense')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Daily Expenses</span>
                                        </a>
                                    </div>
    
                                <?php endif; ?>
    
                                <?php if(!empty($permission) && !empty($permission[55]['permission_status'] == 1)): ?>
    
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'employee-expense'): ?> active <?php endif; ?>" href="<?php echo e(url('employee-expense')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Reimbursement Request</span>
                                        </a>
                                    </div>
    
                                <?php endif; ?>
    
                                <?php if(!empty($permission) && !empty($permission[58]['permission_status'] == 1)): ?>
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'my-expense'): ?> active <?php endif; ?>" href="<?php echo e(url('my-expense')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                            </span>
                                            <span class="menu-title">My Reimbursement Request</span>
                                        </a>
                                    </div>
    
                                <?php endif; ?>
                            
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && !empty($permission[10]['permission_status'] == 1 || !empty($permission[30]['permission_status'] == 1) || !empty($permission[44]['permission_status'] == 1))): ?>
                       
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'manage-loan' || $title == 'all-loan-request' || $title == 'my-loan'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Loans.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Loan</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">
                                    <?php if(!empty($permission) && !empty($permission[30]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-loan'): ?> active <?php endif; ?>" href="<?php echo e(url('loans')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Loans.png')); ?>" />
                                                </span>
                                                <span class="menu-title">Manage Loans</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    <?php if(!empty($permission) && !empty($permission[44]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'all-loan-request'): ?> active <?php endif; ?>" href="<?php echo e(url('all-loan-request')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Loan Request</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[10]['permission_status'] == 1)): ?>
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'my-loan'): ?> active <?php endif; ?>" href="<?php echo e(url('my-loan')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                                </span>
                                                <span class="menu-title">My Loan Request</span>
                                            </a>
                                        </div>
                                
                                    <?php endif; ?> 
                                    
                                </div>
                            </div>
                        <?php endif; ?>

                                                
                        <?php if(!empty($permission) && ( $permission[32]['permission_status'] == 1 || $permission[33]['permission_status'] == 1 || $permission[49]['permission_status'] == 1 || $permission[50]['permission_status'] == 1 || $permission[36]['permission_status'] == 1 )): ?>
                            
                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'manage-departments' || $title == 'manage-designations' || $title == 'manage-rooms' || $title == 'manage-locations' || $title == 'system-settings'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/System Settings.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Settings </span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <?php if(!empty($permission) && !empty($permission[32]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-departments'): ?> active <?php endif; ?>" href="<?php echo e(url('departments')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Manage Departments</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[33]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-designations'): ?> active <?php endif; ?>" href="<?php echo e(url('designations')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Manage Designations</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && $permission[49]['permission_status'] == 1 ): ?>
                                            
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-rooms'): ?> active <?php endif; ?>" href="<?php echo e(url('/rooms')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Rooms.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Rooms</span>
                                            </a>
                                        </div>
                                
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && $permission[50]['permission_status'] == 1 ): ?>
                                    
                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'manage-locations'): ?> active <?php endif; ?>" href="<?php echo e(url('/locations')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Location.png')); ?>" />
                                                </span>
                                                <span class="menu-title">All Locations</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($permission) && $permission[36]['permission_status'] == 1): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link <?php if($title == 'system-settings'): ?> active <?php endif; ?>" href="<?php echo e(url('system-settings')); ?>">
                                                <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/System Settings.png')); ?>" />
                                                </span>
                                                <span class="menu-title">System Settings</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                   
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[16]['permission_status'] == 1 || $permission[17]['permission_status'] == 1  || $permission[42]['permission_status'] == 1 || $permission[18]['permission_status'] == 1 || $permission[6]['permission_status'] == 1 || $permission[38]['permission_status'] == 1 || $permission[8]['permission_status'] == 1 || $permission[39]['permission_status'] == 1 || $permission[33]['permission_status'] == 1 || $permission[34]['permission_status'] == 1 || $permission[46]['permission_status'] == 1 || $permission[11]['permission_status'] == 1  || $permission[53]['permission_status'] == 1 || $permission[57]['permission_status'] == 1 || $permission[35]['permission_status'] == 1 || $permission[37]['permission_status'] == 1)): ?>
                            
                        <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'gadgets-inventory' || $title == 'gadgets-allotment' || $title == 'letters' || $title == 'all-meetings' || $title == 'my-meetings' || $title == 'all-resignation' || $title == 'resignation' || $title == 'Alerts' || $title == 'manage-departments' || $title == 'manage-designations' || $title == 'manage-vehicles' || $title == 'help-desk' || $title == 'my-help-desk' || $title == 'link-post' || $title == 'organogram' || $title == 'system-errors' || $title == 'login-history'): ?> show <?php endif; ?>">

                            <span class="menu-link">
                                <span class="menu-icon">
                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Gadgets Inventory.png')); ?>" />
                                </span>
                                <span class="menu-title">Others</span>
                                <span class="menu-arrow"></span>
                            </span>

                            <div class="menu-sub menu-sub-accordion menu-active-bg">

                                <?php if(!empty($permission) && !empty($permission[16]['permission_status'] == 1)): ?>
                                    <div class="menu-item search-item">

                                        <a class="menu-link nav-link  <?php if($title == 'gadgets-inventory'): ?> active <?php endif; ?>" href="<?php echo e(url('/gadgets-inventory')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Gadgets Inventory.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Gadgets Inventory</span>
                                        </a>
                                    </div>

                                <?php endif; ?>

                                <?php if(!empty($permission) && !empty($permission[17]['permission_status'] == 1)): ?>
                                    <div class="menu-item search-item">

                                        <a class="menu-link nav-link  <?php if($title == 'gadgets-allotment'): ?> active <?php endif; ?>" href="<?php echo e(url('/gadgets-allotment')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Gadgets Allotment.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Gadgets Allotment</span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if(!empty($permission) && ($permission[42]['permission_status'] == 1)): ?>
                            
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link  <?php if($title == 'letters'): ?> active <?php endif; ?>" href="<?php echo e(url('/letters')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Letters.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Letters</span>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if(!empty($permission) && !empty($permission[18]['permission_status'] == 1)): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'all-meetings'): ?> active <?php endif; ?>" href="<?php echo e(url('/meetings')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Meetings.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Meetings</span>
                                        </a>
                                    </div>

                                <?php endif; ?>
                                <?php if(!empty($permission) && !empty($permission[6]['permission_status'] == 1)): ?>

                                    <div class="menu-item search-item"> 
                                        <a class="menu-link nav-link <?php if($title == 'my-meetings'): ?> active <?php endif; ?>" href="<?php echo e(url('/my-meetings')); ?>">
                                            <?php if($meetings == 1): ?>  
                                                <span class="menu-icon pulse pulse-primary">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Meetings.png')); ?>" />
                                                    <span class="pulse-ring"></span>
                                                </span>
                                            <?php else: ?>
                                                    <span class="menu-icon">
                                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Meetings.png')); ?>" />
                                                </span>
                                            <?php endif; ?>  
                                            <span class="menu-title">My Meetings</span> 
                                        </a>
                                    </div>

                                <?php endif; ?>
                                <?php if(!empty($permission) && !empty($permission[38]['permission_status'] == 1)): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'all-resignation'): ?> active <?php endif; ?>" href="<?php echo e(url('resignations')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Resignation.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Resignation</span>
                                        </a>
                                    </div>

                                <?php endif; ?>


                                <?php if(!empty($permission) && !empty($permission[8]['permission_status'] == 1)): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'resignation'): ?> active <?php endif; ?>" href="<?php echo e(url('employee-resignation')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Resignation.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Resignation</span>
                                        </a>
                                    </div>

                                <?php endif; ?>
                                <?php if(!empty($permission) && !empty($permission[39]['permission_status'] == 1)): ?>
                            
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'Alerts'): ?> active <?php endif; ?>" href="<?php echo e(url('alerts')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Alerts.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Alerts</span>
                                        </a>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if(!empty($permission) && $permission[34]['permission_status'] == 1 ): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'manage-vehicles'): ?> active <?php endif; ?>" href="<?php echo e(url('vehicles')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Vehicles.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Manage Vehicles</span>
                                        </a>
                                    </div>

                                <?php endif; ?>

                                <?php if(!empty($permission) && $permission[35]['permission_status'] == 1): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link <?php if($title == 'login-history' || $title == 'login-activity'): ?> active <?php endif; ?>" href="<?php echo e(url('login-history')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Login History.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Login History</span>
                                        </a>
                                    </div>

                                <?php endif; ?>

                                <?php if(!empty($permission) && $permission[37]['permission_status'] == 1): ?>

                                    <div class="menu-item search-item">
                                        <a class="menu-link <?php if($title == 'system-errors'): ?> active <?php endif; ?>" href="<?php echo e(url('system-error-logs')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/System Error Logs.png')); ?>" />
                                            </span>
                                            <span class="menu-title">System Error Logs</span>
                                        </a>
                                    </div>

                                <?php endif; ?>
                                <?php if(!empty($permission) && $permission[46]['permission_status'] == 1): ?>
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'help-desk'): ?> active <?php endif; ?>" href="<?php echo e(url('/all-tickets')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Help Desk.png')); ?>" />
                                            </span>
                                            <span class="menu-title">All Help Desk</span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if(!empty($permission) && $permission[11]['permission_status'] == 1): ?>
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'my-help-desk'): ?> active <?php endif; ?>" href="<?php echo e(url('my-tickets')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Help Desk.png')); ?>" />
                                            </span>
                                            <span class="menu-title">My Help Desk</span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if(!empty($permission) && $permission[53]['permission_status'] == 1 ): ?>
                                
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'link-post'): ?> active <?php endif; ?>"  href="<?php echo e(url('/linked-in-post')); ?>" >
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Linkedin.png')); ?>" />
                                            </span>
                                            <span class="menu-title">LinkedIn Post</span>
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <?php if(!empty($permission) && $permission[57]['permission_status'] == 1 ): ?>
                                    <div class="menu-item search-item">
                                        <a class="menu-link nav-link <?php if($title == 'organogram'): ?> active <?php endif; ?>"  href="<?php echo e(url('/organogram')); ?>">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Linkedin.png')); ?>" />
                                            </span>
                                            <span class="menu-title">Organogram</span>
                                        </a>
                                    </div>
                                <?php endif; ?>
                               
                            </div>
                        </div>
                    <?php endif; ?>
      
                    <?php else: ?>

                        <?php if(!empty($permission) && ($permission[12]['permission_status'] == 1 || $permission[12]['permission_status'] == 1 || $permission[14]['permission_status'] == 1  ||  $permission[15]['permission_status'] == 1  ||  $permission[52]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">EMPLOYEES</span>
                                </div>
                            </div>

                            <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-employee <?php if($title == 'employee' || $title == 'employee-managers' || $title == 'birthdays' || $title == 'work-anniversay' || $title == 'employee-devices'): ?> show <?php endif; ?>">

                                <span class="menu-link">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Employees MDM.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Employee MDM</span>
                                    <span class="menu-arrow"></span>
                                </span>

                                <div class="menu-sub menu-sub-accordion menu-active-bg">

                                    <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'employee'): ?> active <?php endif; ?>" href="<?php echo e(url('/employees')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title ">Manage Employees</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[13]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link <?php if($title == 'employee-managers'): ?> active <?php endif; ?>" href="<?php echo e(url('/employees-managers')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>

                                                <span class="menu-title ">Employees Managers</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>



                                    <?php if(!empty($permission) && !empty($permission[14]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'birthdays'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-birthdays')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Employees Birthday</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>
                                    
                                    


                                    <?php if(!empty($permission) && !empty($permission[15]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'work-anniversay'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-work-anniversay')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Work Anniversery</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    <?php if(!empty($permission) && !empty($permission[52]['permission_status'] == 1)): ?>

                                        <div class="menu-item search-item">
                                            <a class="menu-link nav-link <?php if($title == 'employee-devices'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-devices')); ?>">
                                                <span class="menu-bullet">
                                                    <i class="far fa-circle nav-icon"></i>
                                                </span>
                                                <span class="menu-title">Employees Devices</span>
                                            </a>
                                        </div>

                                    <?php endif; ?>

                                    
                                </div>


                            </div>

                        <?php endif; ?>

                        <?php if(!empty($permission) && !empty($permission[54]['permission_status'] == 1)): ?>
                            
                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'shift-management'): ?> active <?php endif; ?>" href="<?php echo e(url('shift-management')); ?>" >
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Mark Attendance.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Shift Management</span>
                                </a>
                            </div>

                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && ($permission[19]['permission_status'] == 1 || $permission[19]['permission_status'] == 1 || $permission[20]['permission_status'] == 1 || $permission[1]['permission_status'] == 1 || $permission[21]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">ATTENDANCE & REQUEST</span>
                                </div>
                            </div>
                        
                        <?php endif; ?>

                    
                        <div class="menu-item search-item">
                            <a class="menu-link nav-link <?php if($title == 'mark-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('mark-attendance')); ?>" target="blank">
                                <span class="menu-icon">
                                    <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Mark Attendance.png')); ?>" />
                                </span>
                                <span class="menu-title">Mark Attendance</span>
                            </a>
                        </div>
                    
                        <?php if(!empty($permission) && ($permission[19]['permission_status'] == 1 || $permission[20]['permission_status'] == 1 || $permission[21]['permission_status'] == 1 || $permission[1]['permission_status'] == 1 || $permission[2]['permission_status'] == 1)): ?> 

                            <?php if(!empty($permission) && !empty($permission[19]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'manage-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('attendance')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Attendance.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Attendance</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[21]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'daily-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('daily-attendance-report')); ?>">
                                        <span class="menu-icon">

                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Attendance Report.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Daily Attendance Report</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[56]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'overtime-management'): ?> active <?php endif; ?>" href="<?php echo e(url('overtime-management')); ?>">
                                        <span class="menu-icon">

                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Attendance Report.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Overtime Sheet</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[1]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-attendance'): ?> active <?php endif; ?>" href="<?php echo e(url('my-attendance')); ?>">
                                        <span class="menu-icon">
                                            <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Attendance.png')); ?>" />
                                            </span>
                                        </span>
                                        <span class="menu-title">My Attendance</span>
                                    </a>
                                </div>
                                
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[20]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'attendance-request'): ?> active <?php endif; ?>" href="<?php echo e(url('attendance-requests')); ?>" >
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Attendance Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Attendance Requests</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[2]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-attendance-request'): ?> active <?php endif; ?>" href="<?php echo e(url('my-attendance-request')); ?>" >
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Attendance Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Attendance Requests</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && ($permission[3]['permission_status'] == 1 || $permission[23]['permission_status'] == 1 || $permission[24]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">LEAVES & REQUEST</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[23]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'employees-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('employees-leaves')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Leave Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Leaves Requests</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[3]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('/my-leaves')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Leave Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Leaves Requests</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[24]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'manage-leaves'): ?> active <?php endif; ?>" href="<?php echo e(url('manage-leaves')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Leave Entilement.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Leaves Entitlement</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && ($permission[7]['permission_status'] == 1 || $permission[22]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">REMOTE WORK REQUESTS</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[22]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'wfh-request'): ?> active <?php endif; ?>" href="<?php echo e(url('wfh-requests')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All WFH Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Remote Work Requests</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[7]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-wfh-requests'): ?> active <?php endif; ?> " href="<?php echo e(url('my-wfh-requests')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My WFH Requests.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Remote Work Request</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[4]['permission_status'] == 1 || $permission[25]['permission_status'] == 1 || $permission[26]['permission_status'] == 1 || $permission[51]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">INTERVIEWS</span>
                                </div>
                            </div>


                            <?php if(!empty($permission) && !empty($permission[25]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'manage-interviews'): ?> active <?php endif; ?>" href="<?php echo e(url('interviews')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Interviews</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                            
                            <?php if(!empty($permission) && !empty($permission[51]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link  <?php if($title == 'interview-candidate-list'): ?> active <?php endif; ?>" href="<?php echo e(url('/candiddate-interviews')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Interview Candidates</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[4]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-interviews'): ?> active <?php endif; ?>" href="<?php echo e(url('my-interviews')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Interviews.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Interviews</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[26]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link  <?php if($title == 'employee-on-boarding'): ?> active <?php endif; ?>" href="<?php echo e(url('/employee-onboarding')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Interviews.png')); ?>" />
                                        </span>
                                        <span class="menu-title">OnBoarding Employees</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                        
                        <?php endif; ?>
                        

                        <?php if(!empty($permission) && ($permission[27]['permission_status'] == 1 || $permission[5]['permission_status'] == 1 || $permission[9]['permission_status'] == 1 || $permission[43]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">PAYSLIPS</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[27]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'Payroll'): ?> active <?php endif; ?>" href="<?php echo e(url('payroll')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Payslips.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Payroll</span>
                                    </a>
                                </div>

                            <?php endif; ?>


                            <?php if(!empty($permission) && !empty($permission[5]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'My Payslip'): ?> active <?php endif; ?>" href="<?php echo e((session('my_payroll') == "allow") ? url('my-payroll') : '#'); ?>" data-bs-toggle="<?php echo e((session('my_payroll') == "allow") ? '' : 'modal'); ?>" data-bs-target="#payslip_authentication_process">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Payslips.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Payslips</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[43]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'all-salary-request'): ?> active <?php endif; ?>" href="<?php echo e(url('all-salary-request')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Advance Salary Request</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[9]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-salary-request'): ?> active <?php endif; ?>" href="<?php echo e(url('my-salary-request')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Salary Request</span>
                                    </a>
                                </div>
                            <?php endif; ?> 
                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[47]['permission_status'] == 1 || $permission[48]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Income Tax</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && $permission[47]['permission_status'] == 1 ): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'Tax Slab'): ?> active <?php endif; ?>" href="<?php echo e(url('/tax-slab')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Income Tax.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Income Tax</span>
                                    </a>
                                </div>
                            <?php endif; ?>


                            <?php if(!empty($permission) && $permission[48]['permission_status'] == 1): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'Tax Collection'): ?> active <?php endif; ?>" href="<?php echo e(url('/tax-collection')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Tax Collection.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Income Tax Collection</span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        
                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[16]['permission_status'] == 1 || $permission[17]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">

                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">GADGETS</span>
                                </div>

                            </div>

                            <?php if(!empty($permission) && !empty($permission[16]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">

                                    <a class="menu-link nav-link  <?php if($title == 'gadgets-inventory'): ?> active <?php endif; ?>" href="<?php echo e(url('/gadgets-inventory')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Gadgets Inventory.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Gadgets Inventory</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[17]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">

                                    <a class="menu-link nav-link  <?php if($title == 'gadgets-allotment'): ?> active <?php endif; ?>" href="<?php echo e(url('/gadgets-allotment')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Gadgets Allotment.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Gadgets Allotment</span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        

                        <?php if(!empty($permission) && ($permission[42]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">COMPANY LETTERS</span>
                                </div>

                            </div>
                            
                            <div class="menu-item search-item">
                                <a class="menu-link nav-link  <?php if($title == 'letters'): ?> active <?php endif; ?>" href="<?php echo e(url('/letters')); ?>">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Letters.png')); ?>" />
                                    </span>
                                    <span class="menu-title">All Letters</span>
                                </a>
                            </div>
                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[6]['permission_status'] == 1 || $permission[18]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">MEETINGS</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[18]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'all-meetings'): ?> active <?php endif; ?>" href="<?php echo e(url('/meetings')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Meetings.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Meetings</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                            <?php if(!empty($permission) && !empty($permission[6]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item"> 
                                    <a class="menu-link nav-link <?php if($title == 'my-meetings'): ?> active <?php endif; ?>" href="<?php echo e(url('/my-meetings')); ?>">
                                        <?php if($meetings == 1): ?>  
                                            <span class="menu-icon pulse pulse-primary">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Meetings.png')); ?>" />
                                                <span class="pulse-ring"></span>
                                            </span>
                                        <?php else: ?>
                                                <span class="menu-icon">
                                                <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Meetings.png')); ?>" />
                                            </span>
                                        <?php endif; ?>  
                                        <span class="menu-title">My Meetings</span> 
                                    </a>
                                </div>

                            <?php endif; ?>

                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[28]['permission_status'] == 1 || $permission[29]['permission_status'] == 1 || $permission[58]['permission_status'] == 1  || $permission[55]['permission_status'] == 1 || $permission[58]['permission_status'] == 1)): ?>

                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">EXPENSES</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[28]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'cash'): ?> active <?php endif; ?>" href="<?php echo e(url('petty-cash')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Cash Inventory.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Cash Inventory</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[29]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'expense'): ?> active <?php endif; ?>" href="<?php echo e(url('daily-expense')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Daily Expenses</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[55]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'employee-expense'): ?> active <?php endif; ?>" href="<?php echo e(url('employee-expense')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Reimbursement Request</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[58]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-expense'): ?> active <?php endif; ?>" href="<?php echo e(url('my-expense')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Daily Expenses.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Reimbursement Request</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[8]['permission_status'] == 1 || $permission[38]['permission_status'] == 1)): ?>   
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Resignation</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[38]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'all-resignation'): ?> active <?php endif; ?>" href="<?php echo e(url('resignations')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Resignation.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Resignation</span>
                                    </a>
                                </div>

                            <?php endif; ?>


                            <?php if(!empty($permission) && !empty($permission[8]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'resignation'): ?> active <?php endif; ?>" href="<?php echo e(url('employee-resignation')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Resignation.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Resignation</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if(!empty($permission) && !empty($permission[39]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Alerts</span>
                                </div>
                            </div>

                        
                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'Alerts'): ?> active <?php endif; ?>" href="<?php echo e(url('alerts')); ?>">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Alerts.png')); ?>" />
                                    </span>
                                    <span class="menu-title">All Alerts</span>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && ($permission[40]['permission_status'] == 1 || $permission[41]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">

                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Requisition</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && !empty($permission[40]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'all-requisition'): ?> active <?php endif; ?>" href="<?php echo e(url('requisition')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Requisition</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[41]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-requisition'): ?> active <?php endif; ?>" href="<?php echo e(url('my-requisition')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Requisition</span>
                                    </a>
                                </div>
                            <?php endif; ?> 
                        <?php endif; ?>  

                        <?php if(!empty($permission) && !empty($permission[10]['permission_status'] == 1 || !empty($permission[30]['permission_status'] == 1) || !empty($permission[44]['permission_status'] == 1))): ?>
                            <div class="menu-item search-item">

                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Loans</span>
                                </div>
                            </div>
                            
                            <?php if(!empty($permission) && !empty($permission[30]['permission_status'] == 1)): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'manage-loan'): ?> active <?php endif; ?>" href="<?php echo e(url('loans')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Loans.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Loans</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                            <?php if(!empty($permission) && !empty($permission[44]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'all-loan-request'): ?> active <?php endif; ?>" href="<?php echo e(url('all-loan-request')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Loan Request</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && !empty($permission[10]['permission_status'] == 1)): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-loan'): ?> active <?php endif; ?>" href="<?php echo e(url('my-loan')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Requisition.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Loan Request</span>
                                    </a>
                                </div>
                        
                            <?php endif; ?> 
                        <?php endif; ?>
                    

                        <?php if(!empty($permission) && ($permission[31]['permission_status'] == 1 || $permission[32]['permission_status'] == 1 || $permission[33]['permission_status'] == 1  || $permission[34]['permission_status'] == 1  || $permission[35]['permission_status'] == 1  || $permission[36]['permission_status'] == 1  || $permission[37]['permission_status'] == 1)): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">MISCELLANEOUS</span>
                                </div>
                            </div>


                            <?php if(!empty($permission) && !empty($permission[31]['permission_status'] == 1 )): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'holidays'): ?> active <?php endif; ?>" href="<?php echo e(url('holidays')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Holidays.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Holidays</span>
                                    </a>
                                </div>
                            <?php endif; ?>

                            <?php if(!empty($permission) && ($permission[32]['permission_status'] == 1 || $permission[33]['permission_status'] == 1 )): ?>
                                <div data-kt-menu-trigger="click" class="menu-item search-item menu-accordion main-menu-dpt-desgn <?php if($title == 'manage-departments' || $title == 'manage-designations'): ?> show <?php endif; ?>">

                                    <span class="menu-link">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Help Desk.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Departs & Desigs</span>
                                        <span class="menu-arrow"></span>
                                    </span>

                                    <div class="menu-sub menu-sub-accordion menu-active-bg">


                                        <?php if(!empty($permission) && !empty($permission[32]['permission_status'] == 1)): ?>

                                            <div class="menu-item search-item">
                                                <a class="menu-link nav-link <?php if($title == 'manage-departments'): ?> active <?php endif; ?>" href="<?php echo e(url('departments')); ?>">
                                                    <span class="menu-bullet">
                                                        <i class="far fa-circle nav-icon"></i>
                                                    </span>
                                                    <span class="menu-title">Manage Departments</span>
                                                </a>
                                            </div>

                                        <?php endif; ?>



                                        <?php if(!empty($permission) && !empty($permission[33]['permission_status'] == 1)): ?>

                                            <div class="menu-item search-item">
                                                <a class="menu-link nav-link <?php if($title == 'manage-designations'): ?> active <?php endif; ?>" href="<?php echo e(url('designations')); ?>">
                                                    <span class="menu-bullet">
                                                        <i class="far fa-circle nav-icon"></i>
                                                    </span>
                                                    <span class="menu-title">Manage Designations</span>
                                                </a>
                                            </div>

                                        <?php endif; ?>

                                    </div>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && $permission[34]['permission_status'] == 1 ): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'manage-vehicles'): ?> active <?php endif; ?>" href="<?php echo e(url('vehicles')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Manage Vehicles.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Manage Vehicles</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && $permission[35]['permission_status'] == 1): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link <?php if($title == 'login-history' || $title == 'login-activity'): ?> active <?php endif; ?>" href="<?php echo e(url('login-history')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Login History.png')); ?>" />
                                        </span>
                                        <span class="menu-title">Login History</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                            <?php if(!empty($permission) && $permission[36]['permission_status'] == 1): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link <?php if($title == 'system-settings'): ?> active <?php endif; ?>" href="<?php echo e(url('system-settings')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/System Settings.png')); ?>" />
                                        </span>
                                        <span class="menu-title">System Settings</span>
                                    </a>
                                </div>

                            <?php endif; ?>
                            <?php if(!empty($permission) && $permission[37]['permission_status'] == 1): ?>

                                <div class="menu-item search-item">
                                    <a class="menu-link <?php if($title == 'system-errors'): ?> active <?php endif; ?>" href="<?php echo e(url('system-error-logs')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/System Error Logs.png')); ?>" />
                                        </span>
                                        <span class="menu-title">System Error Logs</span>
                                    </a>
                                </div>

                            <?php endif; ?>

                        <?php endif; ?>

                            
                        <?php if(!empty($permission) && ($permission[11]['permission_status'] == 1 || $permission[46]['permission_status'] == 1 )): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Help Desk</span>
                                </div>
                            </div>

                            <?php if(!empty($permission) && $permission[46]['permission_status'] == 1): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'help-desk'): ?> active <?php endif; ?>" href="<?php echo e(url('/all-tickets')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Help Desk.png')); ?>" />
                                        </span>
                                        <span class="menu-title">All Help Desk</span>
                                    </a>
                                </div>
                            <?php endif; ?>


                            <?php if(!empty($permission) && $permission[11]['permission_status'] == 1): ?>
                                <div class="menu-item search-item">
                                    <a class="menu-link nav-link <?php if($title == 'my-help-desk'): ?> active <?php endif; ?>" href="<?php echo e(url('my-tickets')); ?>">
                                        <span class="menu-icon">
                                            <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/My Help Desk.png')); ?>" />
                                        </span>
                                        <span class="menu-title">My Help Desk</span>
                                    </a>
                                </div>
                            <?php endif; ?>
                        
                        <?php endif; ?>

                        <?php if(!empty($permission) && $permission[49]['permission_status'] == 1 ): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Office Rooms</span>
                                </div>
                            </div>

                        
                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'manage-rooms'): ?> active <?php endif; ?>" href="<?php echo e(url('/rooms')); ?>">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/All Rooms.png')); ?>" />
                                    </span>
                                    <span class="menu-title">All Rooms</span>
                                </a>
                            </div>
                            
                        <?php endif; ?>

                        <?php if(!empty($permission) && $permission[50]['permission_status'] == 1 ): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Office Locations</span>
                                </div>
                            </div>

                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'manage-locations'): ?> active <?php endif; ?>" href="<?php echo e(url('/locations')); ?>">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Location.png')); ?>" />
                                    </span>
                                    <span class="menu-title">All Locations</span>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && $permission[53]['permission_status'] == 1 ): ?>
                            <div class="menu-item search-item">
                                <div class="menu-content">
                                    <span class="menu-heading fw-bold text-uppercase fs-7">Post</span>
                                </div>
                            </div>
                            

                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'link-post'): ?> active <?php endif; ?>"  href="<?php echo e(url('/linked-in-post')); ?>" >
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Linkedin.png')); ?>" />
                                    </span>
                                    <span class="menu-title">LinkedIn Post</span>
                                </a>
                            </div>
                        <?php endif; ?>

                        <?php if(!empty($permission) && $permission[57]['permission_status'] == 1 ): ?>
                            <div class="menu-item search-item">
                                <a class="menu-link nav-link <?php if($title == 'organogram'): ?> active <?php endif; ?>"  href="<?php echo e(url('/organogram')); ?>">
                                    <span class="menu-icon">
                                        <img class="sidebar-icon" src="<?php echo e(asset('portal_assets/sidebar_icons/Linkedin.png')); ?>" />
                                    </span>
                                    <span class="menu-title">Organogram</span>
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
                
            </div>
            
        </div>

    </div>
        
        
<?php $__env->startPush('js-link'); ?>
    <script>
    $("#serachMenu").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $(".search-item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            let get_value = $('#serachMenu').val();
           
            if(get_value.length > 0){
                $('.main-menu-employee').addClass('show');
                $('.main-menu-dpt-desgn').addClass('show');
            }else{
                $('.main-menu-employee').removeClass('show');
                $('.main-menu-dpt-desgn').removeClass('show');
            }   
        });
    });
        
    </script>
        
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>