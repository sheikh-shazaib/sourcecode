

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>


    <div class="d-flex flex-column flex-column-fluid">
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">

            <div class="app-container col-12 d-flex flex-stack">
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">System Settings</h1>
                
                </div>
        
            </div>
        </div>
        <div class="app-content flex-column-fluid">
            <div class="app-container">

                <form id="hrm_setting" class="form " autocomplete="off">
                    <?php echo csrf_field(); ?>  
                    <div class="row">
                        <div class="d-flex justify-content-end mb-8">
                            <?php if(!empty($setting)): ?>
                                <button type="submit" id="submit_btn" class="btn btn-success">
                                    <input type="hidden"  name="form_status" value="update" />
                                    <span class="indicator-label">Update Changes</span>    
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            <?php endif; ?>
                        </div>
                        <input type="hidden" name="setting_id" value="<?php echo e($setting[0]['setting_id'] ?? ''); ?>" />
                        <div class="col-md-4 card mb-5">
                            <div class="card-body">
                                <div class="d-flex flex-column ">
                                    <div class="card card-flush">
                                        <div class="card-header" style="justify-content: center !important">
                                            <div class="card-title">
                                                <h2 >Company Logo</h2>
                                            </div>
                                        </div>
                                        <div class="card-body text-center pt-0">
                                            
                                            <div class="image-input image-input-empty image-input-outline image-input-placeholder mb-3" data-kt-image-input="true">
                                                <div class="image-input-wrapper w-150px h-150px main-div " style="background-image: url('<?php echo e(URL('portal_assets/setting/images/'.$setting[0]['company_logo'])); ?>')">
                                                </div>
                                                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change logo">
                                                    <i class="bi bi-pencil-fill fs-7"></i>
                                                    <input type="file" name="company_logo" accept=".png, .jpg, .jpeg"  id="file"/>
                                                </label>
                                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow"  data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel logo">
                                                    <i class="bi bi-x fs-2"></i>
                                                </span>
                                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove logo">
                                                    <i class="bi bi-x fs-2"></i>
                                                </span>
                                            </div>
                                            <div class="text-muted fs-7">This logo will diaplay as a company's primary logo in system. Only *.png, *.jpg and *.jpeg image files are accepted.</div>
                                        </div>
                                    </div>
        
                                    <div class="card card-flush">
                                        <div class="card-header" style="justify-content: center !important">
                                           
                                            <div class="card-title" >
                                                <h2>Company Favicon</h2>
                                            </div>
                                        </div>
                                        <div class="card-body text-center pt-0">
                                            <div class="image-input image-input-empty image-input-outline image-input-placeholder mb-3" data-kt-image-input="true">
                                                <div class="image-input-wrapper w-150px h-150px " style="background-image: url('<?php echo e(URL('portal_assets/setting/images/'.$setting[0]['company_favicon'])); ?>')">
                                                </div>
                                                <label class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow " data-kt-image-input-action="change" data-bs-toggle="tooltip" title="Change favicon">
                                                    <i class="bi bi-pencil-fill fs-7"></i>
                                                    <input type="file" name="company_favicon" accept=".png, .jpg, .jpeg" />
                                            
                                                </label>
                                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="cancel" data-bs-toggle="tooltip" title="Cancel favicon">
                                                    <i class="bi bi-x fs-2"></i>
                                                </span>
                                                <span class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-body shadow" data-kt-image-input-action="remove" data-bs-toggle="tooltip" title="Remove favicon">
                                                    <i class="bi bi-x fs-2"></i>
                                                </span>
                                            </div>
                                            <div class="text-muted fs-7">This image will display as your favicon. Only *.png, *.jpg and *.jpeg image files are accepted.</div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="col-md-8">
                            <div class="card card-flush">
                                <div class="card-header card-header-stretch">
                                    <div class="card-title d-flex">
                                    </div>
                                    <div class="card-toolbar m-0">
                                        <ul class="nav nav-tabs nav-line-tabs nav-stretch fs-6 border-0 fw-bold"
                                            role="tablist">
                                            <li class="nav-item" role="presentation">
                                                <a id="general-settings-tabs" class="tab-nav nav-link  text-active-gray-800 active" data-bs-toggle="tab" role="tab" href="#general-settings-tab">General Settings</a>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <a id="attendance-settings-tabs" class="tab-nav nav-link justify-content-center text-active-gray-800" data-bs-toggle="tab" role="tab" href="#attendance-settings-tab">Attendance Settings</a>
                                            </li>
                                            <li class="nav-item" role="presentation">
                                                <a id="payroll-settings-tabs"  class="tab-nav nav-link justify-content-center text-active-gray-800" data-bs-toggle="tab" role="tab" href="#payroll-settings-tab">Payroll Settings</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-body pt-5">
                                    <div class="tab-content" id="custom-tabs-four-tabContent2">
                                        <div class="tab-panel card-body p-0 tab-pane fade show active" id="general-settings-tab"
                                            role="tabpanel" aria-labelledby="general-settings-tabs">
                                            <div class="card card-flush py-4">
                                                <div class="card-header">
                                                    <div class="card-title">
                                                        <h2>General Settings</h2>
                                                    </div>
                                                </div>
                                                <div class="card-body pt-0">
                                                    <div class="mb-4">
                                                        <label class="required form-label">Company Name</label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="This company name will display all over system. For e.g on sidebar etc."></i>
                                                        <input type="text" class="form-control mb-2" name="company_name"  value="<?php echo e($setting[0]['company_name'] ?? ''); ?>" placeholder="Enter Company Name"  />
                                                        
                                                    </div>
                
                                                    <div class="mb-4">
                                                        <label class="required form-label">Company Primary Email</label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="This company email will display all over system."></i>
                                                        <input type="text" class="form-control mb-2" name="company_email"  value="<?php echo e($setting[0]['company_email'] ?? ''); ?>" placeholder="Enter Company Email" required />
                                                        
                                                    </div>
        
                                                    <div class="mb-4">
                                                        <label class="required form-label">Company Address</label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="This company name will display all over system."></i>
                                                        <input type="text" class="form-control mb-2" name="company_address"  value="<?php echo e($setting[0]['company_address'] ?? ''); ?>" placeholder="Enter Company Address" required />
                                                        
                                                    </div>
                
                                                    <div class="mb-4">
                                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                            <span>Use primary email for email alerts and notifications</span>                                                        
                                                            </label>
                                                            <div class="d-flex align-items-center">
                                                                <label class="form-check form-check-custom me-10">
                                                                    <input class="form-check-input h-20px w-20px" type="checkbox"  name="email_permission" value="1"  <?php if(!empty($setting[0]['company_email_permission']) && $setting[0]['company_email_permission'] == 1): ?> checked <?php endif; ?> />
                                                                
                                                                </label>
                                                            </div>
                                                        
                                                        </div>
                                                    
                                                    
                                                    <div class="mb-4">
                                                        <label class="required form-label">Check In Grace Time </label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Check in grace time for late marking. Grace time should be in minutes greater and equals to 0 minutes and less and equals to 60 minutes."></i>
                                                        <input type="number" name="check_in_grace_time" class="form-control mb-2" value="<?php echo e($setting[0]['check_in_flexibility_time'] ?? ''); ?>" placeholder="Value should be in minutes" min="0" max="60" required/>
                                                    </div>
                
                                                    <div class="mb-4">
                                                        <label class="required form-label">Check Out Grace Time</label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Check out grace time for early checkout or half day. Grace time should be in minutes greater and equals to 0 minutes and less and equals to 60 minutes."></i>
                                                        <input type="number" name="check_out_grace_time" class="form-control mb-2"  value="<?php echo e($setting[0]['check_out_flexibility_time'] ?? ''); ?>" placeholder="Value should be in minutes" min="0" max="60" required/>
                                                    </div>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                    
                                        <div class="tab-panel card-body p-0 tab-pane fade show" id="attendance-settings-tab"
                                            role="tabpanel" aria-labelledby="attendance-settings-tabs">
                                            <div class="card card-flush py-4">
                                                <div class="card-header">
                                                    <div class="card-title">
                                                        <h2>Attendance Devices</h2> &nbsp; 
                                                        <span class="text-gray-400 mt-1 fw-semibold fs-8">(Attendance can be performed only through registered IP Addresses)</span>
                                                    </div>
                                                    <div class="card-toolbar" >
                                                        <button class="btn btn-primary btn-sm" type="button" id="add_new_ip_address"><i class="fa fa-plus"></i>Add New IP Address</button>
                                                    </div>
                                                </div>
                                                <?php $count = 0 ?>
                                                <?php if(!empty($mac_address)): ?>
                                                
                                                    <div class="card-body" id="ip_div">
                                                        <?php $__currentLoopData = $mac_address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $index = ++ $count; ?>
                                                            <div class="row mb-4">
                                                                <label class="form-label">IP Address <?php echo e($index); ?></label>
                                                                <div class="col-sm-11">
                                                                    <input type="text" class="form-control mb-2" name="mac_address[]" value="<?php echo e($mac['mac_address']); ?>" placeholder="Enter IP Address <?php echo e($index); ?>" required/>
                                                                </div>
                                                                <?php if($index > 1): ?>
                                                                    <div class="col-sm-1">
                                                                        <a href="javascript:void(0);" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm" onclick="deactivate_confirm('<?php echo e(url('system-settings/discard_mac_address') . '/' . $mac['address_id']); ?>')">
                                                                            <span class="svg-icon svg-icon-3">
                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                                                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                                                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                                                </svg>
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="tab-panel card-body p-0 tab-pane fade show" id="payroll-settings-tab"
                                            role="tabpanel" aria-labelledby="payroll-settings-tabs">
                                            <div class="card card-flush py-4">
                                                <div class="card-header">
                                                    <div class="card-title">
                                                        <h2>Payroll Settings</h2>
                                                    </div>
                                                </div>
                                                <div class="card-body pt-0">
                                                    <div class="mb-4">
                                                        <label class="required form-label">Payroll Start Period</label>
                                                        <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Payroll Period Date ."></i>
                                                        <?php if(empty($setting) || empty($setting[0]['payroll_start_date'])): ?>
                                                            <input type="number" class="form-control mb-2" value="<?php echo e($setting[0]['payroll_start_date']); ?>"  name="payroll_start_date"  />
                                                        <?php else: ?>
                                                            <input type="number" class="form-control mb-2" value="<?php echo e($setting[0]['payroll_start_date']); ?>"  disabled min="1" max="28" required />
                                                        <?php endif; ?>
                                                      
                                                        
                                                    </div>

                                                    <div class="row">

                                                        <div class="col-md-6 mb-4">
                                                            <label class="required form-label">Tax Fiscal Start Date</label>
                                                            <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Tax Fiscal Start Date ."></i>
                                                            <input type="date" class="form-control mb-2" name="fiscal_date" id="fiscal_start_date" value="<?php echo e($setting[0]['fiscal_date']); ?>"   required />
                                                          
                                                            
                                                        </div>
                                                        
                                                        <div class="col-md-6 mb-6">
                                                            <?php   $date = date('Y-m-d', strtotime('+1 year -1 day', strtotime($setting[0]['fiscal_date'])) );
                                                           ?>
                                                            <label class="required form-label">Tax Fiscal End Date</label>
                                                            <i class="fas fa-exclamation-circle ms-2 fs-7" data-bs-toggle="tooltip" title="Tax Fiscal End Date ."></i>
                                                            <input type="date" class="form-control mb-2" id="fiscal_end_date"  value="<?php echo e($date); ?>"   readonly />
                                                          
                                                            
                                                        </div>
                                                    </div>
                                                    
                
                                                    <div class="mb-4">
                                                        <label class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" name="club_rule" type="checkbox" value="1" <?php if(!empty($setting[0]['club_rule_apply']) && $setting[0]['club_rule_apply'] == 1): ?> checked="checked"  <?php endif; ?>/>
                                                            <span class="form-check-label fw-semibold text-muted">Club Rule Implentation on Payroll</span>
                                                        </label>
                                                    </div>
                                                    
                                                    <div class="mb-4">
                                                        <label class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" name="tax_deduction" type="checkbox" value="1"  <?php if(!empty($setting[0]['tax_deduction_apply']) && $setting[0]['tax_deduction_apply'] == 1): ?> checked="checked"  <?php endif; ?> />
                                                            <span class="form-check-label fw-semibold text-muted">Tax Deduction on Payroll</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    
                                    </div>
                                </div>
                            </div>

                        </div>
                    
                    </div>
                   
                </form>
            </div>
        </div>

    </div>



    <div class="modal fade" id="modal-danger" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <div class="modal-content bg-rounded">
                <div class="modal-header">
                    <h4 class="modal-title pl-4">Confirmation Alert</h4>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1 bg-white">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure to delete this IP Address ?</p>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:void(0);" class="btn btn-sm btn-primary" id="delete_button">Delete</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
    <script>

        const payroll_date = "<?php echo e($setting[0]['payroll_start_date']); ?>";

        function deactivate_confirm(delete_url) {
            console.log(delete_url);
            $('#modal-danger').modal('show');
            document.getElementById('delete_button').setAttribute("href",delete_url);
        }

        var ip_address_counter = 2 + <?php echo e($count-2); ?> ;
        $('#add_new_ip_address').click(function(){
            ip_address_counter = ++ip_address_counter;
            var row_for_append = `
                <div class="row mb-4">
                    <label class="form-label">IP Address ${ip_address_counter}</label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control mb-2" name="mac_address[]" placeholder="Enter IP Address ${ip_address_counter}" required/>
                    </div>
                    <div class="col-sm-1">
                        <a href="javascript:void(0);" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm" onClick="removeDiv(this)">
                            <span class="svg-icon svg-icon-3">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                    <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                    <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                </svg>
                            </span>
                        </a>
                    </div>
                </div>
            `;
            $('#ip_div').append(row_for_append);

        });

        function removeDiv(elem){
            $(elem).parent('div').parent('div').remove();
        }
        
        $('#submit_btn').click(function(){

            $('input:invalid').each(function () {
                var closest = $(this).closest('.tab-pane');
                var id = closest.attr('id');
                $('#'+id+'s').tab('show');
                return false;
            });

        })
        

        $('#hrm_setting').submit(function(e) {

            $('#submit_btn').prop('disabled', true);
            $("#submit_btn").attr('data-kt-indicator', 'on');
            $('#submit_btn').css('cursor', 'not-allowed');
            e.preventDefault();
            if(payroll_date){
                ajax_request();
            }else{
                swal.fire({
                    title: 'Confirmation Alert !',
                    text: 'Are you sure to set your Payroll Start Period ?',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText:'Yes',
                    cancelButtonText:'Cancel',
                }).then(function (value) { 
                    if (value.isConfirmed == true) {
                        ajax_request();
                    }else{
                        $('#submit_btn').prop('disabled', false);
                        $("#submit_btn").removeAttr('data-kt-indicator');
                        $('#submit_btn').css('cursor', 'pointer');
                        $('#payroll-settings-tabs').tab('show'); ;
                    }
                });
            }
        });

        function ajax_request(){
            $.ajax({
                url: '<?php echo e(url('system-settings/update-hrm-settings')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: $('#hrm_setting').serialize(),
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            window.location.href = "<?php echo e(url('system-settings')); ?>";
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 8000,
                        })
                        $('#submit_btn').prop('disabled', false);
                        $("#submit_btn").removeAttr('data-kt-indicator');
                        $('#submit_btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Internet Connection Problem',
                            timer: 3000,
                        })
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            });
        }
        
        $('#fiscal_start_date').change(function(){
            var date = $('#fiscal_start_date').val();
           
             const newDate = addOneYear(date);
            $('#fiscal_end_date').val(newDate);
        })
      
        function addOneYear(date) {
            var date = new Date(date);

            
            var year = date.getFullYear();
            var month = date.getMonth();
            var day = date.getDate();

            var fulldate = new Date(year + 1, month, day);

            var toDate = fulldate.toISOString().slice(0, 10);

            return toDate;

            }
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/miscellanous/hrm-settings.blade.php ENDPATH**/ ?>