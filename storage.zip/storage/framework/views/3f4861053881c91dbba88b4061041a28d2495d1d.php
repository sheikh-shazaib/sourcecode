

<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Interview Detail</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <?php if(empty($employee_onboarding[0]['onboarding_candidate_id'])): ?>
                    <div class="m-0">
                        <a href="javascript:void(0)" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#hired_interviewer">Confirm This Candidate</a>
                    </div>

                    <div class="m-0">
                        <a href="javascript:void(0)" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#schedule_interview">											
                            <span class="svg-icon svg-icon-2">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                    <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                                </svg>
                            </span>
                            Re-Schedule Interview</a>   
                    </div>
                <?php endif; ?>
               
                <div class="m-0">
                    <a href="javascript:void(0)" class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#interviewer_status">Change Interview Status</a>
                </div>

                <div class="m-0">
                     <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
                </div>
         
            </div>
           
        </div>
       
    </div>
    
    <div class="app-content flex-column-fluid">
      
        <div class="app-container">
            <div class="row mb-5">
                <div class="col-md-5 card scroll scroll-pull" data-scroll="true" data-wheel-propagation="true" style="height:1130px">
                    <div class="card card-flush">
                        <div class="card-body pt-5"  >
                            
                            <ul class="nav nav-pills nav-pills-custom row position-relative mx-0 mb-9"
                                id="custom-tabs-four-tab" role="tablist">

                                <li class="nav-item col mx-0 p-0">
                                    <a class="nav-link active d-flex justify-content-center w-100 border-0 h-100"
                                        id="custom-tabs-interview-detail-tab" data-bs-toggle="pill"
                                        href="#custom-tabs-interview-detail" role="tab"
                                        aria-controls="custom-tabs-interview-detail" aria-selected="true">
                                        <span class="nav-text text-gray-800 fw-bold fs-6 mb-3">Interview Detail</span>
                                        <span
                                            class="bullet-custom position-absolute z-index-2 bottom-0 w-100 h-4px bg-primary rounded"></span>
                                    </a>
                                </li>

                                <li class="nav-item col mx-0 px-0">
                                    <a class="nav-link d-flex justify-content-center w-100 border-0 h-100"
                                        id="custom-tabs-interview-status-tab" data-bs-toggle="pill"
                                        href="#custom-tabs-interview-status" role="tab"
                                        aria-controls="custom-tabs-interview-status" aria-selected="false">
                                        <span class="nav-text text-gray-800 fw-bold fs-6 mb-3">Status Log Activity</span>
                                        <span
                                            class="bullet-custom position-absolute z-index-2 bottom-0 w-100 h-4px bg-primary rounded"></span>
                                    </a>
                                </li>
                                <span class="position-absolute z-index-1 bottom-0 w-100 h-5px bg-light rounded"></span>
                            </ul>

                            <div class="tab-content"  id="custom-tabs-four-tabContent">

                                <div class="tab-pane fade show active" id="custom-tabs-interview-detail" role="tabpanel"
                                    aria-labelledby="custom-tabs-interview-detail-tab">

                                    <div class="card-body p-0">
                            
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview ID</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_id']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>

                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Requisition Reference</span>
                                                </div>
                                                    <span class="fs-6 fw-bold text-primary"> <?php echo e($interview[0]['requisition_reference']); ?> - <?php echo e($interview[0]['requisition_job_title']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Date</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_date']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Time</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e(date('h:i A', strtotime($interview[0]['interview_time'] ))); ?></span>
                                            </div>
                                        </div>
                                        
                                        
                                         <div class="separator separator-dashed my-4"></div>
                                        
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Duration Time</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e(($interview[0]['interview_duration'] )); ?> Minutes</span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Department</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['department_name']); ?></span>
                                            </div>
                                        </div>
                                    
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Job Title</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_jobtitle']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">1st Interviewer</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer1']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">2nd Interviewer</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary">
                                                <?php if(!empty($interview) && $interview[0]['interview_interviewer2']): ?>
                                                    <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer2']); ?>

                                                <?php else: ?>
                                                    N\A
                                                <?php endif; ?>
                                               
                                            </span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Round</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_round']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                             
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Interviewer Room No</span>
                                                 </div>
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_room_nbr']); ?></span>
                                            </div>
                                        </div>
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Candidate Name</span>
                                                </div>
                                            <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['candidate_name']); ?></span>
                                            </div>
                                        </div>
                                        
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                        
                                         
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Candidate CV</span>
                                                </div>
                                            <a href="<?php echo e(url('download-candidate-cv?path=interviews/'.$interview[0]['interview_candidate_cv'])); ?>&title=Download Candidate CV" target="_blank" class="btn btn-success">Download File</a>
                                            </div>
                                        </div>
                                        
                                        
                                         <div class="separator separator-dashed my-4"></div>

                                         <div class="d-flex flex-stack">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Candidate Contact No</span>
                                                 </div>
                                                
                                                
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['candidate_contact_no']); ?></span>
                                               
                                                
                                             </div>
                                            
                                         </div>
                                        
                                        
                                         <div class="separator separator-dashed my-4"></div>
                                        
                                         
                                         <div class="d-flex flex-stack">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Current Salary</span>
                                                 </div>
                                                
                                                
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_current_salary']); ?></span>
                                               
                                                
                                             </div>
                                            
                                         </div>
                                        
                                        
                                         <div class="separator separator-dashed my-4"></div>
                                        
                                         
                                         <div class="d-flex flex-stack">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Expected Salary</span>
                                                 </div>
                                                
                                                
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_expected_salary']); ?></span>
                                               
                                                
                                             </div>
                                            
                                         </div>
                                        
                                        
                                         <div class="separator separator-dashed my-4"></div>
                                        
                                         
                                         <div class="d-flex flex-stack">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Notice Period</span>
                                                 </div>
                                                
                                                
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_noticepriod']); ?></span>
                                               
                                                
                                             </div>
                                            
                                         </div>
                                        
                                        
                                        <div class="separator separator-dashed my-4"></div>
                                        
                                        <div class="d-flex flex-stack">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                             
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Created At</span>
                                                 </div>
                                             
                                             
                                             <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_scheduled_time']); ?></span>
                                             
                                             
                                             </div>
                                         
                                        </div>
            
                                        
                                        <div class="separator separator-dashed my-4"></div>
            
                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                            
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Status</span>
                                                </div>
                                            
                                            
                                            <span class="fs-6 fw-bold text-primary">N\A</span>
                                            
                                            
                                            </div>
                                        
                                        </div>

                                       
                                       <div class="separator separator-dashed my-4"></div>

                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                            
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Type</span>
                                                </div>
                                            
                                            
                                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_type']); ?></span>
                                            
                                            
                                            </div>
                                    
                                        </div>

                                        <div class="separator separator-dashed my-4"></div>

                                        <div class="d-flex flex-stack">
                                            <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                            
                                                <div class="flex-grow-1 me-2">
                                                    <span class="text-gray-800  fs-6 fw-bold">Interview Link</span>
                                                </div>

                                                <div class="ms-2">
                                                    <button type="button" class="btn btn-sm btn-icon btn-light btn-active-light-primary" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                                        
                                                        <span class="svg-icon svg-icon-5 m-0"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path opacity="0.3" d="M18.4 5.59998C18.7766 5.9772 18.9881 6.48846 18.9881 7.02148C18.9881 7.55451 18.7766 8.06577 18.4 8.44299L14.843 12C14.466 12.377 13.9547 12.5887 13.4215 12.5887C12.8883 12.5887 12.377 12.377 12 12C11.623 11.623 11.4112 11.1117 11.4112 10.5785C11.4112 10.0453 11.623 9.53399 12 9.15698L15.553 5.604C15.9302 5.22741 16.4415 5.01587 16.9745 5.01587C17.5075 5.01587 18.0188 5.22741 18.396 5.604L18.4 5.59998ZM20.528 3.47205C20.0614 3.00535 19.5074 2.63503 18.8977 2.38245C18.288 2.12987 17.6344 1.99988 16.9745 1.99988C16.3145 1.99988 15.661 2.12987 15.0513 2.38245C14.4416 2.63503 13.8876 3.00535 13.421 3.47205L9.86801 7.02502C9.40136 7.49168 9.03118 8.04568 8.77863 8.6554C8.52608 9.26511 8.39609 9.91855 8.39609 10.5785C8.39609 11.2384 8.52608 11.8919 8.77863 12.5016C9.03118 13.1113 9.40136 13.6653 9.86801 14.132C10.3347 14.5986 10.8886 14.9688 11.4984 15.2213C12.1081 15.4739 12.7616 15.6039 13.4215 15.6039C14.0815 15.6039 14.7349 15.4739 15.3446 15.2213C15.9543 14.9688 16.5084 14.5986 16.975 14.132L20.528 10.579C20.9947 10.1124 21.3649 9.55844 21.6175 8.94873C21.8701 8.33902 22.0001 7.68547 22.0001 7.02551C22.0001 6.36555 21.8701 5.71201 21.6175 5.10229C21.3649 4.49258 20.9947 3.93867 20.528 3.47205Z" fill="currentColor"></path>
                                                            <path d="M14.132 9.86804C13.6421 9.37931 13.0561 8.99749 12.411 8.74695L12 9.15698C11.6234 9.53421 11.4119 10.0455 11.4119 10.5785C11.4119 11.1115 11.6234 11.6228 12 12C12.3766 12.3772 12.5881 12.8885 12.5881 13.4215C12.5881 13.9545 12.3766 14.4658 12 14.843L8.44699 18.396C8.06999 18.773 7.55868 18.9849 7.02551 18.9849C6.49235 18.9849 5.98101 18.773 5.604 18.396C5.227 18.019 5.0152 17.5077 5.0152 16.9745C5.0152 16.4413 5.227 15.93 5.604 15.553L8.74701 12.411C8.28705 11.233 8.28705 9.92498 8.74701 8.74695C8.10159 8.99737 7.5152 9.37919 7.02499 9.86804L3.47198 13.421C2.52954 14.3635 2.00009 15.6417 2.00009 16.9745C2.00009 18.3073 2.52957 19.5855 3.47202 20.528C4.41446 21.4704 5.69269 21.9999 7.02551 21.9999C8.35833 21.9999 9.63656 21.4704 10.579 20.528L14.132 16.975C14.5987 16.5084 14.9689 15.9544 15.2215 15.3447C15.4741 14.735 15.6041 14.0815 15.6041 13.4215C15.6041 12.7615 15.4741 12.108 15.2215 11.4983C14.9689 10.8886 14.5987 10.3347 14.132 9.86804Z" fill="currentColor"></path>
                                                            </svg>
                    
                                                        </span>
                                                    </button>
                                                                
                                                    
                                                    <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-300px" data-kt-menu="true" style="">
                                                        
                                                        <div class="card card-flush">
                                                            <div class="card-body p-5">
                                                                
                                                                    <div class="d-flex flex-column text-start">
                                                                        <div class="d-flex mb-3">
                                                                                
                                                                            <span class="svg-icon svg-icon-2 svg-icon-success me-3"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                <path d="M9.89557 13.4982L7.79487 11.2651C7.26967 10.7068 6.38251 10.7068 5.85731 11.2651C5.37559 11.7772 5.37559 12.5757 5.85731 13.0878L9.74989 17.2257C10.1448 17.6455 10.8118 17.6455 11.2066 17.2257L18.1427 9.85252C18.6244 9.34044 18.6244 8.54191 18.1427 8.02984C17.6175 7.47154 16.7303 7.47154 16.2051 8.02984L11.061 13.4982C10.7451 13.834 10.2115 13.834 9.89557 13.4982Z" fill="currentColor"></path>
                                                                                </svg>
                                                                            </span>
                                                                                    
                                                                            <div class="fs-6 text-dark">Share Link Generated</div>           
                                                                        </div>  

                                                                        <div class="row">
                                                                        
                                                                            <div class="col-md-10">
                                                                                <input type="text" id="url"  class="form-control form-control-sm" value="<?php echo e($interview[0]['interview_link'] ?? 'N\A'); ?>" />
                                                                            </div>
                                                                            <div class="col-md-2">
                                                                                <button  class="btn btn-active-color-primary btn-icon btn-sm btn-outline-light" onclick="Copy();">
                                                                                    
                                                                                    <span class="svg-icon svg-icon-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                        <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="currentColor"></path>
                                                                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="currentColor"></path>
                                                                                        </svg>
                                                                                    </span>
                                                                                    
                                                                                </button>
                                                                            </div> 
                                                                       </div> 
                                                                        
                                                                        <div class="text-muted fw-normal mt-2 fs-8 px-2">Copy Link.</div> 
                                                                        
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                    </div>
                                                </div>                                            
                                            
                                            </div>
                                    
                                        </div>

                                        <div class="separator separator-dashed my-4"></div>
        
                                        <div class="d-flex flex-stack  mt-10">
                                             <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                             
                                                 <div class="flex-grow-1 me-2">
                                                     <span class="text-gray-800  fs-6 fw-bold">Scheduled By</span>
                                                 </div>
                                             
                                             
                                                    <span class="fs-6 fw-bold text-primary">
                                                    <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_created_by']); ?>

                                                    </span>
                                             
                                             
                                             </div>
                                         
                                        </div>
                                        
                                    </div>

                                </div>

                                <div class="tab-pane fade  " id="custom-tabs-interview-status" role="tabpanel"
                                    aria-labelledby="custom-tabs-vehicle-maintenance-tab">
                                    <div class="card-body p-0">

                                        <?php if(!empty($interview_status)): ?>
                                            <?php $__currentLoopData = $interview_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="d-flex flex-stack">
                                                    <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                                        
                                                        <div class="flex-grow-1 me-2">
                                                            <span class="text-gray-800  fs-6 fw-bold">
                                                                <?php echo CustomHelper::getEmpProfileDiv($interview_status['interview_status_created_by']); ?>

                                                            </span>
                                                        </div>
                                                        <?php if($interview_status['interview_status_level'] == 'Interview Scheduled'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Interview Scheduled</span>
                                                        <?php elseif($interview_status['interview_status_level'] == 'Hold for more interviews'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Hold for more Interviews</span>
                                                    
                                                        <?php elseif($interview_status['interview_status_level'] == 'Candidate Shortlisted'): ?>
                                                            <span class="badge badge-light-danger font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Candidate Shortlisted</span>
                                                        <?php elseif($interview_status['interview_status_level'] == 'Candidate Rejected'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Candidate Rejected</span>

                                                        <?php elseif($interview_status['interview_status_level'] == 'Offer Placed'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Offer Placed</span>
                                                        <?php elseif($interview_status['interview_status_level'] == 'Offer Rejected'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Offer Rejected</span>
                                                        <?php elseif($interview_status['interview_status_level'] == "Candidate didn't Appeared"): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Candidate didn't Appeared</span>
                                                        <?php elseif($interview_status['interview_status_level'] == 'Candidate Hired'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Candidate Hired</span>
                                                        <?php elseif($interview_status['interview_status_level'] == 'Interview Cancelled'): ?>
                                                            <span class="badge badge-light-success font-weight-bold" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($interview_status['interview_status_created_at']); ?>">Interview Cancelled</span>
                                                        <?php endif; ?>
                                                      

                                                    </div>
                                                </div>
                                                <div class="separator separator-dashed my-4"></div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                                        <?php endif; ?>
                                            
                                    </div>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                </div>
               

                <div class="col-md-7 scroll scroll-pull" data-scroll="true" data-wheel-propagation="true" style="height:1130px">
                    <?php if(!empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] != ''): ?>
                    <div class="card card-flush mb-10">
                        <div class="card-body">
                            <div class="row g-9 mb-2">
                                <div class="col-md-12">
                                    <label class="fw-bold">Remarks by 1st interviewer ( <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer1']); ?> )</label>
                                    <p class="pt-5">
                                        <?php if(!empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] != ''): ?>
                                            <?php echo e($interview[0]['interview_interviewer_remarks']); ?>

                                        <?php else: ?>
                                            No Remarks By Interviewer.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endif; ?>

                    <?php if(!empty($interview[0]['interview_interviewer_remarks2']) && $interview[0]['interview_interviewer_remarks2'] != ''): ?>
                        <div class="card card-flush mb-10">
                            <div class="card-body">
                                <div class="row g-9 mb-2">
                                    <div class="col-md-12">
                                        <label class="fw-bold">Remarks by 2nd interviewer ( <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer2']); ?> )</label>
                                        <p class="pt-5">
                                            <?php if(!empty($interview[0]['interview_interviewer_remarks2']) && $interview[0]['interview_interviewer_remarks2'] != ''): ?>
                                                <?php echo e($interview[0]['interview_interviewer_remarks2']); ?>

                                            <?php else: ?>
                                                No Remarks By Interviewer.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>

                    <form id="update_interview">
                        <div class="card card-flush mb-10 ">
                        
                            <div class="card-body">
                            
                                <div class="row g-9 mb-2" >
                                    
                                    <div class="col-md-12 fv-row ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                        <span class="required">Requisition Reference</span>
                                        </label>

                                        <div class=" d-flex align-items-center">
                                            <select class="form-select mySelect3" data-control="select2" data-hide-search="false" data-placeholder="Select Requisition"  name="requisition reference" required=""> 
                                                <option value="">Select Requisition</option>
                                                    <?php if(!empty($requisitions)): ?>
                                                        <?php $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($requisition['requisition_id']); ?>"
                                                                <?php if(!empty($interview[0]['requisition_reference']) && $interview[0]['requisition_reference'] == $requisition['requisition_id']): ?> selected <?php endif; ?>>
                                                             <?php echo e($requisition['requisition_id']); ?> - <?php echo e($requisition['requisition_job_title']); ?> - <?php echo e($requisition['department_name']); ?> - <?php echo CustomHelper::getEmpProfileDiv($requisition['requisition_added_by']); ?>

                                                            </option>  
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                        
                                            </select>
                                        </div>
                                    </div>    

                                    <div class="col-md-12 ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                        <span class="required">Interview Type</span>
                                        </label>

                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select myselect3" data-control="select2" data-hide-search="false" data-placeholder="Select Interview Type" id="interview_type" name="interview_type" required=""> 
                                                <option value="">Select Interview Type</option>
                                                <option value="Online" <?php if($interview[0]['interview_type'] == 'Online'): ?> selected <?php endif; ?>>Online Interview</option>
                                                <option value="Physical" <?php if($interview[0]['interview_type'] == 'Physical'): ?> selected <?php endif; ?>>Physical Interview</option>
                                                
                                                    
                                            </select>
                                        </div>
                                    
                                    </div>
                            
                                  
                                    <div class="col-md-6 child-div-interview-type d-none">
                                        
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required" id="label-interview-room">Interviewer Room</span>
                                        </label>
                                        
                                    
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select mySelect3" data-control="select2" data-hide-search="true"  id="interview_room" name="room_no" required="required" value="<?php echo e($interview[0]['interview_room_nbr'] ?? ''); ?>">
                                                <option value="">Select Room</option>

                                                <?php if(!empty($office_rooms)): ?>

                                                    <?php $__currentLoopData = $office_rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office_room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($office_room['room_name']); ?>" <?php if($interview[0]['interview_room_nbr'] == $office_room['room_name']): ?> selected <?php endif; ?>><?php echo e($office_room['room_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php endif; ?>
                                          
                                                
                                                
                                            </select>
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6 child-div-interview-type ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                            <span class="required" id="label-interview-link">Interview Link</span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <input type="url" class="form-control" id="interview_link" name="interview_link" required="required" placeholder="Interview Link"  value="<?php echo e($interview[0]['interview_link'] ?? ''); ?>">
                                        </div>
                                        
                                        
                                    </div>
                                
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Date</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            
                                            <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                    <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                    <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                                </svg>
                                            </span>
                                            
                                            
                                            
                                                    <input type="hidden" class="form-control  ps-12" name="interview_id"
                                                        required="" value="<?php echo e($interview[0]['interview_id']); ?>">
                                                        <input type="hidden" class="form-control "  name="candidate_id" value="<?php echo e($interview[0]['candidate_id']); ?>"  />
                                                    <input class="form-control  ps-12" autocomplete="off"  id="interview_update"  name="interview_date"
                                                        required="" value="<?php echo e($interview[0]['interview_date']); ?>"
                                                        min="<?php echo e(date('Y-m-d')); ?>">
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Time</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            
                                            <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                    <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                    <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                                </svg>
                                            </span>
                                            
                                            
                                            
                                            <input type="time" class="form-control  ps-12" name="interview_time" value="<?php echo e($interview[0]['interview_time']); ?>" required=""/>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-6">
                                        
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required">Expected Duration Time</span>
                                        </label>
                                        
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select mySelect3" data-control="select2" data-hide-search="true"  name="duration" required="required">
                                                <option value="">Select Duration</option>
                                                
                                                    <option value="10" <?php echo e(($interview[0]['interview_duration']	== "10")? 'selected' : ''); ?>>10 minutes</option>
                                                    <option value="20" <?php echo e(($interview[0]['interview_duration']	== "20")? 'selected' : ''); ?>>20 minutes</option> 
                                                    <option value="30" <?php echo e(($interview[0]['interview_duration']	== "30")? 'selected' : ''); ?>>30 minutes</option>
                                                    <option value="40" <?php echo e(($interview[0]['interview_duration']	== "40")? 'selected' : ''); ?>>40 minutes</option>
                                                    <option value="50" <?php echo e(($interview[0]['interview_duration']	== "50")? 'selected' : ''); ?>>50 minutes</option>
                                                    <option value="60" <?php echo e(($interview[0]['interview_duration']	== "60")? 'selected' : ''); ?>>60 minutes</option>
                                                    
                                                
                                                
                                            </select>
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-6">
                                        
                                    <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Department</label>
                                    
                                    
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interview_department" required="required">
                                                <?php if(!empty($departments)): ?>
                                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($department['department_id']); ?>"
                                                            <?php if(!empty($interview[0]['interview_department']) && $interview[0]['interview_department'] == $department['department_id']): ?> selected <?php endif; ?>>
                                                            <?php echo e($department['department_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                        </select>
                                    </div>
                                    
                                    </div>
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Job Title</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="text" class="form-control " placeholder="Enter Job Title" name="interview_jobtitle" value="<?php echo e($interview[0]['interview_jobtitle']); ?>" required="">
                                            
                                        </div>
                                        
                                    </div>
                                    <div class="col-md-6">
                                        
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Interviewer 1st </span>
                                    </label>
                                    
                                    
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interviewer_1"  required="required">
                                            <option value="">Select Interviwer</option>
                                                    <?php if(!empty($employees)): ?>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($employee['employee_id']); ?>"
                                                                <?php if(!empty($interview[0]['interview_interviewer1']) && $interview[0]['interview_interviewer1'] == $employee['employee_id']): ?> selected <?php endif; ?>>
                                                                <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                        </select>
                                    </div>
                                    
                                    </div>

                                    <div class="col-md-6">
                                        
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span> Interviewer 2nd </span>
                                    </label>
                                    
                                    
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interviewer_2">
                                                <option value="">No 2nd Interviewer</option>
                                                        <?php if(!empty($employees)): ?>
                                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($employee['employee_id']); ?>"
                                                                    <?php if(!empty($interview[0]['interview_interviewer2']) && $interview[0]['interview_interviewer2'] == $employee['employee_id']): ?> selected <?php endif; ?>>
                                                                    <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                        </select>
                                    </div>
                                    
                                    </div>
                                    
                                    <div class="col-md-6">
                                        
                                    <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Round</label>
                                    
                                    
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interview_round"  required="required">
                                            <option value="">Select Interview Round</option>
                                            <option value="1st"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '1st'): ?> selected <?php endif; ?>>1st
                                                </option>
                                                <option value="2nd"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '2nd'): ?> selected <?php endif; ?>>2nd
                                                </option>
                                                <option value="3rd"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '3rd'): ?> selected <?php endif; ?>>3rd
                                                </option>
                                                <option value="4th"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '4th'): ?> selected <?php endif; ?>>4th
                                                </option>
                                                <option value="5th"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '5th'): ?> selected <?php endif; ?>>5th
                                                </option>
                                                <option value="6th"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '6th'): ?> selected <?php endif; ?>>6th
                                                </option>
                                                <option value="7th"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '7th'): ?> selected <?php endif; ?>>7th
                                                </option>
                                                <option value="8th"
                                                    <?php if(!empty($interview[0]['interview_round']) && $interview[0]['interview_round'] == '8th'): ?> selected <?php endif; ?>>8th
                                                </option>
                                        </select>
                                    </div>
                                    
                                    </div>

                                    <div class="col-md-6">
                                        
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span> Notice Period </span>
                                    </label>
                                    
                                    
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="notice_period" >
                                            <option value="">Select Notice Period</option>
                                            <?php $__currentLoopData = $notice_period; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  <?php echo e($interview[0]['interview_noticepriod'] == $notice_value ? "selected" : ""); ?>  value="<?php echo e($notice_value); ?>"><?php echo e($notice_value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    </div>

                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Name</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="text" class="form-control " placeholder="Candidate Name" name="candidate_name" value="<?php echo e($interview[0]['candidate_name']); ?>" required="" />
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Cv</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="file" class="form-control" accept=".docx,.txt,application/pdf,image/*"  name="candidate_cv" value="<?php echo e($interview[0]['interview_candidate_cv']); ?>">
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6 fv-row">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required">Candidate Contact No</span>
                                        </label>
                                    
                                        
                                        <div class=" d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Candidate contact number" name="contact_number" value="<?php echo e($interview[0]['candidate_contact_no']); ?>" required/>
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Current Salary</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Current Salary(optional)" name="current_salary" value="<?php echo e($interview[0]['interview_current_salary']); ?>">
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Expected Salary</label>
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Expected Salary(optional)" name="expected_salary" value="<?php echo e($interview[0]['interview_expected_salary']); ?>">
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-12">
                                        <label class="fs-6 fw-semibold mb-2">Additional Remarks</label>
                                        <textarea class="form-control " rows="3" name="additional_remarks" placeholder="Enter Additional Remarks(optional)"><?php echo e($interview[0]['interview_additional_remarks']); ?></textarea>
                                    </div>
                                </div>
                                
                                <?php if(empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] == ''): ?>
                                    <button type="submit" class="btn btn-lg btn-info mt-2" id="update-btn">Update Details</button>
                                <?php endif; ?>
                            </div>
                        
                        
                        </div>
                    
                    </form>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 card mb-5">
                    <div class="flex-lg-row-fluid card card-flush mb-10">
                        
                        <div class="card direct-chat direct-chat-primary">
                                        
                            <div class="card-header" id="kt_chat_messenger_header">
                                
                                <div class="card-title">
                                    
                                    <div class="d-flex justify-content-center flex-column me-3">
                                        <p class="fs-4 fw-bold text-gray-900 me-1 mb-2 lh-1">Interview Chat</p>
                                        
                                    </div>
                                    
                                </div>
                                
                                
                            </div>
                            
                            
                            <div class="card-body" id="kt_chat_messenger_body">
                                
                                <div class="scroll-y me-n5 pe-5 h-300px h-lg-auto " data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-max-height="auto" data-kt-scroll-dependencies="#kt_header, #kt_app_header, #kt_app_toolbar, #kt_toolbar, #kt_footer, #kt_app_footer, #kt_chat_messenger_header, #kt_chat_messenger_footer" data-kt-scroll-wrappers="#kt_content, #kt_app_content, #kt_chat_messenger_body" data-kt-scroll-offset="5px" style="max-height: 151px;" id="interview-chat-message">
                                    <!--begin::Message(in)-->
                                    <div class="direct-chat-messages">

                                    </div>
                        
                                </div>  
                            </div>
                            
                                    
                            <div class="card-footer pt-4" >
                                <form id="sendChatMessage">
                                    

                                    
                                    <input type="hidden" name="interview_id" value="<?php echo e(Request::segment(3)); ?>">
                                    <input type="hidden" name="interviewer1" value="<?php echo e($interview[0]['interview_interviewer1']); ?>" />
                                    <input type="hidden" name="interviewer2" value="<?php echo e($interview[0]['interview_interviewer2']); ?>" />
                                    <div class="input-group">
                                        
                                        <textarea class="form-control form-control-flush mb-3" id="messageInputBox"  name="message" rows="1" data-kt-element="input" placeholder="Type a message"></textarea>
                                        
                                        
                                        <div class="d-flex flex-stack">
                                            <button type="submit" id="sendMessageBtn"class="btn btn-primary">
                                                <span class="indicator-label">Submit</span>
                                                <span class="indicator-progress">Please wait... 
                                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                            </button>
                                            
                                            
                                        </div>
                                    </div>  
                                    
                                </form>    
                            </div>
                                    
                        </div>
                        
                    </div>
                </div>
            </div>
            
            
            <form id="add_interview" class="form">
             <?php echo csrf_field(); ?>
                <div class="modal fade" id="schedule_interview" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-750px">
                        
                        <div class="modal-content rounded">
                            
                                <div class="modal-header">
                                    <h4 class="modal-title pl-4">Re-Schedule Interview</h4>
                                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                        <span class="svg-icon svg-icon-1">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                            </svg>
                                        </span>
                                    </button>
                                </div>
                            
                            
                            <div class="modal-body scroll-y pt-0 pb-15">
                                
                                <input type="hidden" name="reSchedule" value="1" /> 
                                <input type="hidden" class="form-control "  name="candidate_id" value="<?php echo e($interview[0]['candidate_id']); ?>"  />
                                
                                <div class="row g-5 mt-1" >

                                    <div class="col-md-12 fv-row ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                        <span class="required">Requisition Reference</span>
                                        </label>

                                        <div class=" d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" data-placeholder="Select Requisition"  name="requisition reference" required=""> 
                                                <option value="">Select Requisition</option>
                                                    <?php if(!empty($requisitions)): ?>
                                                        <?php $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($requisition['requisition_id']); ?>"
                                                                <?php if(!empty($interview[0]['requisition_reference']) && $interview[0]['requisition_reference'] == $requisition['requisition_id']): ?> selected <?php endif; ?>>
                                                              <?php echo e($requisition['requisition_id']); ?> - <?php echo e($requisition['requisition_job_title']); ?> - <?php echo e($requisition['department_name']); ?> - <?php echo CustomHelper::getEmpProfileDiv($requisition['requisition_added_by']); ?>

                                                            </option>  
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                    
                                            </select>
                                        </div>
                                    </div>    

                                    <div class="col-md-12 ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                        <span class="required">Interview Type</span>
                                        </label>
                                    
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" data-placeholder="Select Interview Type" id="interview_type1" name="interview_type" required=""> 
                                                <option value="">Select Interview Type</option>
                                                <option value="Online" <?php if($interview[0]['interview_type'] == 'Online'): ?> selected <?php endif; ?>>Online Interview</option>
                                                <option value="Physical" <?php if($interview[0]['interview_type'] == 'Physical'): ?> selected <?php endif; ?>>Physical Interview</option>
                                                
                                                    
                                            </select>
                                        </div>
                                    
                                    </div>
                                    
                                    
                                    
                                    <div class="col-md-6 child-div-interview-type ">
                                        
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required" id="label-interview-room1">Interviewer Room</span>
                                        </label>
                                        
                                    
                                    
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false"  id="interview_room1" name="room_no" required="required" value="<?php echo e($interview[0]['interview_room_nbr'] ?? ''); ?>">
                                                <option value="">Select Room</option>
                                    
                                                <?php if(!empty($office_rooms)): ?>
                                    
                                                    <?php $__currentLoopData = $office_rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office_room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($office_room['room_name']); ?>" <?php if($interview[0]['interview_room_nbr'] == $office_room['room_name']): ?> selected <?php endif; ?>><?php echo e($office_room['room_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                                <?php endif; ?>
                                          
                                                
                                                
                                            </select>
                                        </div>
                                        
                                    </div>
                                    
                                    <div class="col-md-6 child-div-interview-type ">
                                        <label class="d-flex align-items-cente fs-6 fw-semibold mb-2">
                                            <span class="required" id="label-interview-link1">Interview Link</span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <input type="url" class="form-control" id="interview_link1" name="interview_link" required="required" placeholder="Interview Link"  value="<?php echo e($interview[0]['interview_link'] ?? ''); ?>">
                                        </div>
                                        
                                        
                                    </div>
                                
                                
                                    <div class="col-md-6">
                                            <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Date</label>
                                        
                                    
                                        <div class="position-relative d-flex align-items-center">
                                        
                                            <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                    <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                    <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                                </svg>
                                            </span>
                                        
                                                <?php 
                                                    $date = date('Y-m-d',strtotime($interview[0]['interview_date']));
                                                    $tomorrow = date('Y-m-d',strtotime($date . "+1 days")); 
                                                    
                                                ?>
                                                
                                                <input type="hidden" class="form-control  ps-12" name="interview_id"
                                                    required="" value="<?php echo e($interview[0]['interview_id']); ?>">
                                                <input class="form-control ps-12" autocomplete="off"  id="interview_reschedule"  name="interview_date"
                                                    required="" value="<?php echo e($tomorrow); ?>"
                                                    min="<?php echo e(date('Y-m-d')); ?>">
                                        
                                        </div>
                                    
                                    </div>
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Time</label>
                                        <div class="position-relative d-flex align-items-center">
                                        
                                            <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                    <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                    <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                                </svg>
                                            </span>
                                            <input type="time" class="form-control  ps-12" name="interview_time" value="<?php echo e($interview[0]['interview_time']); ?>" required=""/>
                                        </div>
                                    </div>
                                    

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required">Expected Duration Time</span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false"  name="duration" required="required">
                                                <option value="">Select Duration</option>
                                                
                                                    <option value="10" <?php echo e(($interview[0]['interview_duration']	== "10")? 'selected' : ''); ?>>10 minutes</option>
                                                    <option value="20" <?php echo e(($interview[0]['interview_duration']	== "20")? 'selected' : ''); ?>>20 minutes</option> 
                                                    <option value="30" <?php echo e(($interview[0]['interview_duration']	== "30")? 'selected' : ''); ?>>30 minutes</option>
                                                    <option value="40" <?php echo e(($interview[0]['interview_duration']	== "40")? 'selected' : ''); ?>>40 minutes</option>
                                                    <option value="50" <?php echo e(($interview[0]['interview_duration']	== "50")? 'selected' : ''); ?>>50 minutes</option>
                                                    <option value="60" <?php echo e(($interview[0]['interview_duration']	== "60")? 'selected' : ''); ?>>60 minutes</option>
                                                    
                                                
                                                
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Department</label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" name="interview_department" required="required">
                                                <?php if(!empty($departments)): ?>
                                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($department['department_id']); ?>"
                                                            <?php if(!empty($interview[0]['interview_department']) && $interview[0]['interview_department'] == $department['department_id']): ?> selected <?php endif; ?>>
                                                            <?php echo e($department['department_name']); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Job Title</label>
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="text" class="form-control " placeholder="Enter Job Title" name="interview_jobtitle" value="<?php echo e($interview[0]['interview_jobtitle']); ?>" required="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required">Interviewer 1st </span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" name="interviewer_1"  required="required">
                                                <option value="">Select Interviwer</option>
                                                    <?php if(!empty($employees)): ?>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($employee['employee_id']); ?>"
                                                                <?php if(!empty($interview[0]['interview_interviewer1']) && $interview[0]['interview_interviewer1'] == $employee['employee_id']): ?> selected <?php endif; ?>>
                                                                <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span> Interviewer 2nd </span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" name="interviewer_2">
                                                <option value="">No 2nd Interviewer</option>
                                                        <?php if(!empty($employees)): ?>
                                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($employee['employee_id']); ?>"
                                                                    <?php if(!empty($interview[0]['interview_interviewer2']) && $interview[0]['interview_interviewer2'] == $employee['employee_id']): ?> selected <?php endif; ?>>
                                                                    <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Interview Round</label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" name="interview_round"  id="interview_round" required="required" >
                                                <option value="">Select Interview Round</option>
                                                <?php if(!empty($interview_round)): ?>
                                                <?php $__currentLoopData = $interview_round; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                    <option  <?php echo e($interview_round[$next_interview_round+1] == $round ? "selected" : ""); ?>  value="<?php echo e($round); ?>"><?php echo e($round); ?></option>
                                            
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span> Notice Period </span>
                                        </label>
                                        <div class="position-relative d-flex align-items-center">
                                            <select class="form-select requitionselect" data-control="select2" data-hide-search="false" name="notice_period" >
                                                <option value="">Select Notice Period</option>
                                                <?php $__currentLoopData = $notice_period; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option  <?php echo e($interview[0]['interview_noticepriod'] == $notice_value ? "selected" : ""); ?>  value="<?php echo e($notice_value); ?>"><?php echo e($notice_value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Name</label>
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="text" class="form-control " placeholder="Candidate Name" name="candidate_name" value="<?php echo e($interview[0]['candidate_name']); ?>" required="" readonly/>
                                            
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Cv</label>
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="file" class="form-control " accept=".docx,.txt,application/pdf,image/*"  name="candidate_cv" value="<?php echo e($interview[0]['interview_candidate_cv']); ?>">
                                            
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                            <span class="required">Candidate Contact No</span>
                                        </label>
                                    
                                        
                                        <div class=" d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Candidate contact number" name="contact_number" value="<?php echo e($interview[0]['candidate_contact_no']); ?>" required/>
                                        
                                        </div>
                                        
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Current Salary</label>
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Current Salary(optional)" name="current_salary" value="<?php echo e($interview[0]['interview_current_salary']); ?>">
                                            
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <label class="d-flex align-items-center fs-6 fw-semibold mb-2">Candidate Expected Salary</label>
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Enter Expected Salary(optional)" name="expected_salary" value="<?php echo e($interview[0]['interview_expected_salary']); ?>">
                                            
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <label class="fs-6 fw-semibold mb-2">Additional Remarks</label>
                                        <textarea class="form-control " rows="3" name="additional_remarks" placeholder="Enter Additional Remarks(optional)"><?php echo e($interview[0]['interview_additional_remarks']); ?></textarea>
                                    </div>
                                </div>
                                        
                            </div>
                            <div class="modal-footer justify-content-center">
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit_btn" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            

            
            <form id="hired_interviewer_employee" class="form">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="hired_interviewer" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                                <h4 class="modal-title pl-4">Joining Confirmation of Candidate</h4>
                            
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                                
                            </div>
                            
                            
                    
                            
                            
                            <div class="modal-body scroll-y pt-0 pb-15">
                                
                                <h6 class="pt-5 pb-3 ">By marking this candidate as confirmed joining. It will be added in <a href="<?php echo e(url('/employee-onboarding')); ?>">On Boarding Employees</a>.</h6>
                            
                                
                                <div class="d-flex flex-column mb-8 mt-3">
                                    <label class="fs-6 fw-semibold mb-2 required">Candidate Name</label>
                                    <input type="hidden" class="form-control "  name="candidate_id" placeholder="Candidate Id" value="<?php echo e($interview[0]['candidate_id']); ?>"  />
                                    <input type="hidden" class="form-control "  name="deprt_id"  value="<?php echo e($interview[0]['department_id']); ?>"  />
                                    <input type="text" class="form-control " name="candidate_name"  placeholder="Candidate Name" value="<?php echo e($interview[0]['candidate_name']); ?>" required readonly />
                                </div>

                                <div class="d-flex flex-column mb-8 mt-3">
                                    <label class="fs-6 fw-semibold mb-2 required">Department Name</label>
                                    <input type="text" class="form-control" name="deprt_name"  placeholder="Department Name" value="<?php echo e($interview[0]['department_name']); ?>" required readonly />
                                </div>
                                

                                <div class="col-md-12 mb-8 mt-3">
                                    <label class="required fs-6 fw-semibold mb-2">Expected Joining Date</label>
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        
                                        
                                        <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                            </svg>
                                        </span>
                                        
                                        
                                        
                                        <input type="date" class="form-control  ps-12" placeholder="Select a date" name="joining_date" min="<?php echo e(date('Y-m-d')); ?>" required/>
                                        
                                    </div>
                                    
                                </div>
                                
                                
                                
                            </div>
                            
                            
                            <div class="modal-footer justify-content-center">
                            
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit_btn_hired" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
            </form>
            


             
             <form id="interviewer_status_candidate" class="form">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="interviewer_status" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                                <h4 class="modal-title pl-4">Change Interview Status</h4>
                            
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                                
                            </div>
                            
                            
                    
                            
                            
                            <div class="modal-body scroll-y pt-0 ">
                                
                                
                            
                                
                                <div class="d-flex flex-column  mt-3">
                                    <label class="fs-6 fw-semibold mb-2 required">Interview Status</label>

                                    <input type="hidden" class="form-control "  name="interview_id"value="<?php echo e($interview[0]['interview_id']); ?>"  />
                                    <input type="hidden" class="form-control "  name="employee_id"  value="<?php echo e($login_user[0]['employee_id']); ?>"  />

                                    <select class="form-select select" data-control="select2" data-hide-search="true"  name="interviewer_status" required="required">
                                        <option value="">Select Interview Status</option>
                                        <?php if(!empty($interview_status_levels)): ?>

                                            <?php $__currentLoopData = $interview_status_levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview_status_level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($interview_status_level['interview_status_level_id']); ?>" <?php if($interview_status['interview_status_level_id'] == $interview_status_level['interview_status_level_id'] ): ?>   selected <?php endif; ?>><?php echo e($interview_status_level['interview_status_level']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php endif; ?>
                                    </select>
 
                                </div>

                                
                                
                            </div>
                            
                            
                            <div class="modal-footer justify-content-center">
                            
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit_btn_status" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
            </form>
            
        </div>


    </div>
    
</div>

            

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>

<script>
     var interview_id = '<?php echo e(Request::segment(3)); ?>';

</script>

<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-database.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/js/firebase-interview-chat.js"></script>

<script>
    $(function(){
        $('#interview_type').trigger('change');
        $('#interview_type1').trigger('change');
        $('.mySelect3').select2({
            "enable": false,
            dropdownParent: $('#update_interview')
        })
        $('.requitionselect').select2({
            "enable": false,
            dropdownParent: $('#schedule_interview')
        })
	});

    $('#interview_type').change(function(){
        var interview_type =  $('#interview_type').find(":selected").val();
        
        $('.child-div-interview-type').removeClass('d-none')
        
        if(interview_type == 'Online'){
            $('#label-interview-room').removeClass('required');
            $('#label-interview-link').addClass('required');
            $('#interview_room').prop('required',false);
            $('#interview_link').prop('required',true);

        }else{
        $('#label-interview-link').removeClass('required');
        $('#label-interview-room').addClass('required');
        $('#interview_link').prop('required',false);
        $('#interview_room').prop('required',true);

        }
    })

   
    $('#update_interview').submit(function(e) {
        $('#update-btn').prop('disabled', true);
        $('#update-btn').attr('data-kt-indicator', 'on');
        $('#update-btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('interviews/modify_interview')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#update-btn').prop('disabled', false);
                    $('#update-btn').removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#update-btn').prop('disabled', false);
                $('#update-btn').removeAttr('data-kt-indicator');
                $('#update-btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    $('#add_interview').submit(function(e) {
        $('#submit_btn').prop('disabled', true);
        $('#submit_btn').attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('interviews/scheduleinterview')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $('#submit_btn').removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $('#submit_btn').removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    $('#hired_interviewer_employee').submit(function(e) {
        $('#submit_btn_hired').prop('disabled', true);
        $("#submit_btn_hired").attr('data-kt-indicator', 'on');
        $('#submit_btn_hired').css('cursor', 'pointer');
        
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('interviews/interviewer-hired')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 5000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn_hired').prop('disabled', false);
                    $('#submit_btn_hired').css('cursor', 'pointer');
                    $("#submit_btn_hired").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn_hired').prop('disabled', false);
                $('#submit_btn_hired').css('cursor', 'pointer');
                $("#submit_btn_hired").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });


    $('#interviewer_status_candidate').submit(function(e) {
        
        $('#submit_btn_status').prop('disabled', true);
        $("#submit_btn_status").attr('data-kt-indicator', 'on');
        $('#submit_btn_status').css('cursor', 'pointer');
        
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('interviews/interviewer-status')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn_status').prop('disabled', false);
                    $('#submit_btn_status').css('cursor', 'pointer');
                    $("#submit_btn_status").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn_status').prop('disabled', false);
                $('#submit_btn_status').css('cursor', 'pointer');
                $("#submit_btn_status").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

     
    $("#interview_reschedule").daterangepicker({
        locale: {
        format: 'YYYY-MM-DD'
        },
        singleDatePicker: true,
        showDropdowns: true,
        minYear: 1901,
        minDate: new Date(),
        maxYear: parseInt(moment().format("YYYY"),12)
        }, function(start, end, label) {
            var years = moment().diff(start, "years");
        }
    );

     
    $("#interview_update").daterangepicker({
        locale: {
        format: 'YYYY-MM-DD'
        },
        singleDatePicker: true,
        showDropdowns: true,
        minYear: 1901,
        minDate: new Date(),
        maxYear: parseInt(moment().format("YYYY"),12)
        }, function(start, end, label) {
            var years = moment().diff(start, "years");
        }
    );

    $('#interview_type1').change(function(){
        var interview_type =  $('#interview_type1').find(":selected").val();
        
        $('.child-div-interview-type').removeClass('d-none')
        
        if(interview_type == 'Online'){
            $('#label-interview-room1').removeClass('required');
            $('#label-interview-link1').addClass('required');
            $('#interview_room1').prop('required',false);
            $('#interview_link1').prop('required',true);

        }else{
        $('#label-interview-link1').removeClass('required');
        $('#label-interview-room1').addClass('required');
        $('#interview_link1').prop('required',false);
        $('#interview_room1').prop('required',true);

        }
    })

    function Copy(Url) {
    var Url = document.getElementById("url");
    Url.select();
    document.execCommand("copy");
    }
		
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/interview/interview-detail.blade.php ENDPATH**/ ?>