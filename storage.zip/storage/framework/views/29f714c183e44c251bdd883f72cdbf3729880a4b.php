

<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        <div class="app-container col-12 d-flex flex-stack">
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Add New Employee</h1>
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
            </div>
        </div>
    </div>
    
    <div class="app-content flex-column-fluid">
        <div class="app-container">
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bold fs-3 mb-1">Personal Details</span>
                        <span class="text-muted mt-1 fw-semibold fs-7"></span>
                    </h3>
                </div> 
                
                <div class="card-body py-3 ">
                    <form  id="add_employee_form" class="form" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Name</span>
                                </label>
                                
                                <input type="text" class="form-control " placeholder="Enter Employee Name" name="employee_name" required />
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Contact No</span>
                                </label>
                                
                                <input type="text" class="form-control " name="employee_contact_no"
                                placeholder="Enter Contact No" required="required" />
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Email<span>
                                </label>
                                
                                <input type="email" class="form-control " name="employee_email"
                                placeholder="Enter Employee Email" required="required"/>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee NIC No</span>
                                </label>
                                
                                <input type="text" class="form-control " name="employee_cnic" placeholder="Enter NIC No" required="required" />
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Gender<span>
                                </label>
                                
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select Employee Gender" name="employee_gender"
                                required="required">
                                    <option value="">Select Employee Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>    
                                </select>
                            </div>
                            
                        </div>

                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Company Details</span>
                            </h3>
                        </div>  
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Department</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select a Employee Department" name="employee_department"
                                required="required" id="department_select">
                                    <option value="">Select Employee Department</option>
                                    <?php if(!empty($all_departments)): ?>
                                        <?php $__currentLoopData = $all_departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_department['department_id']); ?>"
                                                data-depart_id="<?php echo e($all_department['department_id']); ?>">
                                                <?php echo e($all_department['department_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                        
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Designation</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select Employee Designation" name="employee_designation"
                                id="designss" required>
                                                                                           
                                </select>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Job Title</span>                                                        
                                </label>
                                
                                <input type="text" class="form-control " placeholder="Enter Job Title"
                                required name="employee_jobtitle"/>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Mark as Manager / Team Lead</span>                                                        
                                </label>
                                
                                <div class="d-flex align-items-center">
                                    <label class="form-check form-check-custom me-10">
                                        <input class="form-check-input h-20px w-20px manager-reporting" type="radio" id="customRadio5" name="make_ra" required="" value="1" />
                                        <span class="form-check-label fw-semibold">Yes, Employee's can report to him</span>
                                    </label>
                                    
                                    <label class="form-check form-check-custom">
                                        <input class="form-check-input h-20px w-20px manager-reporting " type="radio" id="customRadio6" name="make_ra" value="0"/>
                                        <span class="form-check-label fw-semibold">No, Employee's can't report to him</span>
                                    </label>
                                </div>
                              
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee's Senior Manager</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select a Senior Manager" name="employee_reporting_person"
                                 required="required">
                                <option value="">Select Senior Manager </option>
                                <?php if(!empty($reporting_managers)): ?>
                                    <?php $__currentLoopData = $reporting_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporting_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($reporting_manager['employee_id']); ?>">
                                            <?php echo e($reporting_manager['employee_name']); ?>

                                            (<?php echo e($reporting_manager['department_name']); ?> -
                                            <?php echo e($reporting_manager['designation_name']); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>                                            
                                </select>
                            </div>
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">Employee's Junior Manager</label>
                                <select class="form-select " data-control="select2" data-hide-search="false"  name="employee_reporting_person2">
                                    <option value="">Select Junior Manager </option>
                                    <?php if(!empty($reporting_managers)): ?>
                                        <?php $__currentLoopData = $reporting_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporting_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($reporting_manager['employee_id']); ?>">
                                                <?php echo e($reporting_manager['employee_name']); ?>

                                                (<?php echo e($reporting_manager['department_name']); ?> -
                                                <?php echo e($reporting_manager['designation_name']); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                   
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Joining Date</span>                                                        
                                </label>
                                
                                <input type="date" class="form-control " placeholder="mm/dd/yyyy" name="employee_doj"
                                required="required" />
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employment Status</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select a Employment Status"name="employee_status"
                                required="required">
                                    <option value="">Select Employment Status</option>
                                    <option value="Internee">Internee</option>  
                                    <option value="Probation">Probation</option>
                                    <option value="Permanent">Permanent</option>
                                    <option value="PartTime">Part Time</option>   
                                </select>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Salary</span>                                                        
                                </label>
                                
                                <input type="number" class="form-control " name="employee_salary"
                                placeholder="Enter Employee Salary" required="required" min="0" max="99999999"/>
                            </div>
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2 required">Employee Earning Type</label>
                                <select class="form-select " data-control="select2" data-hide-search="false"   name="earning_type" required>
                                    <option value="">Select Employee Earning Type</option>
                                    <option value="1">Monthly</option>
                                    <option value="2">Daily Wages</option>
                                   
                                </select>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2 required">Employee Job Type</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" data-placeholder="Select a Job Type" name="employee_jobtype"
                                required="required">
                                    <option value="">Select Job Type</option>
                                    <option value="Office">Office Base</option>
                                    <option value="Home">Home Base</option>
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2 required">Employee Activity Status</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" data-placeholder="Select a Activity Status" name="employee_isactive"
                                required="required" id="activity_status">
                                    <option value="">Select Activity Status</option>
                                    <option value="1">Active</option>
                                    <option value="2">De-Active</option>                                                                                                                                                  
                                </select>
                            </div>                            
                            
                        </div>
                        <div class="row  g-9 mb-8" >
                           
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Password</span>                                                        
                                </label>
                                
                                <input type="text" class="form-control "  name="employee_password"
                                placeholder="Enter Employee Password" required="required" value="<?php echo e($randomPassword); ?>"/>
                            </div>

                            <div class="col-md-6 fv-row ">
                                <label class="fs-6 fw-semibold mb-2">Employee Location</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select location" name="employee_location">
                                    <option value="">Select Bank Name</option>
                                    <?php if(!empty($all_locations)): ?>
                                        <?php $__currentLoopData = $all_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($location['location_title']); ?>"><?php echo e($location['location_title']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                             
                                </select>
                            </div>

                           
                        </div>

                        <div class="row  g-9 mb-8" id="append_row_date">
                            <div class="col-md-6" >
                                <div class="form-group">
                                    <label class="fs-6 fw-semibold mb-2">Employee Deactivation Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control " name="employee_deactivate_date" id="deactivate_date" required="required">
                                </div>
                            </div>

                        </div>
                        
                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Office Shift Timings</span>
                            </h3>
                        </div> 
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Shift Start Time</span>                                                        
                                </label>
                                
                                <input type="time" class="form-control " placeholder="--:-- --" name="shift_start_timings"
                                pattern="^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$"
                                required="required"/>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Shift End Time</span>                                                        
                                </label>
                                
                                <input type="time" class="form-control " placeholder="--:-- --" name="shift_end_timings"
                                pattern="^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$"
                               required="required" />
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                
                                
                                <div class="d-flex align-items-center">
                                    
                                    <label class="form-check form-check-custom me-10">
                                        <input class="form-check-input h-20px w-20px" type="checkbox" id="checkboxPrimary1"
                                        name="employee_shift_flexibilty" value="1" />
                                        <span class="form-check-label fw-semibold">Flexible Shift Timings</span>&nbsp; <i class="far fa-question-circle" data-bs-toggle="tooltip" data-placement="right" data-title="If employee has given facility of flexible shift timings, employee can check-in at any time and has to complete their shift total hours. For e.g 8 hours or 9 hours or it can be any."></i>
                                    </label>
                                </div>
                            </div>
                    
                            
                            
                        </div>
                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Leave Entitlement & Off Days</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                            <div class="card-toolbar">
                                
                            </div>
                        </div> 
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Off Day 1</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select 1st Off Day" name="offday1" required="required">
                                    <option value="">Select 1st Off Day</option>
                                    <option value="Monday">Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                    <option value="Saturday">Saturday</option>
                                    <option value="Sunday">Sunday</option>                                                         
                                </select>
                            </div>
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">Employee Off Day 2</label>
                                <select class="form-select " data-control="select2" data-hide-search="false"   name="offday2">
                                    <option value="">Select 2nd Off Day</option>
                                    <option value="Sunday">Sunday</option>
                                    <option value="Saturday">Saturday</option>
                                    <option value="Friday">Friday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Monday">Monday</option>
                                </select>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Casual Leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="casual_leaves" value="0"
                                placeholder="Enter Casual Leaves" required="required" />
                            </div>
                            
                            
                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Annual Leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="annual_leaves" value="0"
                                placeholder="Enter Annual Leaves" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Sick Leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="sick_leaves" value="0"
                                placeholder="Enter Sick Leaves" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Maternity leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="maternity_leaves" value="0"
                                placeholder="Enter Maternity Leaves" required="required"/>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Paternity leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="paternity_leaves" value="0"
                                placeholder="Enter Paternity Leaves" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Bereavement leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="bereavement_leaves" value="0"
                                placeholder="Enter Bereavement Leaves" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Compensatory leaves</span>
                                </label>
                                
                                <input type="number" class="form-control " placeholder="0" max="50" name="compensatory_leaves" value="0"
                                placeholder="Enter Compensatory Leaves" required="required"/>
                            </div>
                            
                        </div>
                    
                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Bank Account Detail (Optional)</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                        </div> 
                    
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">Bank Name</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" data-placeholder="Select a Bank Name" name="employee_bank_name">
                                    <option value="">Select Bank Name</option>
                                    <?php if(!empty($all_banks)): ?>
                                        <?php $__currentLoopData = $all_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_bank['bank_name']); ?>"><?php echo e($all_bank['bank_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                             
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span >Account Title</span>
                                </label>
                                
                                <input type="text" class="form-control " name="employee_account_title" placeholder="Enter Account Title"/>
                            </div>
                            
                        </div>
                    
                        <div class="row g-9 mb-8">
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span>Account No</span>
                                </label>
                                
                                <input type="text" class="form-control " name="employee_account_number" placeholder="Enter Account No" />
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span >Account IBAN</span> 
                                </label>
                                
                                <input type="text" class="form-control " name="employee_iban" placeholder="Enter Account IBAN"/>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span>Bank Code</span>
                                </label>
                                
                                <input type="text" class="form-control " name="employee_bank_code" placeholder="Enter Bank Code" />
                            </div>
                        </div>   

                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Module Rights</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                        </div>
                      
                        <?php if(!empty($get_modules)): ?>
                            <div class="row mb-8">
                                <div class="col-md-12">
                                    
                                    <table class="table table-row-bordered">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Basic Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                                <?php if($module['module_type'] == '0'): ?>
                                            
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                <input class="form-check-input " type="checkbox"  checked disabled>
                                                                <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>" value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                        
                                           
                                            
                                        </tbody>
                                    </table>

                                    <table class="table table-row-bordered mb-2">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Other Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           
                                                <?php if($module['module_type'] == '1'): ?>
                                                    <?php $class = '' ;$disabled = '' ; ?>
                                                    <?php if(in_array($module['module_url'],['/attendance','/attendance-requests','/employees-leaves','/wfh-requests','/all-salary-request','/resignations','/my-requisition','/all-loan-request','/shift-management','/employee-expense'])): ?>
                                                        <?php $class = 'checked'; ?>
                                                    <?php endif; ?>

                                                    <?php if(in_array($module['module_url'],['/my-expense','/permissions'])): ?>
                                                        <?php $disabled = 'disabled'; ?>
                                                    <?php endif; ?>
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom form-check-solid">
                                                                <input class="form-check-input <?php echo e($class); ?>" type="checkbox"  value="1" name="permission_status_<?php echo e($key); ?>" <?php if(!empty($disabled)): ?> checked disabled <?php endif; ?>>
                                                                <?php if(!empty($disabled)): ?>
                                                                    <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <?php endif; ?>
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>" value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="total_count" value="<?php echo e(count($get_modules)); ?>">
 
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                      
                    
                        <div class="text-center">
                            <button type="submit"class="btn btn-lg btn-success" id="submit_btn">
                                <span class="indicator-label">Add Employee</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                               </span>
                            </button>
                        </div>
                    </form>
                    
                </div>
                
            </div>
            
        </div>
        

    </div>
    
</div>

<div class="modal fade"  id="check-candidate-name" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-top mw-950px">
        <div class="modal-content rounded">
            <div class="modal-header">
                <h4 class="modal-title pl-4">On Board Employees</h4>
            </div>
            <div class="modal-body scroll-y pt-0 pb-15">
                <form id="update_onboarding_employee_status" class="form">
                    <?php echo csrf_field(); ?>  
                    <div class="card card-flush pt-3 mb-5 mb-lg-10" data-kt-subscriptions-form="pricing">
                        <div class="card-body pt-0">
                            <div id="kt_create_new_payment_method">
                                <p class="mb-4 text-center">These are the matching candidates in your on boarding. You can select to remove them from On Board process.</p>
                                <div class="onboarding-employees"></div>
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                    
                        <button type="submit" id="submit_btnn1" class="btn btn-primary" onclick="proceed_btn()">
                            <span class="indicator-label">Cancel</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                        <button type="submit" id="submit_btnn2" class="btn btn-success">
                            <span class="indicator-label">Process & Remove From On Board</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){
		dataTable = $('#tableEmployee').DataTable();
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
        // $('[data-mask]').inputmask();
        $('#append_row_date').hide();
	});

    $('#customRadio5').click(function(){
        reporting_authority_given =  $('#customRadio5').val();
        if(reporting_authority_given){
            $('.checked').prop('checked',true);
          
        }
    })
   
    $('#customRadio6').click(function(){
      
        reporting_authority_not_given =  $('#customRadio6').val();
      
        if(reporting_authority_not_given){
            $('.checked').prop('checked',false);
           
        }
       
    })
   
    $('#activity_status').change(function(){
        var selectedOption = $(this).val();
        if(selectedOption == '1'){
            $('#append_row_date').hide("");
            $('#deactivate_date').removeAttr('required');
        }else{
            $('#append_row_date').show("");
            $('#deactivate_date').attr('required','required');
        }
    });

    function candidate_name_list(){
        
        $.ajax({
            url: "<?php echo e(url('employees/check-candidate-name-list')); ?>",
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data:$("#add_employee_form").serialize(),
           
            success: function(data) {
                if (data.status == 'TRUE') {
                    candidate_record = data.data;
                    employeeOnBoardingArray = [];
                    $.each(candidate_record, function(key, candidate) {
                       if(candidate){
                           employeeOnBoardingArray.push(employeeOnBoarding(key,candidate));
               
                            $('.onboarding-employees').html(employeeOnBoardingArray);
                       }
                    });
                    $('#check-candidate-name').modal({backdrop: 'static', keyboard: false},'show');
                    $('#check-candidate-name').modal('show',{backdrop: 'static', keyboard: false});
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                } else {
                   
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    }

    $('#update_onboarding_employee_status').submit(function(e) {
        $('#submit_btnn1').prop('disabled', true);
        $("#submit_btnn1").attr('data-kt-indicator', 'on');
        $('#submit_btnn1').css('cursor', 'not-allowed');
        $('#submit_btnn2').prop('disabled', true);
        $("#submit_btnn2").attr('data-kt-indicator', 'on');
        $('#submit_btnn2').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('employees/update-onboarding-employee-status')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
               
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        window.location.href = "<?php echo e(url('employees')); ?>";
                    }, 3000);
                   

                } else {
                    //
                    $('#submit_btnn1').prop('disabled', false);
                    $("#submit_btnn1").removeAttr('data-kt-indicator');
                    $('#submit_btnn1').css('cursor', 'pointer');
                    $('#submit_btnn2').prop('disabled', false);
                    $("#submit_btnn2").removeAttr('data-kt-indicator');
                    $('#submit_btnn2').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btnn1').prop('disabled', false);
                $("#submit_btnn1").removeAttr('data-kt-indicator');
                $('#submit_btnn1').css('cursor', 'pointer');
                $('#submit_btnn2').prop('disabled', false);
                $("#submit_btnn2").removeAttr('data-kt-indicator');
                $('#submit_btnn2').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    

    $('#add_employee_form').submit(function(e) {
        
        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('employees/create_employee')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
               
                if (data.status == 'TRUE') {

                    if(data.total_candidate > 0){
                        candidate_name_list();
                    }else{
                        Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                        })
                        setTimeout(() => {
                            window.location.href = "<?php echo e(url('employees')); ?>";
                        }, 3000);
                    }
                   
                   
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });



    $('#department_select').change(function(e) {
        e.preventDefault();
        var department = $(this).find(':selected').attr('data-depart_id');
        $('#designss').html('');
        $.ajax({
            url: '<?php echo e(url('employees/get_desinations')); ?>/' + department,
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                department: department
            },
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#designss').append(data);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    function employeeOnBoarding(key=Null,data=Null){
        var interview_current_salary;
        var interview_expected_salary;
        
        if(data.interview_current_salary == null){
            interview_current_salary = 'N/A';
        }else{
            interview_current_salary = data.interview_current_salary
        }

        if(data.interview_expected_salary == null){
            interview_expected_salary = 'N/A';
        }else{
            interview_expected_salary = data.interview_expected_salary
        }


        var record = '';
         record +=`<div class="py-1">                        
            <div class="py-3 d-flex flex-stack flex-wrap">
                <div class="d-flex align-items-center toggle collapsed" data-bs-toggle="collapse" data-bs-target="#kt_create_new_payment_method_${key}">
                    <div class="btn btn-sm btn-icon btn-active-color-primary ms-n3 me-2">
                        <span class="svg-icon toggle-on svg-icon-primary svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor" />
                                <rect x="6.0104" y="10.9247" width="12" height="2" rx="1" fill="currentColor" />
                            </svg>
                       </span>
                        <span class="svg-icon toggle-off svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5" fill="currentColor" />
                                <rect x="10.8891" y="17.8033" width="12" height="2" rx="1" transform="rotate(-90 10.8891 17.8033)" fill="currentColor" />
                                <rect x="6.01041" y="10.9247" width="12" height="2" rx="1" fill="currentColor" />
                            </svg>
                       </span>
                    </div>
                    <div class="me-3">
                        <div class="d-flex align-items-center fw-bold">${data.candidate_name} 
                        <div class="badge badge-light-primary ms-5">${data.department_name}</div></div>
                        <div class="text-muted">Last Interview Date: ${data.interview_date} - ${data.interview_time}</div>
                    </div>
                </div>
                <div class="d-flex my-3 ms-9">
                    <label class="form-check form-check-custom me-5">
                        <input class="form-check-input" type="radio" id="candidate_id" required name="onboarding_id" value="${data.onboarding_id}" />
                    </label>
                </div>
            </div>
        
            <div id="kt_create_new_payment_method_${key}" class="collapse show fs-6 ps-10">
                
                <div class="d-flex flex-wrap py-5">
                
                    <div class="flex-equal me-5">
                        <table class="table table-flush fw-semibold gy-1">
                            <tr>
                                <td class="text-muted">1st Interviewer Name</td>
                                <td class="text-gray-800 ps-1">${data.interviewer_name1} </td>
                            </tr>
                            <tr>
                                <td class="text-muted">2nd Interviewer Name</td>
                                <td class="text-gray-800 ps-1">${(data.interviewer_name2) ?? 'N/A'} </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Interview Created By</td>
                                <td class="text-gray-800 ps-1">${data.interviewer_created_by}</td>
                            </tr>
                           
                        </table>
                    </div>
                    
                    <div class="flex-equal">
                        <table class="table table-flush fw-semibold gy-1">
                            <tr>
                                <td class="text-muted">Interview Job Title </td>
                                <td class="text-gray-800 ps-1">${data.interview_jobtitle} </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Current Salary </td>
                                <td class="text-gray-800 ps-1">
                                    ${interview_current_salary}
                                 </td>
                            </tr>
                            <tr>
                                <td class="text-muted">Expected Salary </td>
                                <td class="text-gray-800 ps-1">${interview_expected_salary} </td>
                            </tr>
                           
                           
                        </table>
                    </div>
                </div>
            
            </div>
        
        </div>
        <div class="separator separator-dashed"></div>
        `;

        return record;
    }

    function proceed_btn(){
        $('#candidate_id').prop('required',false);
    }
 
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/employee/add-employee.blade.php ENDPATH**/ ?>