

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-1 flex-column justify-content-center my-0">Payslips (<?php echo e(date('F-Y')); ?>)</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <div class="m-0">
                    <a href="" class="btn btn-sm btn-primary" >											
                        Download CSV (<?php echo e(date('F-Y')); ?>) Records</a>   
                    <a href="<?php echo e(url('payslip-employees/generate-payslip')); ?>" class="btn btn-sm btn-primary">											
                    Generate Payslip For Single Employee</a> 
                </div>
         
            </div>
            
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">
            <div class="row g-6 g-xl-9 mb-8">
                    
                
                <div class="col-sm-6 col-xl-4">
                    
                    <div class="card" style="background-color: rgb(44, 155, 44)">
                        
                        <div class="card-header flex-nowrap border-0 pt-9">
                            
                            <div class="card-title m-0">
                                
                                <a href="#" class="fs-1 fw-bolder text-white m-0">70000000</a>
                                
                            </div>
                            
                            
                            
                            
                        </div>
                        
                        
                        <div class="card-body d-flex flex-column px-9 pt-6 pb-8">
                            
                            <div class=" fw-bolder text-white mb-3">Total Salary Amount (November-2022)</div>
                          
                        </div>
                        
                    </div>
                    
                </div>
                

            </div>

            <div class="card mb-5 mb-xl-8">
                
                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control form-control-solid w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                    <div class="card-toolbar">
                        
                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                    
                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter</a>
                        <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1">
                            
                            <div class="px-7 py-5">
                                <div class="fs-5 text-dark fw-bold">Filter Options</div>
                            </div>

                            <div class="separator border-gray-200"></div>
                            <div class="px-7 py-5">
                                
                                <div class="mb-10">
                                    
                                    <label class="form-label fw-semibold">Select Month:</label>
                                    
                                    <div>
                                        <select class="form-select form-select-solid" data-kt-select2="true" data-placeholder="Select option" name="m" required="">
                                            <option value="01">January
                                            </option>
                                            <option value="02">February
                                            </option>
                                            <option value="03" >March
                                            </option>
                                            <option value="04">April
                                            </option>
                                            <option value="05">May
                                            </option>
                                            <option value="06">June
                                            </option>
                                            <option value="07">July
                                            </option>
                                            <option value="08">August
                                            </option>
                                            <option value="09">September
                                            </option>
                                            <option value="10">October
                                            </option>
                                            <option value="11">November
                                            </option>
                                            <option value="12">December
                                            </option>
                                        </select>
                                    </div>
                                    
                                </div>
                                <div class="mb-10">
                                    
                                    <label class="form-label fw-semibold">Select Year:</label>
                                    
                                    <div>
                                        <select class="form-select form-select-solid" data-kt-select2="true" data-placeholder="Select option" name="y" required="">
                                            <option value="01">2021
                                            </option>
                                            <option value="02">2022
                                            </option>
                                            <option value="03" >2023
                                            </option>
                                            <option value="04">2024
                                            </option>
                                            <option value="05">2025
                                            </option>
                                
                                        </select>
                                    </div>
                                    
                                </div>
                                <div class="d-flex justify-content-end">
                                    <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Close</button>
                                    <button type="submit" class="btn btn-sm btn-primary" data-kt-menu-dismiss="true">Apply</button>
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div> 
   
                <div class="card-body py-3">
                    
                    <div class="table-responsive">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="table-responsive">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer" id="tableEmployee" aria-describedby="tableEmployee_info">
                                								
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4 min-w-325px rounded-start sorting sorting_asc" tabindex="0" aria-controls="tableEmployee"   rowspan="1" colspan="1" aria-sort="ascending" aria-label="Code &amp;amp; Name: activate to sort column descending" style="width: 325px;">Payslip ID
                                        </th>
                                        <th class="min-w-125px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending" style="width: 189.828px;">Payslip Of
                                        </th>
                                        <th class="min-w-225px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Depart &amp;amp; Design: activate to sort column ascending" style="width: 225px;">Payslip Period Amount
                                        </th>
                                        <th class="min-w-200px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Management Rights: activate to sort column ascending" style="width: 200px;">Net Salary
                                        </th>
                                        <th class="min-w-200px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Management Rights: activate to sort column ascending" style="width: 200px;">Generation Date
                                        </th>
                                        <th class="min-w-200px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 200px;">Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                
                                    <tr class="odd">
                                        <td class="sorting_1">
                                            <div class="d-flex align-items-center">
                                                <div class="symbol symbol-50px me-5">
                                                    <img src="https://www.sourcecodeemployees.com/public/profile_pictures/WhatsApp%20Image%202022-05-18%20at%202.09.32%20PM.jpeg" class="" alt="">
                                                </div>
                                                <div class="d-flex justify-content-start flex-column">
                                                    <a href="#" class="text-dark fw-bold text-hover-primary mb-1 fs-6">001 - Zain Sheikh</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">sidrasheikh93@gmail.com</a>
                                        
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">Human Resource</a>
                                          
                                        </td>
                                        <td>
                                            <span class="badge badge-light-success fs-7 fw-bold">Yes, Given</span>
                                        </td>
                                        <td>
                                            <span class="fs-7 fw-bold">Yes</span>
                                        </td>
                                       
                                        <td class="">
                                            <a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                
                                                <span class="svg-icon svg-icon-3">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M17.5 11H6.5C4 11 2 9 2 6.5C2 4 4 2 6.5 2H17.5C20 2 22 4 22 6.5C22 9 20 11 17.5 11ZM15 6.5C15 7.9 16.1 9 17.5 9C18.9 9 20 7.9 20 6.5C20 5.1 18.9 4 17.5 4C16.1 4 15 5.1 15 6.5Z" fill="currentColor"></path>
                                                        <path opacity="0.3" d="M17.5 22H6.5C4 22 2 20 2 17.5C2 15 4 13 6.5 13H17.5C20 13 22 15 22 17.5C22 20 20 22 17.5 22ZM4 17.5C4 18.9 5.1 20 6.5 20C7.9 20 9 18.9 9 17.5C9 16.1 7.9 15 6.5 15C5.1 15 4 16.1 4 17.5Z" fill="currentColor"></path>
                                                    </svg>
                                                </span>
                                                
                                            </a>
                                            <a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                
                                                <span class="svg-icon svg-icon-3">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                    </svg>
                                                </span>
                                                
                                            </a>
                                            <a href="#" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm">
                                                
                                                <span class="svg-icon svg-icon-3">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M5 9C5 8.44772 5.44772 8 6 8H18C18.5523 8 19 8.44772 19 9V18C19 19.6569 17.6569 21 16 21H8C6.34315 21 5 19.6569 5 18V9Z" fill="currentColor"></path>
                                                        <path opacity="0.5" d="M5 5C5 4.44772 5.44772 4 6 4H18C18.5523 4 19 4.44772 19 5V5C19 5.55228 18.5523 6 18 6H6C5.44772 6 5 5.55228 5 5V5Z" fill="currentColor"></path>
                                                        <path opacity="0.5" d="M9 4C9 3.44772 9.44772 3 10 3H14C14.5523 3 15 3.44772 15 4V4H9V4Z" fill="currentColor"></path>
                                                    </svg>
                                                </span>
                                                
                                            </a>
                                        </td>
                                    </tr>
                        
                                  
                                </tbody>
                            
                            </table>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){
		dataTable = $('#tableEmployee').DataTable();
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
	});
    

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/payslip/all-employees-payslips.blade.php ENDPATH**/ ?>