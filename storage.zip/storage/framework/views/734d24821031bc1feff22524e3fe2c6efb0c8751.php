<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
    <style>
    .table {
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
    }

    .table td, .table th {
    border: 1px solid #ddd;
    padding: 8px;
    }

    .table tr:nth-child(even){background-color: #f2f2f2;}

    .table tr:hover {background-color: #ddd;}

    .table th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #212529;
    color: white;
    }
    .button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 12px;
    font-family: sans-serif;
    }
    </style>
</head>
<body>
  <?php if(!empty($month) && !empty($year) && !empty($download_button_show) && $download_button_show==true ): ?>
    <a  href="<?php echo e(url('tax-slab/download-tax-collection-pdf?month='.$month.'&year='.$year.'&download=TRUE')); ?>" class="button"  >
      Download PDF
    </a>
  <?php endif; ?>
<table class="table">
  <thead>
    <tr>
        <th class="text-center" >Slip No.</th>
        <th>Employee Name</th>
        <th>Pay Period</th>
        <th>Net Salary</th>
        <th>Tax Amount</th>
        <th>Generation Date</th>
    </tr>
  </thead>
  <tbody>
    <?php if(!empty($fetch_employee_tax)): ?>
        <?php $__currentLoopData = $fetch_employee_tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="ps-8"><?php echo e($employee_tax['pc_id']); ?></td>
                <td><?php echo CustomHelper::getEmpProfileDiv($employee_tax['pc_employee_id']); ?></td>
                <td><?php echo e(date('M-Y',strtotime($employee_tax['pc_year'].'-'.$employee_tax['pc_month'].'-'.'01'))); ?> </td>
                
                <td><?php echo e($employee_tax['pc_employee_net_salary']); ?></td>
                <td><?php echo e($employee_tax['total_tax_collection']); ?></td>

                <td><?php echo e(date('d-M-Y',strtotime($employee_tax['pc_created_at']))); ?></td>
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
  </tbody>
</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/tax-slab/all-tax-collection-pdf.blade.php ENDPATH**/ ?>