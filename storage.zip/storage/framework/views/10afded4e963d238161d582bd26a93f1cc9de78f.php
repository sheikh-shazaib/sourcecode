

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">

	<div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
		<div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
			<div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
				<h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Loan Detail</h1>
			</div>
		</div>
	</div>
	
	
	<div id="kt_app_content" class="app-content flex-column-fluid">
		
		<div id="kt_app_content_container" class="app-container">
			
			<div class="row">

				<div class="col-md-4 card mb-5">
					<div class="card-body pt-15 px-0">
						<div class="d-flex flex-column text-center mb-9 px-9">
							<div class="symbol symbol-80px symbol-lg-150px mb-4">
								<?php if(!empty($image)): ?>
									<?php if($image[0]['profile_avatar'] != null): ?>
										<img src="<?php echo e(asset('portal_assets/profile_pictures').'/'.$image[0]['profile_avatar']); ?>" class="" alt="" />
									<?php else: ?>
										<img src="<?php echo e(asset('/portal_assets/images/fav-icons.png')); ?>" class="" alt="" />
									<?php endif; ?>
								<?php endif; ?>
							</div>
							<div class="text-center">
								<a href="../user-profile/overview.html"> <span class="text-gray-800 fw-bold text-hover-primary fs-4"></span></a>
								<span class="text-muted d-block fw-semibold"><?php echo e($employees[0]['department_name']); ?></span>
								<span class="text-muted d-block fw-semibold"><?php echo e($employees[0]['designation_name']); ?></span>
							</div>
						</div>
									
									
						<div class="row px-9 mb-4">
							
							<div class="col-md-4 text-center">
								<div class="text-gray-800 fw-bold fs-3">
									<span class="m-0" data-kt-countup="true" ><?php echo e($employee_total_loan); ?></span>
								</div>
								<span class="text-gray-500 fs-8 d-block fw-bold">Total Loan</span>
							</div>
							
							
							<div class="col-md-4 text-center">
								<div class="text-gray-800 fw-bold fs-3">
								<span class="m-0" data-kt-countup="true" ><?php echo e($employee_submitted_loan); ?></span></div>
								<span class="text-gray-500 fs-8 d-block fw-bold">Loan Paid</span>
							</div>
							<div class="col-md-4 text-center">
								<div class="text-gray-800 fw-bold fs-3">
								<span class="m-0" data-kt-countup="true"><?php echo e($employee_remaining_loan); ?></span></div>
								<span class="text-gray-500 fs-8 d-block fw-bold">Loan Remaining</span>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-8">
					<div class="card">
						<div class="card-header card-header-stretch">
							
							<div class="card-title d-flex align-items-center">

								
							</div>
							
							
							<div class="card-toolbar m-0">
								
								<ul class="nav nav-tabs nav-line-tabs nav-stretch fs-6 border-0 fw-bold" role="tablist">
									<li class="nav-item" role="presentation">
										<a id="edit_loan_details_tab" class="nav-link justify-content-center text-active-gray-800 active" data-bs-toggle="tab" role="tab" href="#edit_loan_details">Edit Loan Details</a>
									</li>
									<li class="nav-item" role="presentation">
										<a id="kt_activity_week_tab" class="nav-link justify-content-center text-active-gray-800" data-bs-toggle="tab" role="tab" href="#kt_activity_week">Pay Installment</a>
									</li>
								</ul>
								
							</div>
							
						</div>

						<div class="card-body">
							<div class="tab-content">
								<div id="edit_loan_details" class="card-body p-0 tab-pane fade show active" role="tabpanel" aria-labelledby="edit_loan_details_tab">
									
									<div class="timeline">
										<form id="update_loan_detail">
											<div class="mb-10 mt-n1">
												<div class="row g-9 mb-8">
													<div class="col-md-6 fv-row">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Employee</span>
														</label>

														<input type="hidden" name="loan_id" value="<?php echo e($loan_detail[0]['loan_id']); ?>">

														<select class="form-select" data-control="select2" data-hide-search="false" name="employee_code" required="required" disabled="true">
															<option value="">Select Employee</option>
															<?php if(!empty($all_employees)): ?>
																<?php $__currentLoopData = $all_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
																	<option value="<?php echo e($all_employee['employee_id']); ?>" <?php if($all_employee['employee_id'] == $loan_detail[0]['employee_code']): ?> selected <?php endif; ?>>
																		<?php echo e($all_employee['employee_name']); ?>

																			
																	</option>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
															<?php endif; ?>
														</select>
													</div>

													<div class="col-md-6 fv-row">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Loan Amount</span>
														</label>
														
														<input type="number" class="form-control " placeholder="Enter Loan Amount" name="loan_amount" value="<?php echo e($loan_detail[0]['loan_given_amount']); ?>" readonly="readonly"  required="required"/>
													</div>
												</div>

												<div class="row g-9 mb-8">
													
													<div class="col-md-6 fv-row">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Loan Type</span>
														</label>
														
														<select class="form-select" data-control="select2" data-hide-search="true" name="loan_type" id="reason" required="required">
															<option value="">Select Reason</option>
															<option value="Bike Loan" <?php if($loan_detail[0]['loan_type'] == 'Bike Loan'): ?> selected <?php endif; ?>>Bike Loan</option>
															<option value="Car Loan" <?php if($loan_detail[0]['loan_type'] == 'Car Loan'): ?> selected <?php endif; ?>>Car Loan</option>
															<option value="Property Loan" <?php if($loan_detail[0]['loan_type'] == 'Property Loan'): ?> selected <?php endif; ?>>Property Loan</option>
															<option value="Advance Salary" <?php if($loan_detail[0]['loan_type'] == 'Advance Salary'): ?> selected <?php endif; ?>>Advance Salary</option>
															<option value="Other" <?php if($loan_detail[0]['loan_type'] == 'Other'): ?> selected <?php endif; ?>>Other</option>
														</select>
													</div>
													
													
													<div class="col-md-6 fv-row reason_div <?php if($loan_detail[0]['loan_type'] != 'Other'): ?> d-none <?php endif; ?>">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Reason </span>
														</label>
														
														<input type="text" class="form-control " placeholder="Enter Loan Reason" name="loan_other_reason" value="<?php echo e($loan_detail[0]['loan_other_reason']); ?>" id="reason_input"/>
													</div>
													
												</div>

												<div class="text-end">
													<button type="submit" id="update_loan_detail_submit_btn" class="btn btn-primary">
														<span class="indicator-label">Update Details</span>
														<span class="indicator-progress">Please wait...
														<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
													</button>
												</div>
											</div>
										</form>
									</div>

								</div>

								<div id="kt_activity_week" class="card-body p-0 tab-pane fade show" role="tabpanel" aria-labelledby="kt_activity_week_tab">
									<div class="timeline">
										<form id="add_installment">
											<div class="mb-10 mt-n1">
												
												<div class="row g-9 mb-8">
													
													<div class="col-md-6 fv-row">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Total Remaining Amount</span>
														</label>
														
														<input type="number" class="form-control " placeholder="Enter Employee Name" name="loan_remaings" value="<?php echo e($loan_detail[0]['loan_remaining_amount']); ?>" readonly="readonly" id="loan_remain"/>
														<input type="hidden" class="form-control" name="loan_id" required="" value="<?php echo e($loan_detail[0]['loan_id']); ?>" readonly="" id="loan_remain">
													</div>
													
													
													<div class="col-md-6 fv-row">
														<label class="d-flex align-items-center fs-6 fw-semibold mb-2">
														<span class="required">Deposit Amount (Installment Amount)</span>
														</label>
														
														<input type="number" class="form-control " placeholder="Enter Deposit Amount" name="installment_amount" id="installment_amount"/>
													</div>
													
												</div>
												<div class="text-end">
													<button type="submit" id="installment_btn" <?php if($loan_detail[0]['loan_remaining_amount'] == '0'): ?> disabled <?php endif; ?> class="btn btn-primary">
														<span class="indicator-label">Pay Installment</span>
														<span class="indicator-progress">Please wait...
														<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
													</button>
												</div>

											</div>
										</form>

									</div>
								</div>

							</div>
						</div>
					</div>
				</div>

				<div class="col-md-4 card card-flush">
					<div class="card-body">
						<ul class="nav nav-pills nav-pills-custom row position-relative mx-0 mb-9">

							<li class="nav-item col-6 mx-0 p-0">
								<a class="nav-link active d-flex justify-content-center w-100 border-0 h-100" data-bs-toggle="pill" href="#kt_list_widget_10_tab_1">
									<span class="nav-text text-gray-800 fw-bold fs-6 mb-3">Loan Details</span>
									<span class="bullet-custom position-absolute z-index-2 bottom-0 w-100 h-4px bg-primary rounded"></span>
								</a>
							</li>

							<li class="nav-item col-6 mx-0 px-0">
								<a class="nav-link d-flex justify-content-center w-100 border-0 h-100" data-bs-toggle="pill" href="#kt_list_widget_10_tab_2">
									<span class="nav-text text-gray-800 fw-bold fs-6 mb-3">Installment Details</span>
									<span class="bullet-custom position-absolute z-index-2 bottom-0 w-100 h-4px bg-primary rounded"></span>
								</a>
							</li>

							<span class="position-absolute z-index-1 bottom-0 w-100 h-4px bg-light rounded"></span>
						</ul>

						<div class="tab-content">

							<div class="tab-pane fade show active" id="kt_list_widget_10_tab_1">

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Loan ID</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_id']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Issuance Date</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_issuance_date']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Issued To</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_id']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Total Amount</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_given_amount']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Returned Amount</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_submitted_amount']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Remaining Amount</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_remaining_amount']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Type</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_type']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Reason</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['loan_other_reason']); ?></span>
									</div>
								</div>

								<div class="separator separator-dashed my-2"></div>

								<div class="d-flex align-items-sm-center">
									<div class="d-flex align-items-center flex-row-fluid flex-wrap">
										<div class="flex-grow-1 me-2">
											<span class="text-gray-800 fw-bold d-block fs-5">Last Updated</span>
										</div>
										<span class="text-gray-500 fw-bold my-2"><?php echo e($loan_detail[0]['last_updated']); ?></span>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="kt_list_widget_10_tab_2">

								<?php if(!empty($installment_details)): ?>
									<?php $__currentLoopData = $installment_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="d-flex align-items-sm-center">
											<div class="d-flex align-items-center flex-row-fluid flex-wrap">
												<div class="flex-grow-1 me-2">
													<span class="text-gray-800 fw-bold d-block fs-5"><?php echo e($installment_detail['loan_installment_date']); ?></span>
												</div>
												<span class="text-gray-500 fw-bold my-2"><?php echo e($installment_detail['loan_installment_amount']); ?>.00 Rs</span>
											</div>
										</div>
										<div class="separator separator-dashed my-2"></div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>

							</div>

						</div>
					</div>
				</div>

				
			</div>
			
		</div>
		
	</div>
	
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js-link'); ?>

<script>
	$('#reason').change(function() {
		var reason_val = $(this).val();
		if(reason_val == 'Other'){
			$('.reason_div').removeClass('d-none');
			$('#reason_input').attr('required','required');
		}else{
			$('.reason_div').addClass('d-none');
			$('#reason_input').removeAttr('required');
		}
	});

	$('#installment_amount').keyup(function() {
		let deduction_amount = $(this).val();
		let employee_loan = $('#loan_remain').val();
		if (employee_loan == '0' || employee_loan == '0.00') {
			$('#installment_amount').attr('readonly', 'readonly');
		} else {
			if (Number(deduction_amount) > Number(employee_loan)) {
				$('#installment_amount').val('');
				Toast.fire({
					icon: 'warning',
					title: 'Installment amount cannot be greater than loan remaining amount',
					timer: 8000,
				})
			} else {

			}
		}
	});

	  $('#add_installment').submit(function(e) {
		$('#installment_btn').prop('disabled', true);
		$('#installment_btn').attr('data-kt-indicator', 'on');
		$('#installment_btn').css('cursor', 'not-allowed');
		e.preventDefault();
		$.ajax({
			url: '<?php echo e(url('loans/payinstallment')); ?>',
			type: 'POST',
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			data: new FormData(this),
			contentType: false,
			cache: false,
			processData: false,
			success: function(data) {
				if (data.status == 'TRUE') {
					Toast.fire({
						icon: 'success',
						title: data.msg,
						timer: 3000,
					})
					setTimeout(() => {
						location.reload();
					}, 3000);
				} else {
					Toast.fire({
						icon: 'warning',
						title: data.msg,
						timer: 5000,
					})
					$('#installment_btn').prop('disabled', false);
					$('#installment_btn').removeAttr('data-kt-indicator');
					$('#installment_btn').css('cursor', 'pointer');
				}
			},
			error: function(jqXHR, textStatus) {
				var errorStatus = jqXHR.status;
				$('#installment_btn').prop('disabled', false);
				$('#installment_btn').removeAttr('data-kt-indicator');
				$('#installment_btn').css('cursor', 'pointer');
				if (errorStatus == 0) {
					Toast.fire({
						icon: 'warning',
						title: 'Internet Connection Problem',
						timer: 3000,
					})
				} else {
					Toast.fire({
						icon: 'warning',
						title: 'Try Again. Error Code ' + errorStatus,
						timer: 3000,
					})
				}
			}
		});
	});

	$('#update_loan_detail').submit(function(e) {
        $('#update_loan_detail_submit_btn').prop('disabled', true);
        $("#update_loan_detail_submit_btn").attr('data-kt-indicator', 'on');
        $('#update_loan_detail_submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url("loans/update_loan")); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#update_loan_detail_submit_btn').prop('disabled', false);
                    $("#update_loan_detail_submit_btn").removeAttr('data-kt-indicator');
                    $('#update_loan_detail_submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#update_loan_detail_submit_btn').prop('disabled', false);
                $("#update_loan_detail_submit_btn").removeAttr('data-kt-indicator');
                $('#update_loan_detail_submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/loan/loan-detail.blade.php ENDPATH**/ ?>