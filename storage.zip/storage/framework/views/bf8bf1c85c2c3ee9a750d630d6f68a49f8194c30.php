<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<head>
	<title>SourceCode - HCM</title>
	<meta charset="utf-8" />
	<meta name="description" content="Our state of the art product offers complete HR management with latest technology and AI based help you to put your employees at the center of your company" />
	<meta name="keywords" content="SourceCode - HCM, SourceCode - HRM, SourceCode, HCM, HRM, Human Capital Management, Human Resource Management." />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta property="og:locale" content="en_US" />
	<meta property="og:type" content="article" />
	<meta property="og:title" content="Intelligent and Efficient HCM System" />
	<meta property="og:url" content="<?php echo e(url('/')); ?>" />
	<meta property="og:site_name" content="SourceCode - HCM" />
	<link rel="canonical" href="<?php echo e(url('/')); ?>" />
	<link rel="shortcut icon" href="<?php echo e(url('portal_assets/images/fav-icons.png')); ?>" />
	
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
	
	
	<link href="<?php echo e(url('assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
	<link href="<?php echo e(url('assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
	
	<script src="https://code.jquery.com/jquery-3.6.1.js"></script>
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<style>
		.vertical-center {
			margin: 0;
			position: fixed;
			height: 100vh;
			width: 100%;
			padding-top:20%;
			display:block;
			text-align:center;

		}
	</style>

</head>
	
	
	<body id="kt_body" class="app-blank app-blank bgi-size-cover bgi-position-center bgi-no-repeat">

		<?php $setting =  CustomHelper::hcm_default_settings() ?>

		<div class="page-loader flex-column vertical-center">
			<div class="spinner-border text-primary" role="status"></div>
			<div class="text-muted fs-6 fw-semibold mt-5">Loading...</div>
		</div>
	
		<div class="d-flex flex-column flex-root" id="kt_app_root">
			<style>body { background-image: url('/assets/media/auth/bg10.jpg'); } [data-theme="dark"] body { background-image: url('/assets/media/auth/bg10-dark.jpg'); }</style>
			<div class="d-flex flex-column flex-lg-row flex-column-fluid">
				
				<div class="d-flex flex-lg-row-fluid">
				
					<div class="d-flex flex-column flex-center pb-0 pb-lg-10 p-10 w-100">
						
						<img class="theme-light-show mx-auto mw-100 w-150px w-lg-300px mb-10 mb-lg-20" src="<?php echo e(URL('/portal_assets/images/main-login.png')); ?>" alt="" />
						<h1 class="text-gray-800 fs-2qx fw-bold text-center mb-7">Fast, Efficient and Productive</h1>
						
						<div class="text-gray-600 fs-base text-center fw-semibold">At SourceCode, we have a reliable, secure and adaptable HR management built from the ground up. 
						    <br />We are determined to help our employees to give their best efforts every day to achieve the goals of their job.
					    </div>
						
					</div>
					
				</div>

				<div class="d-flex flex-column-fluid flex-lg-row-auto justify-content-center justify-content-lg-end p-12">
					
					<div class="bg-body d-flex flex-center rounded-4 w-md-600px p-10">
						
						<div class="w-md-400px">
						
							<form class="form w-100"  id="loginForm" autocomplete="off" >
								
								<div class="text-center mb-11">
									
									<h1 class="text-dark fw-bolder mb-3"><?php echo e($setting['company_name']); ?> - HCM</h1>
									<div class="text-gray-500 fw-semibold fs-6">Sign in to start your session</div>
									
								</div>
								
                                <div class="text-center mb-11">
									<img alt="Logo" src="<?php echo e($setting['company_logo']); ?>" class="theme-light-show" style="width: 40%;" />
																	
								</div>
								
								<div class="fv-row mb-8 ">
								
									<input type="number" name="employee_id" class="form-control bg-transparent" placeholder="Employee Code" min="0"  required/>
									
								</div>
								
								<div class="fv-row mb-3">
									
									<input  type="password" name="employee_password" placeholder="Password"  class="form-control bg-transparent" required/>
							
								</div>
								
								<div class="d-flex flex-stack flex-wrap gap-3 fs-base fw-semibold mb-8">
									<div></div>
									
								</div>
								
								<div class="d-grid mb-10">

									<div id="gl_div" >
									</div>

									<button type="submit" id="loginForm_submit" class="btn btn-primary">
										
										<span class="indicator-label">Sign In</span>
										
										<span class="indicator-progress">Please wait... 
										<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
										
									</button>
								</div>

								<div class="d-grid mb-10">
								    <span class="text-center">© 2023 SourceCode HCM. All Rights Reserved</span>
								</div>
								
						
							</form>
							
						</div>
					
					</div>
					
				</div>
				
			</div>
			
		</div>
		<script>
			const Toast = Swal.mixin({
				toast: true,
				position: 'top-end',
				showConfirmButton: false,
				timer: 3000,
				timerProgressBar: true,
			});

			setTimeout(()=>{
				$('.page-loader').fadeOut()
			})
			
			var gl;

			$("#loginForm").submit(function(e) {
				
				$('#loginForm_submit').prop('disabled', true);
				$('#loginForm_submit').css('cursor', 'not-allowed');
				// $('.btn_loader').removeClass('d-none');
				$("#loginForm_submit").attr('data-kt-indicator', 'on');
				$('#gl_div').html(gl);
				e.preventDefault();
				$.ajax({
					url: '<?php echo e(url('authenticate')); ?>',
					type: 'POST',
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					data: new FormData(this),
					contentType: false,
					cache: false,
					processData: false,
					success: function(data) {
					  $('#gl_div').html('');
					  response = JSON.parse(JSON.stringify(data));
					  console.log(response.status);
						if (response.status == "TRUE") {
							
							Toast.fire({
								icon: 'success',
								title: response.message,
								timer: 3000,
							})
							  setTimeout(() => {
								window.location.href = '<?php echo e(url('/')); ?>';
							}, 3000);
							
							
						} else {
						  Toast.fire({
								icon: 'warning',
								title: response.message,
								timer: 6000,
							})
							$('#loginForm_submit').prop('disabled', false);
							$('#loginForm_submit').css('cursor', 'pointer');
							$("#loginForm_submit").removeAttr('data-kt-indicator');
						  
						}
					},
					error: function(jqXHR, textStatus) {
						$('#loginForm_submit').prop('disabled', false);
						$('#loginForm_submit').css('cursor', 'pointer');
						$("#loginForm_submit").removeAttr('data-kt-indicator');
						$('#gl_div').html('');
						// $('.btn_loader').addClass('d-none');
						var errorStatus = jqXHR.status;
						
						if (errorStatus == 0) {
							Toast.fire({
								icon: 'warning',
								title: 'Internet Connection Problem',
								timer: 6000,
							});
						} else {
							if(errorStatus == 419){
								location.reload();
							}else{
								Toast.fire({
									icon: 'warning',
									title: 'Try Again. Error Code ' + errorStatus,
									timer: 3000,
								})
							}
						}
					}
				});
			});

			
		</script>



		
		

	</body>
	


</html><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/authentication/signin.blade.php ENDPATH**/ ?>