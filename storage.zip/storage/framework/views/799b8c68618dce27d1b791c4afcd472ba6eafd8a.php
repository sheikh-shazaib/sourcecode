






<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Edit Employee Permission</h1>
                
                
                
                
            </div>
            
            
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary"  >Go Back</a>
            </div>
            
        </div>
        
    </div>
    
    
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            
            <div class="card mb-5 mb-xl-8">
                <div class="card-body py-3">
                    
                    <?php if(!empty($get_modules)): ?>
                        <form  id="edit_employee_permission_form" class="form" autocomplete="off">
                            <?php echo csrf_field(); ?>
            
                        
                            <div class="row mb-8">
                                <input type="hidden" class="form-control" name="employee_id"
                                placeholder="Enter Employee Name" required="required"
                                value="<?php echo e($employee_id); ?>">
                                <input type="hidden" class="form-control" name="employee_jobtype"
                                required="required"
                                value="<?php echo e($login_user[0]['employee_jobtype']); ?>">
                                <div class="col-md-12">
                                    
                                    <table class="table table-row-bordered">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Basic Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($module['module_type'] == '0'): ?>
                                                    
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom">
                                                                <input class="form-check-input" type="checkbox"  checked disabled>
                                                                <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>" value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </tbody>
                                    </table>

                                    <table class="table table-row-bordered mb-2">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Other Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($module['module_type'] == '1'): ?>
                                                    <?php $checked = '';$disabled = ''; ?>
                                                    <?php if(in_array($module['module_url'],$get_permissions)): ?>
                                                        <?php $checked = 'checked'; ?>

                                                    <?php endif; ?>
                                                    <?php if(in_array($module['module_url'],['/my-expense'])): ?>
                                                         <?php $disabled = 'disabled'; ?>
                                                    <?php endif; ?>
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom">
                                                                <input class="form-check-input"  type="checkbox"  value="1" <?php echo e($checked); ?>  name="permission_status_<?php echo e($key); ?>"  <?php if(!empty($disabled)): ?> checked disabled <?php endif; ?>>
                                                                <?php if(!empty($disabled)): ?>
                                                                    <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <?php endif; ?>
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>"  value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <input type="hidden" name="total_count" value="<?php echo e(count($get_modules)); ?>">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        
                            
                            
                            
                            <div class="text-center">
                            
                                <button type="submit"class="btn btn-lg btn-success" id="submit_btn">
                                    <span class="indicator-label">Update Employee Permission</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </form>
                    <?php endif; ?>
                    
                </div>
                
            </div>
            
            
            
        </div>
        

        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
   
    // $(function(){
    //     var job_type = $('#employee_jobtype').val();
    //     if(job_type == 'Home'){
    //         $('#wfh')..prop('disabled', true);
    //     }
    // })
    $('#customRadio5').click(function(){
        reporting_authority_given =  $('#customRadio5').val();
        
      
        if(reporting_authority_given){
            $('.checked').prop('checked',true);
           
        }
    })
   
    $('#customRadio6').click(function(){
      
        reporting_authority_not_given =  $('#customRadio6').val();
      
        if(reporting_authority_not_given){
            $('.checked').prop('checked',false);
        }
       
    })
  
  

    $('#edit_employee_permission_form').submit(function(e) {
        var previous_url  = '<?php echo e(url()->previous()); ?>';
        previous_url = previous_url.replace("amp;",'');
        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('permissions/update_employee_permission')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        window.location.href = previous_url;
                      
                        
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/permissions/edit-employee-permission.blade.php ENDPATH**/ ?>