

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Tax Collection (<?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?>) </h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                
         
            </div>
            
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">

            <div class="row g-6 g-xl-9">
                    
                <div class="col-xl-12">
                                        
                    <a href="#" class="card bg-body hoverable card-xl-stretch mb-xl-8">
                        
                        <div class="card-body">
                            
                            <span class="svg-icon svg-icon-primary svg-icon-3x ms-n1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="8" y="9" width="3" height="10" rx="1.5" fill="currentColor"></rect>
                                    <rect opacity="0.5" x="13" y="5" width="3" height="14" rx="1.5" fill="currentColor"></rect>
                                    <rect x="18" y="11" width="3" height="8" rx="1.5" fill="currentColor"></rect>
                                    <rect x="3" y="13" width="3" height="6" rx="1.5" fill="currentColor"></rect>
                                </svg>
                            </span>
                            
                            <div class="text-gray-900 fw-bold fs-2 mb-2 mt-5" data-kt-countup="true" data-kt-countup-value="<?php echo e((empty($total_tax_collection)) ? '0' : $total_tax_collection); ?>"></div>
                            <div class="fw-semibold text-gray-400">Total tax collection of <?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?></div>
                        </div>
                        
                    </a>
                    
                </div>
            </div>
           
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">  

                    

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>


                    <div class="card-toolbar" >
                        
                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                    
                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter
                        </a>
                       
                        <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                            <form action="<?php echo e(url('/tax-collection')); ?>" method="GET">

                                <div class="px-7 py-5">
                                    <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                </div>

                                <div class="separator border-gray-200"></div>
                                <div class="px-7 py-5">
                                        
                                    <div class="mb-10">
                                            
                                        <label class="form-label fw-semibold">Month:</label>
                                            
                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Month"name="m"
                                            required="required">
                                            <option value="">Select Month</option>
                                            <option value="01" <?php if(!empty(Request::get('m')) && Request::get('m') == '01'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '01'): ?> selected <?php endif; ?>>January
                                            </option>
                                            <option value="02" <?php if(!empty(Request::get('m')) && Request::get('m') == '02'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '02'): ?> selected <?php endif; ?>>February
                                            </option>
                                            <option value="03" <?php if(!empty(Request::get('m')) && Request::get('m') == '03'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '03'): ?> selected <?php endif; ?>>March
                                            </option>
                                            <option value="04" <?php if(!empty(Request::get('m')) && Request::get('m') == '04'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '04'): ?> selected <?php endif; ?>>April
                                            </option>
                                            <option value="05" <?php if(!empty(Request::get('m')) && Request::get('m') == '05'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '05'): ?> selected <?php endif; ?>>May
                                            </option>
                                            <option value="06" <?php if(!empty(Request::get('m')) && Request::get('m') == '06'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '06'): ?> selected <?php endif; ?>>June
                                            </option>
                                            <option value="07" <?php if(!empty(Request::get('m')) && Request::get('m') == '07'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '07'): ?> selected <?php endif; ?>>July
                                            </option>
                                            <option value="08" <?php if(!empty(Request::get('m')) && Request::get('m') == '08'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '08'): ?> selected <?php endif; ?>>August
                                            </option>
                                            <option value="09" <?php if(!empty(Request::get('m')) && Request::get('m') == '09'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '09'): ?> selected <?php endif; ?>>September
                                            </option>
                                            <option value="10" <?php if(!empty(Request::get('m')) && Request::get('m') == '10'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '10'): ?> selected <?php endif; ?>>October
                                            </option>
                                            <option value="11" <?php if(!empty(Request::get('m')) && Request::get('m') == '11'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '11'): ?> selected <?php endif; ?>>November
                                            </option>
                                            <option value="12" <?php if(!empty(Request::get('m')) && Request::get('m') == '12'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '12'): ?> selected <?php endif; ?>>December
                                            </option>
                                        </select>
                                    </div>

                                    <div class="mb-10">
                                        
                                        <label class="form-label fw-semibold">Attendance Year</label>
                                        
                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year" name="y" required="required">
                                            <option value="">Select Year</option>
                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?> selected <?php endif; ?>>2020
                                            </option>
                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?> selected <?php endif; ?>>2021
                                            </option>
                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?> selected <?php endif; ?>>2022
                                            </option>
                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?> selected <?php endif; ?>>2023
                                            </option>
                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?> selected <?php endif; ?>>2024
                                            </option>
                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?> selected <?php endif; ?>>2025
                                            </option>
                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?> selected <?php endif; ?>>2026
                                            </option>
                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?> selected <?php endif; ?>>2027
                                            </option>
                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?> selected <?php endif; ?>>2028
                                            </option>
                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?> selected <?php endif; ?>>2029
                                            </option>
                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?> selected <?php endif; ?>>2030
                                            </option>
                                        </select>
                                    </div>
                                       
                                    <div class="d-flex justify-content-end">
                                        <?php if(!empty(Request::get('m')) && !empty(Request::get('y'))): ?>
                                        
                                        <a href="<?php echo e(url('tax-collection')); ?>" class="btn btn-sm btn-danger btn-active-light-danger me-2 "
                                            >Reset Filter</a>
                                        <?php endif; ?>
                                        <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Close</button>
                                        <button type="submit" class="btn btn-sm btn-primary" >Apply</button>
                                    </div>
                                        
                                </div>
                            </form>
                        </div>
                    </div>

                </div> 

                
                <div class="card-body py-3">
                    
                    <div class="dt-buttons btn-group flex-wrap"><a href="<?php echo e(url('tax-slab/download-tax-collection-pdf?month='.$month.'&year='.$year )); ?>" class="btn btn-secondary buttons-excel buttons-html5 mb-5 btn-sm btn-primary" tabindex="0" target="_blank" ><span>Download Tax Collection Record</span></a> </div>

                    <div class="table-responsive popup-visible ">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer table-row-bordered"><div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer" id="system_datatable" aria-describedby="tableEmployee_info">
                                
                                
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="text-center" >Slip No.</th>
                                        <th>Employee Name</th>
                                        <th>Pay Period</th>
                                        <th>Net Salary</th>
                                        <th>Tax Amount</th>
                                        <th>Generation Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($fetch_employee_tax)): ?>
                                        <?php $__currentLoopData = $fetch_employee_tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-8"><?php echo e($employee_tax['pc_id']); ?></td>
                                                <td><?php echo CustomHelper::getEmpProfileDiv($employee_tax['pc_employee_id']); ?></td>
                                                <td><?php echo e(date('M-Y',strtotime($employee_tax['pc_year'].'-'.$employee_tax['pc_month'].'-'.'01'))); ?> </td>
                                                
                                                <td><?php echo e($employee_tax['pc_employee_net_salary']); ?></td>
                                                <td><?php echo e($employee_tax['total_tax_collection']); ?></td>

                                                <td><?php echo e(date('d-M-Y',strtotime($employee_tax['pc_created_at']))); ?></td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/tax-slab/tax-collection.blade.php ENDPATH**/ ?>