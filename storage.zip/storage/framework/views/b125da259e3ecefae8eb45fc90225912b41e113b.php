<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Attendance Report</title>
		
	<meta name="description" content="More than five years back a group of few members started SourceCode Aiming to provide website solutions and solutions to businesses through daily needed performing software like HRM/ERP to ease management businesses.">


	<meta itemprop="name" content="Portal || SourceCode">
	<meta itemprop="description" content="More than five years back a group of few members started SourceCode Aiming to provide website solutions and solutions to businesses through daily needed performing software like HRM/ERP to ease management businesses.">


	<meta property="og:type" content="website">
	<meta property="og:title" content="Portal || SourceCode">
	<meta property="og:description" content="More than five years back a group of few members started SourceCode Aiming to provide website solutions and solutions to businesses through daily needed performing software like HRM/ERP to ease management businesses.">
    <link rel="icon" href="<?php echo e(url('portal_assets/images/fav-icons.png')); ?>" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	
	<style>
        .hr{
           border: 1px solid black;
           margin-top: 1px;
        }

        th,td{
            font-size: 12px;
        }
	
	</style>
</head>
  
<body>
    <?php
        $companySetting = CustomHelper::hcm_default_settings();
    ?>

    <div class="container mt-3">
        <div class="row">
            <div class="col-md-4">
                <?php if(!empty($companySetting['company_logo'])): ?>
                    <img src="<?php echo e($companySetting['company_logo']); ?>" draggable="false" alt="logo" class="logo">
                <?php else: ?>
                     <img src="<?php echo e(url('/portal_assets/images/default-img.png')); ?>" draggable="false" class="img-fluid" >
                <?php endif; ?>
        
            </div>
            <div class="col-md-6 mt-4">
                <h1 style="padding-left:84px;"><?php echo e($companySetting['company_name']); ?></h1>
            </div>
          
            <div class="col-md-2 mt-4">
            
                
                <?php if(!empty(Request::get('employee_id'))): ?>
                    <a href="<?php echo e(url('download-attendance-report?employee_id='.Request::get('employee_id').'&month='.$month.'&year='.$year)); ?>" class="btn btn-sm fw-bold btn-primary">Download Attendance</a>
                <?php else: ?>
                    <a href="<?php echo e(url('download-attendance-report?month='.$month.'&year='.$year)); ?>"  class="btn btn-sm fw-bold btn-primary" >Download Attendance</a>
                <?php endif; ?>
                
        
            </div>
   
            <hr class="hr">
           
        </div>
    </div>

    <div class="container mt-3">
        <h4 class="text-center">Employee Attendance Sheet</h4>
        <div class="row mb-5 mt-5">
            
            <div class="col-md-5">
                <div class="row">
                    <div class="col-md-4">
                        <label><b>Employee Id</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e(!empty($employee) ? $employee[0]['employee_code'] : ''); ?></span>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-4">
                        <label><b>Employee Name</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e(!empty($employee) ?$employee[0]['employee_name'] : ''); ?></span>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-4">
                        <label><b>Position:</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e(!empty($employee) ? $employee[0]['employee_jobtitle'] : ''); ?></span>
                    </div>
                </div>
               
            </div>
            <div class="col-md-2">
              
            </div>
            <div class="col-md-5">
                <div class="row">
                    <div class="col-md-4">
                        <label><b>Department:</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e(!empty($employee) ? $employee[0]['department_name'] : ''); ?></span>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-4">
                        <label><b>Designation:</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e(!empty($employee) ? $employee[0]['designation_name'] : ''); ?></span>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-4">
                        <label><b>Location</b></label>
                    </div>
                    <div class="col-md-8">
                        <span><?php echo e($companySetting['company_address']); ?></span>
                    </div>
                </div>
              
            </div>

        </div>

        <div class="row">
            <table class="table table-bordered">
                <thead>
                    <tr style="background:lightgray">
                        <th rowspan="2" class="text-center">Attendance Date </th>
                        <th colspan="2" class="text-center">Check In</th>
                        <th colspan="2" class="text-center">Check Out </th>
                        <th rowspan="2" class="text-center">Work Hours</th>
                        <th rowspan="2" class="text-center">Extra Hours</th>
                        <th rowspan="2" class="text-center">Late Minutes</th>
                        <th rowspan="2" class="text-center">Early Depar. Minutes</th>
                        <th rowspan="2" class="text-center">Leave/Deputation</th>
                        <th rowspan="2" class="text-center">Att Source</th>
                        <th rowspan="2" class="text-center">Status</th>
                    </tr>
                    <tr style="background:lightgray">
                    
                        <th class="text-center">Date</th>
                        <th class="text-center">Time</th>
                        <th class="text-center">Date</th>
                        <th class="text-center">Time</th>

                    </tr>
                </thead>

                <tbody>
                    <?php for($month_count = 1; $month_count <= $month_days; $month_count++): ?>
                    <?php $absent = true; ?>
                    <tr>
                        <?php
                                               
                            $current_date = $month_count . '-' . $month . '-' . $year;
                            $nameOfDay = date("l", strtotime($current_date ));	
                        ?>
                        
                        <td class="text-center">
                            <?php echo e($current_date); ?>

                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php endif; ?>

                                        <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                            <?php echo e($attendance['att_check_in_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                            <?php echo e($attendance['att_check_in_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                            <?php echo e($attendance['att_check_in_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                            <?php echo e($attendance['att_check_in_time']); ?>

                                        <?php endif; ?>

                                        <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                            <?php echo e($current_date); ?>

                                        <?php endif; ?>

                                        <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e($attendance['att_check_out_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e($attendance['att_check_out_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e($attendance['att_check_out_time']); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                        <?php echo e($attendance['att_check_out_time']); ?>

                                        <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                           
                                        <?php endif; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>  
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                            <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                            <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                            <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                            <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                        <?php endif; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>

                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $employee_shift_times =  CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                        $employee_working_hours =   CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time']);
                                    
                                    ?>
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        
                                        <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                        
                                        <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                            
                                        <?php endif; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($employee) && $employee[0]['employee_shift_flexibilty'] != 1): ?>
                                <?php if(!empty($attendances)): ?>

                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $employee_shift_times =  CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                        ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            
                                            <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            
                                            <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                            <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                                
                                            <?php endif; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>

                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php 
                                        $employee_shift_times =  CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                        $employee_working_hours =   CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time']);
                                    ?>
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                        <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                        <?php endif; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            00:00:00
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_request_approval'] == 1): ?>
                                            Attendance Request
                                        <?php endif; ?>
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center"> 
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($attendance['att_for_date'] == $month_count): ?>
                                    <?php $absent = false; ?>
                                    <?php if($attendance['att_source'] == 1): ?>
                                        Web Application
                                    <?php elseif($attendance['att_source'] == 2): ?>
                                        Mobile Application
                                    <?php elseif($attendance['att_source'] == 3): ?>
                                       Updated Attendance
                                    <?php else: ?>
                                        Machine Attendance
                                    <?php endif; ?>
                                <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                        <td class="text-center"> 
                            <?php if(!empty($attendances)): ?>
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($attendance['att_for_date'] == $month_count): ?>
                                        <?php $absent = false; ?>
                                        <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                            On Time
                                        <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                            Half Day
                                        <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                            Late Coming
                                        <?php elseif($attendance['att_check_overall_status'] == 'Casual Leave'): ?>
                                            Casual Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Annual Leave'): ?>
                                            Annual Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Sick Leave'): ?>
                                            Sick Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Maternity Leave'): ?>
                                            Maternity Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Paternity Leave'): ?>
                                            Paternity Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                            Bereavement Leave
                                        <?php elseif($attendance['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                            Compensatory Leave                    
                                        <?php elseif($attendance['att_check_overall_status'] == 'Absent'): ?>
                                            Absent
                                        <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                            Early out
                                        <?php elseif(substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                            Holiday
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php
                              
                                $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                $today = strtotime(date("Y-m-d"));
                            ?>
                            
                            <?php if($absent ): ?>
                                
                                <?php if( $employee[0]['employee_offday1'] == $nameOfDay || $employee[0]['employee_offday2'] == $nameOfDay ): ?>
                                    Off Day

                                <?php elseif($date_filter< $today): ?>
                                   Absent
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            
                        </td> 
                    </tr>
                    <?php endfor; ?>
                </tbody>
            </table>

        </div>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>





</body>
</html><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/attendance/attendance-report.blade.php ENDPATH**/ ?>