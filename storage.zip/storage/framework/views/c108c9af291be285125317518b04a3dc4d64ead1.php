

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Employee Resignation Form</h1>
                
                
                
                
            </div>
            
            
           
        </div>
        
    </div>
    
    
    <?php if(empty($resignation_status) || (!empty($resignation_status) && $resignation_status[0]['resignation_status'] == '3')): ?>
        <div id="kt_app_content" class="app-content flex-column-fluid">
            <div id="kt_app_content_container" class="app-container">
                <div class="card mb-5 mb-xl-8">
                    <div class="card-body py-8 pt-12">
                        <form id="add_employee_resignation_form" class="form" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <div class="row g-9 mb-8">
                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Employee Name</span>
                                    </label>
                                    <input type="text" class="form-control " value="<?php echo e($login_user[0]['employee_name'] ?? 'N/A'); ?>" readonly />
                                </div>

                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Employee Department </span>
                                    </label>
                                    <input type="text" class="form-control " value="<?php echo e($department_name[0]['department_name'] ?? 'N/A'); ?>" readonly/>
                                </div>

                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Employee Designation</span>
                                    </label>
                                    <input type="text" class="form-control " value="<?php echo e($designation_name[0]['designation_name'] ?? 'N/A'); ?>" readonly/>
                                </div>
                            </div>
                            <div class="row g-9 mb-8">
                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required"> Notice Period Start Date</span>
                                    </label>
                                    <input type="date" class="form-control " value="<?php echo e(date('Y-m-d')); ?>" min="<?php echo e(date('Y-m-d')); ?>" id="fromDate" name="from_date" required="required" />
                                </div>

                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Notice Period End Date </span>
                                    </label>
                                    <input type="date" class="form-control " placeholder="mm/dd/yyyy" id="toDate"   min="<?php echo e(date('Y-m-d')); ?>" name="to_date" required="required" />
                                </div>

                                <div class="col-md-4 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Notice Period Total Days</span>
                                    </label>
                                    <input type="text" class="form-control " placeholder="Total Notice Period Days" id="days"  readonly/>
                                </div>
                            </div>

                            <div class="row g-9 mb-8">
                                <div class="col-md-12 fv-row">
                                    <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                        <span class="required">Resignation Description</span>
                                    </label>
                                    <textarea class="form-control " placeholder="Enter a Description" rows="4" name="reason" required="required" id="description" ></textarea>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-lg btn-success" id="submit_btn">
                                    <span class="indicator-label">Submit Resignation</span>
                                        <span class="indicator-progress">Please wait... 
                                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                                    </span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    <?php endif; ?>

    <?php if(!empty($resignations)): ?>
        <div id="kt_app_content" class="app-content flex-column-fluid mt-5">
            
            <div id="kt_app_content_container" class="app-container">
                
                <div class="row">
                    <?php $__currentLoopData = $resignations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resignation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-12 ">
                            <div class="card mb-5 mb-xl-8">
                                <div class="d-flex flex-row-reverse ribbon ribbon-start ribbon-clip">
                                    <div class="ribbon-label fw-bolder">
                                        <?php if($resignation['resignation_status'] == 1): ?>
                                            Resignation Approval Pending
                                        <span class="ribbon-inner bg-gray"></span>
                                        <?php elseif($resignation['resignation_status'] == 2): ?>
                                            Resignation Approved
                                        <span class="ribbon-inner bg-success"></span>
                                        <?php else: ?>
                                            Resignation Rejected
                                        <span class="ribbon-inner bg-danger"></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="card-body py-8 pt-12 ">
                                    <div class="row g-9 mb-8">
                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span class="required">Employee Name</span>
                                            </label>
                                            <input type="text" class="form-control " value="<?php echo e($login_user[0]['employee_name'] ?? 'N/A'); ?>" readonly />
                                        </div>

                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span class="required">Employee Department </span>
                                            </label>
                                            <input type="text" class="form-control " value="<?php echo e($department_name[0]['department_name'] ?? 'N/A'); ?>" readonly/>
                                        </div>

                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span class="required">Employee Designation</span>
                                            </label>
                                            <input type="text" class="form-control " value="<?php echo e($designation_name[0]['designation_name'] ?? 'N/A'); ?>" readonly/>
                                        </div>
                                    </div>
        
                                    <div class="row g-9 mb-8">
                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span> Notice Period Start Date</span>
                                            </label>
                                            <input type="date" class="form-control " value="<?php echo e($resignation['resignation_from_date']); ?>" readonly id="fromDate" name="from_date"
                                            required="required" />
                                        </div>
                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span>Notice Period End Date </span>
                                            </label>
                                            <input type="date" class="form-control " value="<?php echo e($resignation['resignation_to_date']); ?>" id="toDate" readonly   name="to_date"
                                            required="required" />
                                        </div>
        
                                        <div class="col-md-4 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span> Notice Period Total Days</span>
                                            </label>
                                            <?php
                                                $startDate = new DateTime($resignation['resignation_from_date']); 
                                                $endDate = new DateTime($resignation['resignation_to_date']);
                                                $total_days = $endDate->diff($startDate)->format("%a");
                                            ?>
                                            <input type="text" class="form-control " value="<?php echo e($total_days+1); ?>" readonly  />
                                        </div>
                                    </div>
        
                                    <div class="row g-9 mb-8">
                                        <div class="col-md-12 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span>Resignation Description</span>
                                            </label>
                                            <textarea class="form-control " placeholder="Enter a Description" rows="4" name="reason" readonly><?php echo e($resignation['resignation_description']); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
  

    $('#toDate,#fromDate').change(function(){
        
        var start = moment($('#fromDate').val());
        $('#toDate').attr('min',$('#fromDate').val());
        var end = moment($(this).val());
        total_days = end.diff(start,"days");
        $('#days').val(total_days+1);
    });


    $('#add_employee_resignation_form').submit(function(e) {
        e.preventDefault();

        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        
        swal.fire({
            title: 'Confirmation Alert !',
            text: 'Are you sure to submit your resignation letter ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText:'Yes',
            cancelButtonText:'Cancel',
        }).then(function (value) { 
          
            if (value.isConfirmed == true) {
                $.ajax({
                    url: '<?php echo e(url('add-employee-resignation')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: $('#add_employee_resignation_form').serialize(),
                    success: function(data) {
                        console.log(data);
                        if (data.status == 'TRUE') {
                            Toast.fire({
                                icon: 'success',
                                title: data.msg,
                                timer: 3000,
                            })
                            setTimeout(() => {
                                location.reload();
                            }, 3000);
                        } else {
                            Toast.fire({
                                icon: 'warning',
                                title: data.msg,
                                timer: 8000,
                            })
                            $('#submit_btn').prop('disabled', false);
                            $("#submit_btn").removeAttr('data-kt-indicator');
                            $('#submit_btn').css('cursor', 'pointer');
                        }
                    },
                    error: function(jqXHR, textStatus) {
                        var errorStatus = jqXHR.status;
                        $('#submit_btn').prop('disabled', false);
                        $("#submit_btn").removeAttr('data-kt-indicator');
                        $('#submit_btn').css('cursor', 'pointer');
                        if (errorStatus == 0) {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Internet Connection Problem',
                                timer: 3000,
                            })
                        } else {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Try Again. Error Code ' + errorStatus,
                                timer: 3000,
                            })
                        }
                    }
                });
            }else{
                location.reload();
            }
        });
    });

  
      
    
 
</script>


    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/resignation/employee-resignation.blade.php ENDPATH**/ ?>