
    </div>
    
    </div>
    
    </div>
    
    </div>
    
   <script>

      var user_id = "<?php echo e(session('user_session')); ?>";
      var base_url = "<?php echo e(url('/')); ?>";
      var gl;
   
   </script>
   
    <script type="text/javascript" src="<?php echo e(url('assets/js/general_script.js')); ?>"></script>
    
    <script type="text/javascript" src="<?php echo e(url('assets/plugins/global/plugins.bundle.js')); ?>"></script>
    

    <script type="text/javascript" src="<?php echo e(url('assets/js/scripts.bundle.js')); ?>"></script>
    
    
    
    <script type="text/javascript" src="<?php echo e(url('assets/plugins/custom/datatables/datatables.bundle.js')); ?>"></script>
    
    
    

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" crossorigin="anonymous"></script>
   
    <script src="https://cdn.jsdelivr.net/npm/@eonasdan/tempus-dominus@6.2.10/dist/js/tempus-dominus.min.js" crossorigin="anonymous"></script>

    
    <script type="text/javascript" src="<?php echo e(url('assets/js/proxy-user.js')); ?>"></script>

    
    <script type="text/javascript" src="<?php echo e(url('assets/js/fetch-api.js')); ?>"></script>

    
    <script type="text/javascript" src="<?php echo e(url('assets/js/geo-location.js')); ?>"></script>  

    <script>
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: false,
          timer: 3000,
          timerProgressBar: true,
        });

        setTimeout(()=>{
          $('.page-loader').fadeOut()
        })

        
    </script>
    
    
    
    <script type="text/javascript" src="<?php echo e(url('assets/js/payslip-password-verification.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('js-link'); ?>
    
    
	</body>
	

</html><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/layout/footer.blade.php ENDPATH**/ ?>