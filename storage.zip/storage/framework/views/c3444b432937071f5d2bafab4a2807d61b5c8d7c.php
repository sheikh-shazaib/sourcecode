

<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
       
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                    <?php if(empty($month) && empty($year)): ?>
                        My Attendance (<?php echo e(date('F') . '-' . date('Y')); ?>)
                    <?php else: ?>
                        My Attendance (<?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?>)
                    <?php endif; ?>
                </h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <div class="d-flex align-items-center gap-2 gap-lg-3">
                    <a href="<?php echo e(url('my-attendance-report?month='.$month.'&year='.$year)); ?>" target="_blank"  class="btn btn-sm fw-bold btn-primary" >View Attendance Report</a>
                </div>

            </div>
            
        </div>
       
    </div>
    
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            <div class="row">
                    
                <div class="col-md-2 col-6 filter-record mb-4" data-value="On Time"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2" id="present">0</div>
                            <div class="fw-semibold text-gray-400 ">Present</div>
                        </div>
                    </div>
                </div>


                <div class="col-md-2 col-6  filter-record mb-4" data-value="Absent"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2" id="absent">0</div>
                            <div class="fw-semibold text-gray-400">Absent </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-2 col-6  filter-record mb-4" data-value="Late Coming"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2" id="lateComing">0</div>
                            <div class="fw-semibold text-gray-400">Late Coming</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 col-6  filter-record mb-4" data-value="Half Day"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2 " id="HalfDay">0</div>
                            <div class="fw-semibold text-gray-400">Half Day</div>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 col-6 filter-record mb-4" data-value="Off Day"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2 " id="offdays">0</div>
                            <div class="fw-semibold text-gray-400">Off Days</div>
                        </div>
                    </div>
                </div>    

                <div class="col-md-2 col-6 filter-record mb-4" data-value="Leave"  style="cursor: pointer">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-gray-900 fw-bold fs-2" id="Leaves"><?php echo e($t_employee_leaves??''); ?></div>
                            <div class="fw-semibold text-gray-400 ">Leaves</div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1 me-5">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                        
                      
                    </div>
                    <div class="card-toolbar" >
                        
                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                    
                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter</a>
                       
                            <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                <form action="<?php echo e(url('my-attendance')); ?>" method="GET">
                                    <div class="px-7 py-5">
                                        <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                    </div>

                                    <div class="separator border-gray-200"></div>
                                    <div class="px-7 py-5">
                                        
                                        <div class="mb-3">
                                            
                                            <label class="form-label fw-semibold">Month</label>
                                            
                                            <select class="form-select " data-kt-select2="true" data-placeholder="Select Month"name="m"
                                                required="required">
                                                <option value="">Select Month</option>
                                                <option value="01" <?php if(!empty($month) && $month == '01'): ?> selected <?php elseif(empty($month) && date('m') == '01'): ?> selected <?php endif; ?>>January
                                                </option>
                                                <option value="02" <?php if(!empty($month) && $month == '02'): ?> selected <?php elseif(empty($month) && date('m') == '02'): ?> selected <?php endif; ?>>February
                                                </option>
                                                <option value="03" <?php if(!empty($month) && $month == '03'): ?> selected <?php elseif(empty($month) && date('m') == '03'): ?> selected <?php endif; ?>>March
                                                </option>
                                                <option value="04" <?php if(!empty($month) && $month == '04'): ?> selected <?php elseif(empty($month) && date('m') == '04'): ?> selected <?php endif; ?>>April
                                                </option>
                                                <option value="05" <?php if(!empty($month) && $month == '05'): ?> selected <?php elseif(empty($month) && date('m') == '05'): ?> selected <?php endif; ?>>May
                                                </option>
                                                <option value="06" <?php if(!empty($month) && $month == '06'): ?> selected <?php elseif(empty($month) && date('m') == '06'): ?> selected <?php endif; ?>>June
                                                </option>
                                                <option value="07" <?php if(!empty($month) && $month == '07'): ?> selected <?php elseif(empty($month) && date('m') == '07'): ?> selected <?php endif; ?>>July
                                                </option>
                                                <option value="08" <?php if(!empty($month) && $month == '08'): ?> selected <?php elseif(empty($month) && date('m') == '08'): ?> selected <?php endif; ?>>August
                                                </option>
                                                <option value="09" <?php if(!empty($month) && $month == '09'): ?> selected <?php elseif(empty($month) && date('m') == '09'): ?> selected <?php endif; ?>>September
                                                </option>
                                                <option value="10" <?php if(!empty($month) && $month == '10'): ?> selected <?php elseif(empty($month) && date('m') == '10'): ?> selected <?php endif; ?>>October
                                                </option>
                                                <option value="11" <?php if(!empty($month) && $month == '11'): ?> selected <?php elseif(empty($month) && date('m') == '11'): ?> selected <?php endif; ?>>November
                                                </option>
                                                <option value="12" <?php if(!empty($month) && $month == '12'): ?> selected <?php elseif(empty($month) && date('m') == '12'): ?> selected <?php endif; ?>>December
                                                </option>
                                            </select>
                                       
                                            
                                        </div>
                                        <div class="mb-3">
                                            
                                            <label class="form-label fw-semibold">Attendance Year</label>
                                            
                                                <select class="form-select " data-kt-select2="true" data-placeholder="Select Year" name="y" required="required">
                                                    <option value="">Select Year</option>
                                                    <option value="2020" <?php if(!empty($year) && $year == '2020'): ?> selected <?php elseif(empty($year) && date('Y') == '2020'): ?> selected <?php endif; ?>>2020
                                                    </option>
                                                    <option value="2021" <?php if(!empty($year) && $year == '2021'): ?> selected <?php elseif(empty($year) && date('Y') == '2021'): ?> selected <?php endif; ?>>2021
                                                    </option>
                                                    <option value="2022" <?php if(!empty($year) && $year == '2022'): ?> selected <?php elseif(empty($year) && date('Y') == '2022'): ?> selected <?php endif; ?>>2022
                                                    </option>
                                                    <option value="2023" <?php if(!empty($year) && $year == '2023'): ?> selected <?php elseif(empty($year) && date('Y') == '2023'): ?> selected <?php endif; ?>>2023
                                                    </option>
                                                    <option value="2024" <?php if(!empty($year) && $year == '2024'): ?> selected <?php elseif(empty($year) && date('Y') == '2024'): ?> selected <?php endif; ?>>2024
                                                    </option>
                                                    <option value="2025" <?php if(!empty($year) && $year == '2025'): ?> selected <?php elseif(empty($year) && date('Y') == '2025'): ?> selected <?php endif; ?>>2025
                                                    </option>
                                                    <option value="2026" <?php if(!empty($year) && $year == '2026'): ?> selected <?php elseif(empty($year) && date('Y') == '2026'): ?> selected <?php endif; ?>>2026
                                                    </option>
                                                    <option value="2027" <?php if(!empty($year) && $year == '2027'): ?> selected <?php elseif(empty($year) && date('Y') == '2027'): ?> selected <?php endif; ?>>2027
                                                    </option>
                                                    <option value="2028" <?php if(!empty($year) && $year == '2028'): ?> selected <?php elseif(empty($year) && date('Y') == '2028'): ?> selected <?php endif; ?>>2028
                                                    </option>
                                                    <option value="2029" <?php if(!empty($year) && $year == '2029'): ?> selected <?php elseif(empty($year) && date('Y') == '2029'): ?> selected <?php endif; ?>>2029
                                                    </option>
                                                    <option value="2030" <?php if(!empty($year) && $year == '2030'): ?> selected <?php elseif(empty($year) && date('Y') == '2030'): ?> selected <?php endif; ?>>2030
                                                    </option>
                                                </select>
                                     
                                            
                                        </div>
                                       
                                        <div class="d-flex justify-content-end">
                                            <?php if(!empty(Request::get('m')) && !empty(Request::get('y'))): ?>
                                                <a href="<?php echo e(url('my-attendance')); ?>" class="btn btn-sm btn-danger btn-active-light-danger me-2">Reset Filter</a>
                                             <?php endif; ?>
                                            <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Close</button>
                                            <button type="submit" class="btn btn-sm btn-primary" >Apply</button>
                                        </div>
                                        
                                    </div>
                                 </form>
                            </div>
                       
                    </div>
                </div>
                    <div class="card-body py-3">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="table-responsive popup-visible ">
                                <table class="table table-bordered align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="system_datatable">
                                                                    
                                    <thead>
                                        <tr class="fw-bold text-muted bg-light">
                                            <th class="ps-8">Date</th>
                                            <th class="text-center">Check In Time </th>
                                            <th class="text-center">Check Out Time</th>
                                            <th class="text-center">Shift Duration</th>
                                            <th class="text-center">Leave/Deputation</th>
                                            <th class="text-center">Att Source</th>
                                            <th class="text-center">Hours Worked</th>
                                            <th class="text-center">Status</th>
                                        
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $total_working_hours = 0;
                                        $total_working_hours_actual = 0;
                                        $in_day_time_actual = $out_day_time_actual = 0 ;
                                        $present = 0;
                                        $halfday = 0;
                                        $late_coming = 0;
                                        $offdays = 0;
                                        $absent_count = 0;
                                        

                                        $attendance_total_count = count($attendance);
                                        ?>
                                       
                                        <?php for($month_count = 1; $month_count <= $month_days; $month_count++): ?>
                                        <?php $absent = true;
                                        $loop_count = 0;
                                        $helper_absent = false;

                                        ?>
                                        <tr>
                                        
                                            <?php
                                               
                                                $current_date = $month_count . '-' . $month . '-' . $year;
                                                $nameOfDay = date("l", strtotime($current_date ));	
                                            ?>
                                            
                                            <td class="ps-8">
                                                <?php echo e($current_date); ?> - <?php echo e($nameOfDay); ?>

                                            </td>

                                            <td  class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       
                                                        
                                                        <?php if($attendances['att_for_date'] == $month_count): ?>
                                                            
                                                            <?php $absent = false; ?>
                                                           
                                                            <?php if($attendances['att_check_overall_status'] == 'Present'): ?>
                                                                <?php echo e($attendances['att_check_in_time']); ?>

                                                            <?php elseif($attendances['att_check_overall_status'] == 'Half day'): ?>
                                                                <?php echo e($attendances['att_check_in_time']); ?>

                                                            <?php elseif($attendances['att_check_overall_status'] == 'Late Coming'): ?>
                                                                <?php echo e($attendances['att_check_in_time']); ?>

                                                            <?php elseif($attendances['att_check_overall_status'] == 'Casual Leave'): ?>
                                                                    00:00:00
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Annual Leave'): ?>
                                                                    00:00:00
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Sick Leave'): ?>
                                                                    00:00:00
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                                    00:00:00
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                                    00:00:00        
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                                    00:00:00       
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                                    00:00:00       
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Absent'): ?>
                                                                    00:00:00
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Early out'): ?>
                                                             <?php echo e($attendances['att_check_in_time']); ?>

                                                            <?php elseif(substr($attendances['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                                    00:00:00
                                                            <?php endif; ?>
                                                        <?php endif; ?>  
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                <?php
                                                   
                                                    $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                                    $today = strtotime(date("Y-m-d"));
                                                    ?>
                                                    
                                                    <?php if($absent ): ?>
                                                        <?php if( $login_user[0]['employee_offday1'] == $nameOfDay || $login_user[0]['employee_offday2'] == $nameOfDay ): ?>
                                                           00:00:00

                                                        <?php elseif($date_filter< $today): ?>
                                                            00:00:00
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                              
                                                
                                            </td> 

                                            <td  class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($attendances['att_for_date'] == $month_count): ?>
                                                        <?php $absent = false; ?>
                                                        <?php if($attendances['att_check_overall_status'] == 'Present'): ?>
                                                            <?php echo e($attendances['att_check_out_time']); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Half day'): ?>
                                                            <?php echo e($attendances['att_check_out_time']); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Late Coming'): ?>
                                                            <?php echo e($attendances['att_check_out_time']); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Casual Leave'): ?>
                                                                00:00:00
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Annual Leave'): ?>
                                                                00:00:00
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Sick Leave'): ?>
                                                                00:00:00
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                                00:00:00
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                                00:00:00        
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                                00:00:00       
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                                00:00:00               
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Absent'): ?>
                                                                00:00:00
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Early out'): ?>
                                                             <?php echo e($attendances['att_check_out_time']); ?>

                                                        <?php elseif(substr($attendances['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                                00:00:00
                                                        <?php endif; ?>
                                                    <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                <?php
                                                   
                                                    
                                                    $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                                    $today = strtotime(date("Y-m-d"));
                                                ?>
                                                
                                                <?php if($absent ): ?>
                                                    <?php if( $login_user[0]['employee_offday1'] == $nameOfDay || $login_user[0]['employee_offday2'] == $nameOfDay ): ?>
                                                        00:00:00

                                                    <?php elseif($date_filter< $today): ?>
                                                         00:00:00
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                              
                                                
                                            </td> 
                                            
                                            <td  class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($attendances['att_for_date'] == $month_count): ?>
                                                            <?php $absent = false; ?>
                                                            <?php if($attendances['att_check_overall_status'] == 'Present'): ?>
                                                                <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_shift_start_time'],$attendances['att_shift_end_time'])); ?>

                                                               
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Half day'): ?>
                                                                <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_shift_start_time'],$attendances['att_shift_end_time'])); ?>

                                                               
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Late Coming'): ?>
                                                                <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_shift_start_time'],$attendances['att_shift_end_time'])); ?>

                                                               
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Casual Leave'): ?>
                                                                    00:00:00
                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Annual Leave'): ?>
                                                                   00:00:00
                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Sick Leave'): ?>
                                                                   00:00:00
                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                                   00:00:00
                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                                   00:00:00       
                                                                        
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                                   00:00:00      
                                                                        
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                                   00:00:00                     
                                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Absent'): ?>
                                                                   00:00:00
                                                                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Early out'): ?>
                                                                <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_shift_start_time'],$attendances['att_shift_end_time'])); ?>

                                                               
                                                            <?php elseif(substr($attendances['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                                    00:00:00
                                                            <?php endif; ?>
                                                        <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    <?php if($absent ): ?>
                                                        <?php if( $login_user[0]['employee_offday1'] == $nameOfDay || $login_user[0]['employee_offday2'] == $nameOfDay ): ?>
                                                            00:00:00
                                                        <?php elseif($date_filter < $today): ?>
                                                            00:00:00
                                                        <?php endif; ?>
                                                    <?php endif; ?>

                                                <?php endif; ?>
                                            </td> 

                                            <td  class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($attendances['att_for_date'] == $month_count): ?>
                                                            <?php $absent = false; ?>
                                                            <?php if($attendances['att_request_approval'] == 1): ?>
                                                                <span class="badge badge-light-danger text-center font-weight-bold">Attendance Request</span>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td> 

                                            <td  class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($attendances['att_for_date'] == $month_count): ?>
                                                        <?php $absent = false; ?>
                                                        <?php if($attendances['att_source'] == 1): ?>
                                                            <span class="badge badge-light-success text-center font-weight-bold">Web Application</span>
                                                        <?php elseif($attendances['att_source'] == 2): ?>
                                                            <span class="badge badge-light-info text-center font-weight-bold">Mobile Application</span>
                                                        <?php elseif($attendances['att_source'] == 3): ?>
                                                            <span class="badge badge-light-danger text-center font-weight-bold">Updated Attendance</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-light-success text-center font-weight-bold">Machine Attendance</span>
                                                        <?php endif; ?>
                                                    <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                              
                                            </td> 

                                            <td class="text-center">
                                                 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                                
                                                        $calculate_working_hour = CustomHelper::calculate_working_hour($attendances['att_for_year'],$attendances['att_for_month'],$attendances['att_for_date'],$attendances['att_check_in_time'],$attendances['att_check_out_time'],$attendances['att_shift_start_time'],$attendances['att_shift_end_time'],$month_count,$attendances['att_check_overall_status'],$month,$year,$total_working_hours,$total_working_hours_actual,$login_user[0]['employee_offday1'] ,$login_user[0]['employee_offday2'] ,$helper_absent,$attendance_total_count,$loop_count);

                                                        $total_working_hours = $calculate_working_hour['total_working_hours'];
                                                        $total_working_hours_actual = $calculate_working_hour['total_working_hours_actual'];
                                                        $helper_absent = $calculate_working_hour['helper_absent'];
                                                        $loop_count = $calculate_working_hour['loop_count'];
                                                        $total_working_hour_of_this_day = $calculate_working_hour['total_working_hour_of_this_day'];
                                                        //echo $total_working_hour_of_this_day;
                                                        ?>
                                                        
                                                    <?php if($attendances['att_for_date'] == $month_count): ?>
                                                        <?php $absent = false; ?>
                                                        <?php if($attendances['att_check_overall_status'] == 'Present'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_check_in_time'],$attendances['att_check_out_time'])); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Half day'): ?>
                                                           <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_check_in_time'],$attendances['att_check_out_time'])); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Late Coming'): ?>
                                                           <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_check_in_time'],$attendances['att_check_out_time'])); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Casual Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Annual Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Sick Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>   
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?> 
                                                        <?php elseif($attendances['att_check_overall_status'] == 'Absent'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php elseif($attendances['att_check_overall_status'] == 'Early out'): ?>
                                                           <?php echo e(CustomHelper::calculate_shift_timings($attendances['att_check_in_time'],$attendances['att_check_out_time'])); ?>

                                                        <?php elseif(substr($attendances['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                            <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?> 
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>

                                                <?php
                                               
                                                $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                                $today = strtotime(date("Y-m-d"));
                                                ?>
                                                
                                                <?php if($absent ): ?>
                                                    <?php if( $login_user[0]['employee_offday1'] == $nameOfDay || $login_user[0]['employee_offday2'] == $nameOfDay ): ?>
                                                        <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                    <?php elseif($date_filter< $today): ?>
                                                        <?php echo e(CustomHelper::calculate_shift_timings('00:00:00','00:00:00')); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>

                                            </td>


                                            
                                            <td class="text-center"> 
                                                <?php if(!empty($attendance)): ?>
                                                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($attendances['att_for_date'] == $month_count): ?>
                                                            <?php $absent = false; ?>
                                                            <?php if($attendances['att_check_overall_status'] == 'Present'): ?>
                                                                <?php  $present++; ?>
                                                                <p class="text-success"><i class="fa-solid fa-calendar-check text-success" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Check In Time : <?php echo e($attendances['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($attendances['att_check_out_time']); ?>" ></i> -- On Time</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Half day'): ?>
                                                                <?php  $halfday++; ?>
                                                                <p class="text-danger"><i class="fa-solid fa-calendar-check text-danger" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Check In Time : <?php echo e($attendances['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($attendances['att_check_out_time']); ?>"></i> -- Half Day</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Late Coming'): ?>
                                                                <?php  $late_coming++; ?>
                                                                <p class="text-gray"><i class="fa-solid fa-calendar-check text-gray" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Check In Time : <?php echo e($attendances['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($attendances['att_check_out_time']); ?>"></i> -- Late Coming</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Casual Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Casual Leave"></i> -- Casual Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Annual Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash"  data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Annual Leave"></i> -- Annual Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Sick Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Sick Leave"></i> -- Sick Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Maternity Leave"></i> -- Maternity Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Paternity Leave"></i> -- Paternity Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Bereavement Leave"></i> -- Bereavement Leave</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-user-large-slash" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Compensatory Leave"></i> -- Compensatory Leave</p>                
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Absent'): ?>
                                                                <p class="text-danger"><i class="fa-solid fa-xmark text-danger" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Absent"></i> -- Absent</p>
                                                            <?php elseif($attendances['att_check_overall_status'] == 'Early out'): ?>
                                                                <p class="text-info"><i class="fa-solid fa-clock text-info" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="Check In Time : <?php echo e($attendances['att_check_in_time']); ?>  &nbsp; &nbsp; Check Out Time : <?php echo e($attendances['att_check_out_time']); ?>"></i> -- Early out</p>
                                                            <?php elseif(substr($attendances['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                                <p class="text-warning"><i class="fa-solid fa-umbrella-beach text-warning" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo e($attendances['att_check_overall_status']); ?>"></i> -- Holiday</p>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <?php
                                                  
                                                    $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                                    $today = strtotime(date("Y-m-d"));
                                                ?>
                                                
                                                <?php if($absent ): ?>
                                                    
                                                    <?php if( $login_user[0]['employee_offday1'] == $nameOfDay || $login_user[0]['employee_offday2'] == $nameOfDay ): ?>
                                                        <?php $offdays++; ?>
                                                        <p class="text-warning">
                                                        <i class="fa-solid fa-sun text-warning" data-bs-toggle="tooltip"
                                                        data-bs-placement="top" data-bs-title="Off Day"></i> -- Off Day</p>

                                                    <?php elseif($date_filter< $today): ?>
                                                        <?php $absent_count++; ?>
                                                        <p class="text-danger">
                                                            <i class="fa-solid fa-xmark text-danger" data-bs-toggle="tooltip"
                                                            data-bs-placement="top" data-bs-title="Absent"></i> -- Absent</p>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                
                                                
                                            </td> 
                                        </tr>
                                        
                                    <?php endfor; ?>
                                    <tr class="bg-light">
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td class="text-center"><?php echo e($calculate_working_hour['hours_actual'] ?? '00:00'); ?></td>
                                    
                                        
                                        <td class="text-center">
                                        <?php echo e($calculate_working_hour['hours_worked'] ?? '00:00'); ?>


                                        </td>
                                        <td></td>
                                    </tr>
                            
                                    </tbody>
                                  
                                
                                </table>
                            
                            </div>
                        
                        </div>
                    
                    </div>
            
                </div>
            </div>
        
        </div>
    
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){

        var  present = <?php echo e($present); ?>;
        var  absent_count = <?php echo e($absent_count); ?>;
        var  late_coming = <?php echo e($late_coming); ?>;
        var  halfday = <?php echo e($halfday); ?>;
        var  offDays = <?php echo e($offdays); ?>;
        
        $('#present').html(present);
        $('#absent').html(absent_count);
        $('#lateComing').html(late_coming);
        $('#HalfDay').html(halfday);
        $('#offdays').html(offDays);
		
      

        $('.filter-record').on('click', function () {
            value = $(this).attr('data-value');
    
            dataTable.search(value).draw();
        });
	});

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/attendance/my-attendance.blade.php ENDPATH**/ ?>