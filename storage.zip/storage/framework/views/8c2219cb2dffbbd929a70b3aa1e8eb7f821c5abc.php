



<?php $__env->startPush('css-link'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<style>
    .has-time{
        border: 1px solid greenyellow;
    }
</style>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Manage Shift Timings</h1>
            </div>            
        </div>
       
    </div>
    
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <h4 class="modal-title pl-4">Select Employees</h4>
                        </div>
                    </div>
                </div>

                

                <div class="card-body py-3">
                    <form  id="shiftEmployeeForm" class="form" autocomplete="off">

                        <?php if(!empty($login_user)): ?>
                            <?php if($login_user[0]['employee_department'] == 1 || $login_user[0]['employee_department'] == 2): ?>
                            <div class="row mt-5" >
                                <div class="col-md-9 fv-row" id="selectDepartmentCalculate" >
                                    <label class="fs-6 fw-semibold mb-2">Department</label>
                                    <select class="form-select" id="departments_all" multiple="multiple" data-hide-search="true" data-kt-select2="true" data-placeholder="Select Department" name="department[]" data-close-on-select="false" >
                                        <?php if(!empty($all_department)): ?>
                                            <?php $__currentLoopData = $all_department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department['department_id']); ?>" ><?php echo e($department['department_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-8 mt-3 fv-row">
                                    
                                    <label class="fs-6 fw-semibold mb-2">All Departments</label>
                                        <label class="form-check form-check-custom me-10 fs-6 fw-semibold mb-2">
                                        
                                        <input class="form-check-input h-20px w-20px" type="checkbox" id="department_all_calculate" name="select_all" value="Select All" /> 
                                
                                    </label>
                                </div> 
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <div class="col-md-12 mb-8 mt-5 fv-row">
                            <label class="fs-6 fw-semibold mb-2">Employees</label>
                            <div class="col-md-12 fv-row">
                                <select class="form-select  " data-control="select2" multiple="multiple" data-hide-search="true" data-close-on-select="false" data-placeholder="Select Employee" name="employee_id[]" id="employees">
                                    <?php if(!empty($employees)): ?>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($employee['employee_id']); ?>"><?php echo e($employee['employee_code']); ?> - <?php echo e($employee['employee_name']); ?></option>';
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            
                        </div>
                        
                    </form>
                </div>
            </div>
            <div class="card mb-5 mb-xl-8" id="tableForm" >

                <div class="card-header border-0 pt-5">
                    
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                </div> 
            
                <div class="card-body py-3">
                    <form id="responseEmployeeShiftForm" >
                        <table class="table table-bordered  table-row-bordered" id="system_datatable"> 
                            
                            <thead>
                                <tr class="fw-bold text-muted bg-light">
                                    <td class="ps-4"></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="date" class="form-control" id="fillDate" min="<?php echo e(date('Y-m-d',strtotime('+1 days'))); ?>" onInput="fillAllDate(this)"></td>
                                    <td><input type="time" class="form-control" id="fillStartTime" onInput="fillAllStartTime(this)" ></td>
                                    <td><input type="time" class="form-control" id="fillEndTime" onInput="fillAllEndTime(this)" ></td>
                                    <td></td>
                                </tr> 

                                <tr class="fw-bold text-muted bg-light">
                                    <th class="ps-4" ></th>
                                    <th>Employee Name</th>
                                    <th>Effected From </th>
                                    <th>Current Start Time</th>
                                    <th>Current End Time</th>
                                    <th>New Effected From </th>
                                    <th>New Start Time </th>
                                    <th>New End Time </th>
                                    <th>Duration</th>
                                </tr>
                            </thead>
                            <tbody id="responseEmployeeShift">
                            </tbody>
                        </table>
                        <div class="modal-footer justify-content-center d-none" id="responseEmployeeShiftSubmitDiv" >
                            <button type="submit" id="responseEmployeeShiftFormButton" class="btn btn-primary">
                                <span class="indicator-label">Update Shift Timings</span>
                                <span class="indicator-progress">Please wait... 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </form>
                </div>
            
            </div>
        
        </div>
    
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    var effected_date_old;
    var shift_start_old;
    var shift_end_old;
    var employee_id = [];
    var record = '';

    $('#department_all_calculate').click(function() {
         
         var checkbox = $('#department_all_calculate').prop('checked');
 
         if(checkbox){
             $('#departments_all option').prop('selected', true);
             $('#selectDepartmentCalculate').find('.select2-selection__rendered').html('<span class="select2-selection__choice__display" id="select2-departments_all-container-choice-5nle-Human Resource">All Departments</span>');
             $('#selectDepartmentCalculate').find('.select2-search__field').attr('placeholder', '');
         }else{
             $('#departments_all option').prop('selected', false);
             $('#selectDepartmentCalculate').find('.select2-selection__rendered').html('');
             $('#selectDepartmentCalculate').find('.select2-search__field').attr('placeholder', 'Select Department');
             $('#selectDepartmentCalculate').find('.select2-search__field').css('width', '100%');
             
         }
           
    })

    $('#responseEmployeeShiftForm').submit(function(e){
        e.preventDefault()
        send_server_request( 'POST' ,'shift-management/add-employee-shift' , this ,'responseEmployeeShiftFormButton', "No" , 'shift-management' ,3000)
    })

    $('#departments_all').change(function(e){
        e.preventDefault();
        $('#employees').html('');
       var dept = $('#departments_all').val();
        $.ajax({
            url: "<?php echo e(url('get-employee-department')); ?>",
            type: 'GET',
                            
            data: {
                department : dept
            },
            success: function(response) {
                $('#employees').append(response);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
                
            }
        });
    })

    $('#shiftEmployeeForm').change(function(e) {

    e.preventDefault();

    var url = "<?php echo e(url('shift-management/get-employee-shift')); ?>"

    let form_data = new FormData(this);

    body_data = {

        // Adding method type
        method: 'POST',

        // Adding body or contents to send
        // body: JSON.stringify({form_data}),
        body : form_data,

        // Adding headers to the request
        headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    }


    fetch(url,body_data)

    // Converting to JSON
    .then(response =>{
        // response.json()
        if (response.ok) {
            return response.json();
        }

        return Promise.reject(response);
    })


    // Displaying results to console
    .then(json =>{

    if (json.status == 'TRUE') {

        $('.odd').remove()
        record = '';

        var current_employee = [];
        var fillDate = $('#fillDate').val();
        var fillStartTime = $('#fillStartTime').val();
        var fillEndTime = $('#fillEndTime').val();

        $.each(json.data, function(key, employee_shift) {

            current_employee.push(employee_shift.employee_id); 

            if(employee_id.indexOf(employee_shift.employee_id) === -1){
                        
                record += `<tr class="dataRow${employee_shift.employee_id}" >
                <td class="ps-4" >
                    <div class="form-check form-check-sm form-check-custom">
                        <input class="form-check-input checked"  type="checkbox" checked onClick="checkedBox(this)"  />
                    </div>
                </td>
                <td><input type="hidden" name="employee_id[]" value="${employee_shift.employee_id}"/> ${employee_shift.employee_name} - ${employee_shift.employee_code}</td>
                <td>${employee_shift.shift_start_from_date}</td>
                <td>${employee_shift.shift_start_time}</td>
                <td>${employee_shift.shift_end_time}</td>
                <td><input type="date" class="form-control effected_date_input ${(fillDate == '') ? '' : 'has-time'}" name="effected_date[]" placeholder="" required="" min="${json.date_max}" onInput="borderClassDate(this)" value="${fillDate}" ></td>
                <td><input type="time" class="form-control shift_start_time_input ${(fillStartTime == '') ? '' : 'has-time'}" name="shift_start_time[]" placeholder="Shift Start Time" required="" pattern="^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$" onInput="borderClassStartTime(this);calculateDuration(this)"  value="${fillStartTime}"></td>
                <td><input type="time" class="form-control shift_end_time_input ${(fillEndTime == '') ? '' : 'has-time'}" name="shift_end_time[]" placeholder="Shift End Time" required="" pattern="^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$" onInput="borderClassEndTime(this);calculateDuration(this)"  value="${fillEndTime}" ></td>
                <td><span> </span></td>
                </tr>`; 

            }
        })

        $('#responseEmployeeShiftSubmitDiv').addClass('d-none')
        $('#responseEmployeeShift').append(record)
        if(record != ''){
            $('#responseEmployeeShiftSubmitDiv').removeClass('d-none')
        }
        
        $.each(employee_id,function(key, value){
            if(current_employee.indexOf(value) == -1){
                removeTd(value)
            }
        });
        
        employee_id = current_employee;
        $(".effected_date_input,.shift_start_time_input,.shift_end_time_input").trigger("input");

    } else {
        $('#responseEmployeeShift').html('')
        employee_id = [];
    }

    }).catch(response => {

    });


    })

    function fillAllDate(e){
        var effected_date = $(e).val();
        $('.effected_date_input').each(function(index, element) {
            var effected_date_input = $(this).val()
            if(effected_date_input == "" || effected_date_input==effected_date_old){
                $(this).val(effected_date)
                $(this).addClass('has-time')
                $(e).addClass('has-time')
            }else{
                $(this).removeClass('has-time')
            }
        });
        effected_date_old = effected_date;
    }

    function fillAllStartTime(e){
        var shift_start = $(e).val();
        $('.shift_start_time_input').each(function(index, element) {
            var check_shift_start = $(this).val()
            if(check_shift_start == "" || check_shift_start==shift_start_old){
                $(this).val(shift_start)
                $(this).addClass('has-time')
                $(e).addClass('has-time')
            }else{
                $(this).removeClass('has-time')
            }
            calculateDuration(this)
        });
        shift_start_old = shift_start;
    }

    function fillAllEndTime(e){
        var shift_end = $(e).val();
        $('.shift_end_time_input').removeClass('has-time')
        $('.shift_end_time_input').each(function(index, element) {
            var check_shift_end = $(this).val()
            if(check_shift_end == "" || check_shift_end==shift_end_old){
                $(this).val(shift_end)
                $(this).addClass('has-time')
                $(e).addClass('has-time')
            }else{
                $(this).removeClass('has-time')
            }
            calculateDuration(this)
        });
        shift_end_old = shift_end;
    }

    function borderClassDate(e){
        var effected_date = $(e).val();
        if(effected_date==effected_date_old){
            $(e).addClass('has-time')
        }else{
            $(e).removeClass('has-time')
        }
    }
    function borderClassStartTime(e){
        var shift_start = $(e).val();
        if(shift_start==shift_start_old){
            $(e).addClass('has-time')
        }else{
            $(e).removeClass('has-time')
        }
    }
    function borderClassEndTime(e){
        var shift_end = $(e).val();
        if(shift_end==shift_end_old){
            $(e).addClass('has-time')
        }else{
            $(e).removeClass('has-time')
        }
    }

    function calculateDuration(e){

        var main_class = $(e).attr("class");

        const substring = "shift_start_time_input";
        if(main_class.includes(substring)){
            var start_time = $(e).val();
            var end_time = $(e).closest('td').next('td').find('input').val();
        }else{
            var end_time = $(e).val();
            var start_time = $(e).closest('td').prev('td').find('input').val();
        } 

        var time_start = new Date();
        var time_end = new Date();
        var value_start = start_time.split(':');
        var value_end = end_time.split(':');

        time_start.setHours(value_start[0], value_start[1], 0, 0)
        time_end.setHours(value_end[0], value_end[1], 0, 0)
        var duration_in_ms = time_end - time_start;
        var duration_period = moment.utc(duration_in_ms).format('HH:mm:ss');
        if(main_class.includes(substring)){
            if(duration_period != 'Invalid date'){
                $(e).closest('td').next('td').next('td').find('span').html(duration_period);
            }
        }else{
            if(duration_period != 'Invalid date'){
                $(e).closest('td').next('td').find('span').html(duration_period);
            }
        }


    }

    function checkedBox(e){
        
        if($(e).is(':checked')){
            $(e).closest('td').next('td').find('input').prop('name','employee_id[]')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',true)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','effected_date[]')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',true)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','shift_start_time_input[]')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',true)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','shift_end_time_input[]')
        }else{
            $(e).closest('td').next('td').find('input').prop('name','')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',false)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').val('')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').find('input').removeClass('has-time')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',false)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').val('')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').removeClass('has-time')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('required',false)
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').prop('name','')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').val('')
            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('input').removeClass('has-time')

            $(e).closest('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').next('td').find('span').html('')
        }
        
    }

    function removeTd(value){
        $('.dataRow'+value).remove();
    }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/shift-management/add-shift.blade.php ENDPATH**/ ?>