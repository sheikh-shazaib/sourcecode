






<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">

    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">

        <div class="app-container col-12 d-flex flex-stack">

            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">

                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Leaves Entitlement

                    <?php if(Request::get('is_active') == '2'): ?>
                        (De-active Employees)
                    <?php else: ?>
                        (Active Employees)
                    <?php endif; ?>
                </h1>
            </div>
        </div>

    </div>

    <div class="app-content flex-column-fluid">

        <div class="app-container">

            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                    <div class="card-toolbar">

                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">

                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter</a>
                        <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1">

                            <div class="px-7 py-5">
                                <div class="fs-5 text-dark fw-bold">Filter Options</div>
                            </div>

                            <div class="separator border-gray-200"></div>
                            <form action="<?php echo e(url('manage-leaves')); ?>" method="GET">
                                <div class="px-7 py-5">

                                    <div class="mb-10">

                                        <label class="form-label fw-semibold">Status</label>

                                        <div>
                                            <select class="form-select" data-kt-select2="true" data-placeholder="Select option" required name="is_active">
                                                <option value="1" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '1'): ?> selected <?php endif; ?>>Active
                                                    Employees</option>
                                                <option value="2" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '2'): ?> selected <?php endif; ?>>De-active
                                                    Employees</option>
                                            </select>
                                        </div>

                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Close</button>
                                        <button type="submit" class="btn btn-sm btn-primary">Apply</button>
                                    </div>

                                </div>
                            </form>

                        </div>
                    </div>
                </div>
                <div class="card-body py-3">

                    <div class="table-responsive popup-visible ">

                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="system_datatable" aria-describedby="tableEmployee_info">

                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-6">Name</th>
                                        <th>Casual Alloted/Availed</th>
                                        <th>Annual Alloted/Availed </th>
                                        <th>Sick Alloted/Availed</th>
                                        <th>Maternity Alloted/Availed</th>
                                        <th>Paternity Alloted/Availed</th>
                                        <th>Bereavement Alloted/Availed</th>
                                        <th>Compensatory Alloted/Availed</th>
                                        <th >Action</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($leaves_entitled)): ?>
                                        <?php $__currentLoopData = $leaves_entitled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaves_entitlement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-6"><?php echo CustomHelper::getEmpProfileDiv($leaves_entitlement['employee_id']); ?></td>

                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_casual_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_casual_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_annual_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_annual_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_sick_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_sick_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_maternity_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_maternity_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_paternity_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_paternity_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                     <?php echo e($leaves_entitlement['total_bereavement_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_bereavement_leaves']); ?></span></td>
                                                <td class="text-primary font-weight-bold text-center">
                                                    <?php echo e($leaves_entitlement['total_compensatory_leaves']); ?>/<span class="text-danger font-weight-bold text-center"><?php echo e($leaves_entitlement['used_compensatory_leaves']); ?></span></td>
                                                <td class="">
                                                    <a href="javascript:void(0)" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="modal" data-bs-target="#addleave" onclick="leavesEditModel(<?php echo e(($leaves_entitlement['leaves_id'])); ?>, '<?php echo e($leaves_entitlement['employee_name']); ?>', <?php echo e($leaves_entitlement['total_casual_leaves']); ?>, <?php echo e($leaves_entitlement['total_annual_leaves']); ?>, <?php echo e($leaves_entitlement['total_sick_leaves']); ?>, <?php echo e($leaves_entitlement['total_maternity_leaves']); ?>, <?php echo e($leaves_entitlement['total_paternity_leaves']); ?>, <?php echo e($leaves_entitlement['total_bereavement_leaves']); ?>, <?php echo e($leaves_entitlement['total_compensatory_leaves']); ?>)" >

                                                        <span class="svg-icon svg-icon-3" data-bs-toggle="tooltip" title="View Leave detail">
                                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                                <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                            </svg>
                                                        </span>

                                                    </a>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>

                            </table>
                        </div>

                    </div>

                </div>

            </div>

            
            <form id="addleaveForm" class="form">
                <?php echo csrf_field(); ?>  
                <div class="modal fade" id="addleave" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                                <h4 class="modal-title pl-4">Update Leave</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                                </button>
                            </div>
                            
                            
                            <div class="modal-body scroll-y pt-0 pb-15">
                                
                                <div class="row g-9 mt-0" >
                                    
                                    <div class="col-md-12 fv-row">
                                        <input type="hidden" name="leaves_id" value=""/>
                                        <label class="fs-6 fw-semibold mb-2 required">Employee Name</label>
                                            
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="text" name="employee_name" class="form-control " value="<?php echo e(($leaves_entitlement['employee_id'])); ?>" readonly>
                                                
                                        </div>
                                    </div>    
                                    
                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Casual Alloted</label>
                                            
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " name="total_casual_leaves"  placeholder="Enter Sick Alloted" max="50" required="">
                                                
                                        </div>
                                    </div>    

                                    <div class="col-md-6 fv-row">
                                        <label class="required fs-6 fw-semibold mb-2">Annual Alloted</label>
                                        
                                        <div class="position-relative d-flex align-items-center">
                                            
                                            <input type="number" class="form-control " placeholder="Annual Alloted" name="total_annual_leaves" max="50" required="">
                                            
                                        </div>
                                        
                                    </div>
                                    
                                    
                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Sick Alloted</label>
                                        <input type="number" class="form-control " name="total_sick_leaves" placeholder="Enter Sick Alloted" max="50" required="">
                                    </div>
                                    
                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Maternity Alloted</label>
                                        <input type="number" class="form-control " name="total_maternity_leaves" placeholder="Enter Maternity Alloted" max="50" required="">
                                    </div>
                                    
                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Paternity Alloted</label>
                                        <input type="number" class="form-control " name="total_paternity_leaves" placeholder="Enter Paternity Alloted" max="50" required="">
                                    </div>

                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Bereavement Alloted</label>
                                        <input type="number" class="form-control " name="total_bereavement_leaves" placeholder="Enter Bereavement Alloted" max="50" required="">
                                    </div>

                                    <div class="col-md-6 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Compensatory Alloted</label>
                                        <input type="number" class="form-control " name="total_compensatory_leaves" placeholder="Enter compensatory Alloted" max="50" required="">
                                    </div>
                                    
                                </div>
                                    
                            </div>
                            
                            <div class="modal-footer justify-content-center">
                                    
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="update-btn" class="btn btn-primary">
                                    <span class="indicator-label">Update</span>
                                    <span class="indicator-progress">Please wait 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                        </div>
                        
                    </div>
                    
                </div>
            </form>
            



        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
       function leavesEditModel(leaves_id, employee_id, total_casual_leaves, total_annual_leaves, total_sick_leaves, total_maternity_leaves, total_paternity_leaves, total_bereavement_leaves, total_compensatory_leaves ){

        $('input[name=employee_name]').val(employee_id)
        $('input[name=total_casual_leaves]').val(total_casual_leaves)
        $('input[name=total_annual_leaves]').val(total_annual_leaves)
        $('input[name=total_sick_leaves]').val(total_sick_leaves)
        $('input[name=total_maternity_leaves]').val(total_maternity_leaves)
        $('input[name=total_paternity_leaves]').val(total_paternity_leaves)
        $('input[name=total_bereavement_leaves]').val(total_bereavement_leaves)
        $('input[name=total_compensatory_leaves]').val(total_compensatory_leaves)
        $('input[name=leaves_id]').val(leaves_id)

      }
           
      $('#addleaveForm').submit(function(e) {
            e.preventDefault();
            // var form_data = new FormData(this);
            // send_server_request('POST','manage-leaves/updateleave',this,'update-btn','No','employee',1000);
            $('#update-btn').prop('disabled', true);
            $('#update-btn').attr('data-kt-indicator', 'on');
            $('#update-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('manage-leaves/updateleave')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    console.log(data)
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#update-btn').prop('disabled', false);
                        $("#update-btn").removeAttr('data-kt-indicator');
                        $('#update-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#update-btn').prop('disabled', false);
                    $("#update-btn").removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                    }
                }
            });
        });
    

</script>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/leave/leaves-entitled.blade.php ENDPATH**/ ?>