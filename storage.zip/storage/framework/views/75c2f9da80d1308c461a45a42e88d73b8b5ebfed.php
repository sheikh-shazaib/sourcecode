

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Add New Gadget</h1>
                
            </div>
            <div class="gap-2 gap-lg-3">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
            </div>
        </div>
    </div>
    
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container container-xxl">
            
            <div class="card mb-5 mb-xl-8">
                
                <div class="card-body py-3 mb-12">
                    
                    <form  id="add_new_gadget_form" class="form" autocomplete="off">
                        <?php echo csrf_field(); ?> 

                        <div class="row g-9 mb-12 mt-3">

                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Gadget Type</label>
                                <select class="form-select form-select-solid" data-control="select2" data-hide-search="true" data-placeholder="Select Gadget Type" required name="gadget_type">
                                    <option value="">Select Gadget</option>
                                    <option value="Computer">Computer</option>
                                    <option value="Laptop">Laptop</option>
                                    <option value="Mobile">Mobile</option>                                        
                                </select>
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Brand Name</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_brand"
                                placeholder="Enter Brand Name" required="required"/>
                            </div>
                           
                        </div>

                        <div class="row g-9 mb-8">
                             
                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Model No</label>
                                <input type="text" class="form-control form-control-solid"  name="gadget_model_no"
                                placeholder="Enter Model Number" required="required"/>
                            </div>

                            <div class="col-md-6 fv-row">
                               <label class="required fs-6 fw-semibold mb-2">Serial No</label>
                               <input type="text" class="form-control form-control-solid"name="gadget_serial_no"
                               placeholder="Enter Serial Number" required="required"/>
                           </div>
                          
                           
                        </div>

                        <div class="row g-9 mb-8">

                            <div class="col-md-6 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Configuration</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_configuration" placeholder="Enter Configuration" required="required">
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">Mouse</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_mouse"
                                placeholder="Enter Mouse" />
                            </div>
                          
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">Keyboard</label>
                                <input type="text" class="form-control form-control-solid"  name="gadget_keyboard"
                                placeholder="Enter KeyBoard" >
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">LCD</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_lcd"
                                placeholder="Enter LCD" />
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2">HeadPhone</label>
                                <input type="text" class="form-control form-control-solid"name="gadget_headphone"
                                placeholder="Enter HeadPhone" />
                            </div>

                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2 required">MAC ADDRESS WIFI</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_mac_wifi"
                                placeholder="Enter MAC ADDRESS WIFI" required/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                        
                            <div class="col-md-6 fv-row">
                                <label class="fs-6 fw-semibold mb-2 required">MAC ADDRESS LAN</label>
                                <input type="text" class="form-control form-control-solid" name="gadget_mac_lan"
                                placeholder="Enter MAC ADDRESS LAN" required />
                            </div>
                        </div>
                        <div class="text-center">
                            <button type="submit" id="submit_btn" class="btn btn-primary">
                                <span class="indicator-label">Add Gadget</span>
                                <span class="indicator-progress">Please wait... 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
    $('#add_new_gadget_form').submit(function(e) {
       
        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('gadgets-inventory/assign_form_submit')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        window.location.href = "<?php echo e(url('gadgets-inventory')); ?>";
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/gadget/assign-gadget.blade.php ENDPATH**/ ?>