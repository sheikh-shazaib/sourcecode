

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
						 
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
    
        <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Portal Maintenance Records</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <div class="m-0">
                 
                    <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_new_target">											
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                            </svg>
                        </span>
                        Turn on Maintenance Mode</a>   
                </div>
              
            
            </div>
            
        </div>
    </div>
       
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container container-xxl">
            
            <div class="card mb-5 mb-xl-8">
                
                <div class="card-body ">
                    							
                    <div class="table-responsive">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="table-responsive">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer" id="tableEmployeeLeaveRequest" aria-describedby="tableEmployee_info">
                                																		 				
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4 min-w-225px rounded-start sorting sorting_asc" tabindex="0" aria-controls="tableEmployee"   rowspan="1" colspan="1" aria-sort="ascending" aria-label="Code &amp;amp; Name: activate to sort column descending" style="width: 225px;">ID
                                        </th>
                                        <th class="min-w-125px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending" style="width: 189.828px;">	Created By
                                        </th>
                                        <th class="min-w-125px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Depart &amp;amp; Design: activate to sort column ascending" style="width: 205px;">Status
                                        </th>
                                        <th class="min-w-200px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Management Rights: activate to sort column ascending" style="width: 200px;">Reason
                                        </th>
                                        <th class="min-w-150px sorting" tabindex="0" aria-controls="tableEmployee" rowspan="1" colspan="1" aria-label="Management Rights: activate to sort column ascending" style="width: 100px;">Create Date
                                        </th>
                                       
                                        
                                    </tr>
                                </thead>
                                <tbody>
                     
                                    <tr class="odd">
                                        <td class="sorting_1">
                                            <div class="d-flex align-items-center">
                                                <div class="symbol symbol-50px me-5">
                                                    <img src="https://www.sourcecodeemployees.com/public/profile_pictures/WhatsApp%20Image%202022-05-18%20at%202.09.32%20PM.jpeg" class="" alt="">
                                                </div>
                                                <div class="d-flex justify-content-start flex-column">
                                                    <a href="#" class="text-dark fw-bold text-hover-primary mb-1 fs-6">001 - Zain Sheikh</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">sidrasheikh93@gmail.com</a>
                                        
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">Human Resource</a>
                                            <span class="text-muted fw-semibold text-muted d-block fs-7">Senior HR executive</span>
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">sidrasheikh</a>
                                        
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">Php</a>
                                        
                                        </td>

                                        
                                    </tr>
                                    <tr class="even">
                                        <td class="sorting_1">
                                            <div class="d-flex align-items-center">
                                                <div class="symbol symbol-50px me-5">
                                                    <img src="https://www.sourcecodeemployees.com/public/profile_pictures/WhatsApp%20Image%202022-05-18%20at%202.09.32%20PM.jpeg" class="" alt="">
                                                </div>
                                                <div class="d-flex justify-content-start flex-column">
                                                    <a href="#" class="text-dark fw-bold text-hover-primary mb-1 fs-6">001 - Zain Sheikh</a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">sidrasheikh93@gmail.com</a>
                                        
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">Human Resource</a>
                                            <span class="text-muted fw-semibold text-muted d-block fs-7">Senior HR executive</span>
                                        </td>
                                        <td>
                                            <span class="badge badge-light-success fs-7 fw-bold">Yes, Given</span>
                                        </td>
                                        <td>
                                            <a href="#" class="text-dark fw-bold text-hover-primary d-block mb-1 fs-6">Php</a>
                                        
                                        </td>
                                        
                                      
                                    </tr>
                                   
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
               
            </div>
            
            
		
            <div class="modal fade" id="kt_modal_new_target" tabindex="-1" aria-hidden="true">
                
                <div class="modal-dialog modal-dialog-top mw-650px">
                    
                    <div class="modal-content rounded">
                        
                        <div class="modal-header pb-0 border-0 justify-content-end">
                            
                            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                                
                                <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                                
                            </div>
                            
                        </div>
                        
                        
                        <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
                            
                            <form id="kt_modal_new_target_form" class="form" action="#">
                                
                                <div class="mb-4">
                                    
                                    <h1 class="mb-3">Portal Maintenance Records</h1>
                                   
                                </div>
                                <hr>
                                
                                <div class="d-flex flex-column mb-8">
                                    <label class="fs-6 fw-semibold mb-2 required">Enter Reason</label>
                                    <textarea class="form-control form-control-solid" rows="5" name="leave_reason" placeholder="Enter Portal Maintenance Reason" required></textarea>
                                </div>
                                <div class="form-group">
                                    <p class="text-danger text-center">Please be careful ! By entering reason, portal will temporary shutdown until you turn off this maintanance mode thorugh API.</p>
                                </div>
                                
                                

                                <div class="text-center">
                                    
                                    <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" id="kt_modal_new_target_submit" class="btn btn-primary">
                                        <span class="indicator-label">Submit</span>
                                        <span class="indicator-progress">Please wait... 
                                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                    </button>
                                </div>
                                
                            </form>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
   

    // var table = $('#tableEmployee').DataTable({
    //     initComplete: function () {
    //         // Apply the search
    //         this.api()
    //             .columns()
    //             .every(function () {
    //                 var that = this;

    //                 $('input', this.footer()).on('keyup change clear', function () {
    //                     if (that.search() !== this.value) {
    //                         that.search(this.value).draw();
    //                     }
    //                 });
    //             });
    //     },
    // });
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/portal-maintenance/all-maintenance.blade.php ENDPATH**/ ?>