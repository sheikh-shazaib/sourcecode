

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                   Manage Letters
                </h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <div class="m-0">
                    <a href="" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addletter">											
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                            </svg>
                        </span>
                        Add New Letter</a>   
                </div>
         
            </div>
            
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container container-xxl">
           
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">  
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control form-control-solid w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                   
                </div> 
                <div class="card-body py-3">
                    
                    <div class="table-responsive">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer table-row-bordered"><div class="table-responsive">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableLetter" aria-describedby="tableEmployee_info">
                               					 				
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4 min-w-50px sorting">Letter ID
                                        </th>
                                        <th class="min-w-50px sorting">Title
                                        </th>
                                        <th class="min-w-50px sorting">Document Attachment
                                        </th>
                                        <th class="min-w-50px sorting">Upload By Hr
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php if(!empty($letters)): ?>
                                        <?php $__currentLoopData = $letters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-8"><?php echo e($letter['letter_id']); ?></td>
                                                <td><?php echo e($letter['letter_title']); ?></td>
                                                <td class="ps-15">
                                                   <a href="<?php echo e(url('/')); ?>/portal_assets/letter/<?php echo e($letter['document_name']); ?>" target="_blank" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" title="Download File"><i class="fa fa-download" aria-hidden="true"></i></a>
                                                </td>
                                                <td><?php echo CustomHelper::getEmpProfileDiv($letter['uploader']); ?></td>
                                                
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                      
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
            
		
            <div class="modal fade" id="addletter" tabindex="-1" aria-hidden="true">
                
                <div class="modal-dialog modal-dialog-top mw-650px">
                    
                    <div class="modal-content rounded">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                              <h4 class="modal-title pl-4">Add Letter</h4>
                              <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                  <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                              </button>
                            </div>
                             
                            
                        </div>
                        
                        
                        <div class="modal-body scroll-y pt-0 pb-15">
                            
                            <form id="addletterForm" class="form">
                                <?php echo csrf_field(); ?>  
            
                                
                                <div class="col-md-12 mb-8 mt-3 fv-row">
                                    <label class="fs-6 fw-semibold mb-2 required">Employees</label>
                                    <select class="form-select form-select-solid select" data-control="select2" data-hide-search="true" data-placeholder="Select Employee" name="employee" >
                                        <option value="">Select Employee</option>
                                        <?php if(!empty($employees)): ?>
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($employee['employee_id']); ?>"
                                                    <?php if($employee['employee_code'] == '' || $employee['employee_code'] == 'N/A'): ?> disabled <?php endif; ?>>
                                                    <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <div class="d-flex flex-column mb-8">
                                    <label class="fs-6 fw-semibold mb-2 required">Title</label>
                                    <input type="text" class="form-control form-control-solid" name="title" placeholder="title" required="">
                                </div>
                                <div class="d-flex flex-column mb-8">
                                    <label class="required fs-6 fw-semibold mb-2">Document</label>
                                    <input type="file" class="form-control form-control-solid" name="document_name">
                                </div>
                                
                                <div class="text-center">
                                   
                                    <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" id="submit-btn" class="btn btn-primary">
                                        <span class="indicator-label">Submit</span>
                                        <span class="indicator-progress">Please wait 
                                        <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                    </button>
                                </div>
                                
                            </form>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
<script>
  $(function(){
		dataTable = $('#tableLetter').DataTable({
            order:false
        });
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
	});

   $('#addletterForm').submit(function(e) { 
            $('#submit-btn').prop('disabled', true);
            $('#submit-btn').attr('data-kt-indicator', 'on');
            $('#submit-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('letters/addletter')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#submit-btn').prop('disabled', false);
                        $("#submit-btn").removeAttr('data-kt-indicator');
                        $('#submit-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#submit-btn').prop('disabled', false);
                    $("#submit-btn").removeAttr('data-kt-indicator');
                    $('#submit-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						Toast.fire({
							icon: 'warning',
							title: 'Try Again. Error Code ' + errorStatus,
							timer: 3000,
						})
                    }
                }
            });
        });

        
    
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/Company-Letters/letter.blade.php ENDPATH**/ ?>