

<?php $__env->startSection('main-section'); ?>
    <?php 
        $permission = CustomHelper::access_permission();
        $attendance_summary = CustomHelper::attendance_summary_employee();
    ?>
   
    <style>
        .custom-div-size-250{
            height:250px !important;
        }
        .imagenone{
            pointer-events: none;
        }
    </style>

    <div class="app-main flex-column flex-row-fluid" id="kt_app_main">

        <div class="d-flex flex-column flex-column-fluid">
            <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
                <div class="app-container col-12 d-flex flex-stack">
                    <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                        <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0"></h1>
                    </div>
                </div>
            </div>

            <div class="app-content flex-column-fluid">
                
                <div class="app-container">

                    <?php if(!empty($alerts)): ?>
                        <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-primary d-flex align-items-center p-5 mb-10" id="alert_div<?php echo e($alert['alert_id']); ?>">
                                <span class="svg-icon svg-icon-2hx svg-icon-primary me-4">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="currentColor" />
                                        <path d="M10.5606 11.3042L9.57283 10.3018C9.28174 10.0065 8.80522 10.0065 8.51412 10.3018C8.22897 10.5912 8.22897 11.0559 8.51412 11.3452L10.4182 13.2773C10.8099 13.6747 11.451 13.6747 11.8427 13.2773L15.4859 9.58051C15.771 9.29117 15.771 8.82648 15.4859 8.53714C15.1948 8.24176 14.7183 8.24176 14.4272 8.53714L11.7002 11.3042C11.3869 11.6221 10.874 11.6221 10.5606 11.3042Z" fill="currentColor" />
                                    </svg>
                                </span>
                                <div class="d-flex flex-column">
                                    <h4 class="mb-1 text-primary"><?php echo e($alert['title']); ?></h4>
                                    <p><?php echo e($alert['message']); ?></p>
                                </div>
                                <button type="button" onclick="alert_remove(<?php echo e($alert['alert_id']); ?>)" class="position-absolute position-sm-relative m-2 m-sm-0 top-0 end-0 btn btn-sm btn-icon btn-active-color-primary ms-sm-auto" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if(!empty($total_count)): ?>
                   
                    <div class="alert alert-primary d-flex align-items-center p-5">
                      
                        <div class="d-flex flex-column">
                           
                            <h4 class="mb-1">Meetings Acknowledgement</h4>
                            <span>You have (<?php echo e($total_count); ?>) meetings scheduled for tomorrow / today. <a href="<?php echo e(url('my-meetings')); ?>">Click here to see details.</a></span>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($login_user) && date('d-m', strtotime($login_user[0]['dob'])) == date('d-m')): ?>
                        <div class="card border-transparent mb-5" data-theme="light" style="background-color: #1C325E;">
                            <div class="card-body d-flex ps-xl-15">
                                <div class="m-0">
                                    <div class="position-relative fs-2x z-index-2 fw-bold text-white mb-7">
                                        <span class="me-2">Happy Birthday
                                            <span class="position-relative d-inline-block text-danger">
                                                <p class="text-danger">Champ !</p>
                                            </span>
                                        </span>
                                        <br>Best of luck for the upcoming years.
                                    </div>
                                </div>
                                <img src="<?php echo e(url('portal_assets/images/17-dark.png')); ?>" class="position-absolute me-3 bottom-0 end-0 h-200px" alt="">
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($login_user[0]['employee_can_ra']== "1" && !empty($my_team_mates)): ?>
                        <div class="row g-5 g-xl-10 mb-5">
                            
                            <div class="col-xl-4 mb-xl-10">
                                <div class="card card-flush" style="height : 443px;">
                                    <div class="card-header rounded bgi-no-repeat bgi-size-cover bgi-position-y-top bgi-position-x-center align-items-start h-200px" style="background-image:url('<?php echo e(url('/')); ?>/assets/media/svg/top-green.png" data-theme="light">
                                        <h3 class="card-title align-items-start flex-column text-white pt-5">
                                            <span class="fw-bold fs-2x mb-3"><?php echo e($login_user[0]['employee_name']); ?></span>
                                            <div class="fs-4 text-white">
                                                <span class="opacity-75">You have following remaining leaves</span>
                                            </div>
                                        </h3>
                                    </div>

                                    <div class="card-body mt-n20">
                                        <div class="mt-n20 position-relative">
                                            <div class="row g-3 g-lg-6">
                                                <div class="col-6">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/CasualLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($casual_used); ?>/<?php echo e($leaves_entitiled[0]['total_casual_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Casual Leave</span>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="col-6">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/SickLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($sick_used); ?>/<?php echo e($leaves_entitiled[0]['total_sick_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Sick Leave</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/AnnualLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($annual_used); ?>/<?php echo e($leaves_entitiled[0]['total_annual_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Annual Leave</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-4">
                                <div class="card card-flush" style="height : 443px;">
                                    <div class="card-header pt-7">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Reporting Authorities</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">You are supposed to report your activities to the following authorities</span>
                                        </h3>
                                    </div>
                                    <div class="card-body pt-7">
                                        <div class="row g-5 g-xl-9 mb-xl-3 mt-3">
                                            <div class="col-md-6 col-6 mb-3 mb-sm-0">
                                                <div class="m-0">
                                                    <div class="card-rounded position-relative mb-5">
                                                        <div class="mx-auto mb-6 bgi-no-repeat bgi-size-contain bgi-position-center rounded-circle w-125px h-125px" 
                                                            <?php if(empty($senior_manager)): ?>
                                                                style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                            <?php elseif(empty($senior_manager[0]['profile_avatar'] )): ?>
                                                                style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                            <?php else: ?>
                                                                <?php if(file_exists('portal_assets/profile_pictures/'.$senior_manager[0]['profile_avatar'])): ?>
                                                                    style="background-image:url('<?php echo e(asset('portal_assets/profile_pictures').'/'.$senior_manager[0]['profile_avatar']); ?> ')">
                                                                 <?php else: ?>
                                                                   style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                                <?php endif; ?>
                                                                    
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="m-0">
                                                        <a  class="text-gray-800 fs-3 fw-bold d-block mb-2 text-center">Senior Manager</a>
                                                        <span class="fw-bold fs-6 text-gray-400 d-block lh-1 text-center">
                                                            <?php if(empty($senior_manager)): ?>
                                                                Not Assigned
                                                            <?php else: ?>
                                                                <?php echo e($senior_manager[0]['employee_name']); ?>

                                                            <?php endif; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-6 mb-3 mb-sm-0">
                                                <div class="m-0">
                                                    <div class="card-rounded position-relative mb-5">
                                                        <div class="mx-auto mb-6 bgi-no-repeat bgi-size-contain bgi-position-center rounded-circle w-125px h-125px"    
                                                            <?php if(empty($junior_manager)): ?>
                                                                style="background-image:url('<?php echo e(asset('portal_assets/images/default-img.png')); ?>')">
                                                            <?php elseif(empty($junior_manager[0]['profile_avatar'] )): ?>
                                                                style="background-image:url('<?php echo e(asset('portal_assets/images/default-img.png')); ?>')">
                                                            <?php else: ?>
                                                                <?php if(file_exists('portal_assets/profile_pictures/'.$junior_manager[0]['profile_avatar'])): ?>
                                                                    style="background-image:url('<?php echo e(asset('portal_assets/profile_pictures').'/'.$junior_manager[0]['profile_avatar']); ?> ')">
                                                                 <?php else: ?>
                                                                   style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                                <?php endif; ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="m-0">
                                                        <a  class="text-gray-800 fs-3 fw-bold d-block mb-2 text-center">Junior Manager</a>
                                                        <span class="fw-bold fs-6 text-gray-400 d-block lh-1 text-center">
                                                            <?php if(empty($junior_manager)): ?>
                                                                Not Assigned
                                                            <?php else: ?>
                                                                <?php echo e($junior_manager[0]['employee_name']); ?>

                                                            <?php endif; ?>
                                                        </span>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php if(!empty($my_team_mates)): ?>
                                <div class="col-xl-4">
                
                                    
                                    <div class="card card-flush" style="height: 443px;" >
                                        
                                        <div class="card-header pt-7" >
                                            
                                            <h3 class="card-title align-items-start flex-column">
                                                <span class="card-label fw-bold text-dark">My Team</span>
                                                <span class="text-gray-400 mt-1 fw-semibold fs-6">Total <?php echo e(count($my_team_mates)); ?> employees under my reporting</span>
                                            </h3>
                                            
                                        </div>
                                        

                                        
                                        <div class="card-body">    
                                            
                                            <div class="hover-scroll-overlay-y pe-6 me-n6" style="height: 342px ">
                                            
                                                <?php $__currentLoopData = $my_team_mates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    <div class="border border-dashed border-gray-300 rounded px-7 py-3 mb-6">                 
                                                                                          
                                                        <div class="mb-3">
                                                            
                                                            <div class="me-3">    
                                                                <div class ="row">  
                                                                    <div class = "col-md-3">     
                                                                           
                                                                        <?php if(empty($employee['profile_avatar'])): ?>                      
                                                                            <img draggable="false" src="<?php echo e(asset('portal_assets/images/default-img.png')); ?>" class="mt-2 w-50px h-50px ms-n1 me-1 rounded-circle imagenone" alt=""> 
                                                                        <?php else: ?>
                                                                            <?php if(file_exists('portal_assets/profile_pictures/'.$employee['profile_avatar'])): ?>
                                                                                <img draggable="false" src="<?php echo e(asset('portal_assets/profile_pictures').'/'.$employee['profile_avatar']); ?>" class="mt-2 w-50px h-50px ms-n1 me-1 rounded-circle imagenone" alt="">
                                                                            <?php else: ?>
                                                                                <img draggable="false" alt="Logo" src="<?php echo e(asset('/portal_assets/images/default-img.png')); ?>" class="mt-2 w-50px h-50px ms-n1 me-1 rounded-circle imagenone"/>
                                                                            <?php endif; ?>
                                                                        <?php endif; ?>

                                                                       
                                                                    </div>

                                                                     

                                                                     
                                                                    <div class = "col-md-9 pt-2"> 
                                                                        <span class="text-gray-800 fw-bold"><?php echo e($employee['employee_name']); ?></span><br>

                                                                        <span class="text-muted d-block fw-semibold"><?php echo e($employee['employee_department']); ?> - <?php echo e($employee['employee_designation']); ?></span>
                                                                        
                                                                    </div>
                                                                 
                                                                </div>
                                                            </div>
                                                                                                
                                                        </div>                   
                                                        

                                                    </div>
                                                    
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        
                                            </div>   
                                            
                                        </div>
                                        
                                    </div>    
                                </div>
                            <?php endif; ?>     
                        </div>
                      
                        <?php if(!empty($setting[0]['linked_post1']) && !empty($setting[0]['linked_post2'])): ?>
                            <?php  $linked_post1 =  substr($setting[0]['linked_post1'],0,7);
                                $linked_post2 =  substr($setting[0]['linked_post2'],0,7);
                            ?>
                          
                            <?php if($linked_post1 == '<iframe' && $linked_post2 == '<iframe' ): ?>
                                <div class="row g-5 g-xl-10 mb-5">
                                    <div class="col-md-6">
                                        <div class="card card-flush" style="height:443px;">
                                            <div class="card-body">
                                                <div class="hover-scroll-overlay-y pe-6 me-n6" style="height:370px">
                                            
                                                    <?php echo $setting[0]['linked_post1']; ?>

                                            
                                                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-6">
                                        <div class="card card-flush" style="height:443px;">
                                            <div class="card-body">
                                                <div class="hover-scroll-overlay-y pe-6 me-n6" style="height:370px ">
                                                    <?php echo $setting[0]['linked_post2']; ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>  
                            <?php endif; ?>
                          
                        <?php endif; ?>                                      
                    <?php else: ?>    
                        <div class="row g-5 g-xl-10 mb-5">
                            
                            <div class="col-xl-5 mb-xl-10">
                                <div class="card card-flush h-xl-100">
                                    <div class="card-header rounded bgi-no-repeat bgi-size-cover bgi-position-y-top bgi-position-x-center align-items-start h-200px" style="background-image:url('<?php echo e(url('/')); ?>/assets/media/svg/top-green.png" data-theme="light">
                                        <h3 class="card-title align-items-start flex-column text-white pt-5">
                                            <span class="fw-bold fs-2x mb-3"><?php echo e($login_user[0]['employee_name']); ?></span>
                                            <div class="fs-4 text-white">
                                                <span class="opacity-75">You have following remaining leaves</span>
                                            </div>
                                        </h3>
                                    </div>

                                    <div class="card-body mt-n20">
                                        <div class="mt-n20 position-relative">
                                            <div class="row g-3 g-lg-6">
                                                <div class="col-6">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/CasualLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($casual_used); ?>/<?php echo e($leaves_entitiled[0]['total_casual_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Casual Leave</span>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div class="col-6">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/SickLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($sick_used); ?>/<?php echo e($leaves_entitiled[0]['total_sick_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Sick Leave</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="bg-gray-100 bg-opacity-70 rounded-2 px-6 py-5">
                                                        <div class="symbol symbol-30px me-5 mb-8">
                                                            <span class="symbol-label">
                                                                <span class="svg-icon svg-icon-1 svg-icon-primary">
                                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/AnnualLeave.png')); ?>" />
                                                                </span>
                                                            </span>
                                                        </div>

                                                        <div class="m-0">
                                                            <span class="text-gray-700 fw-bolder d-block fs-2qx lh-1 ls-n1 mb-1"><?php echo e($annual_used); ?>/<?php echo e($leaves_entitiled[0]['total_annual_leaves']); ?></span>
                                                            <span class="text-gray-500 fw-semibold fs-6">Annual Leave</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-xl-7">
                                <div class="card card-flush" style="height : 443px;">
                                    <div class="card-header pt-7">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Reporting Authorities</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">You are supposed to report your activities to the following authorities</span>
                                        </h3>
                                    </div>
                                    <div class="card-body pt-7">
                                        <div class="row g-5 g-xl-9 mb-xl-3 mt-3">
                                            <div class="col-md-6 col-6 mb-3 mb-sm-0">
                                                <div class="m-0">
                                                    <div class="card-rounded position-relative mb-5">
                                                        <div class="mx-auto mb-6 bgi-no-repeat bgi-size-contain bgi-position-center rounded-circle w-125px h-125px" 
                                                            <?php if(empty($senior_manager)): ?>
                                                                style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                            <?php elseif(empty($senior_manager[0]['profile_avatar'] )): ?>
                                                                style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                            <?php else: ?> 
                                                                <?php if(file_exists('portal_assets/profile_pictures/'.$senior_manager[0]['profile_avatar'])): ?>
                                                                    style="background-image:url('<?php echo e(asset('portal_assets/profile_pictures').'/'.$senior_manager[0]['profile_avatar']); ?> ')">
                                                                <?php else: ?>
                                                                    style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                                <?php endif; ?>
                                                              
                                                            <?php endif; ?>
                                                        
                                                        </div>
                                                    </div>

                                                    <div class="m-0">
                                                        <a  class="text-gray-800 fs-3 fw-bold d-block mb-2 text-center">Senior Manager</a>
                                                        <span class="fw-bold fs-6 text-gray-400 d-block lh-1 text-center">
                                                            <?php if(empty($senior_manager)): ?>
                                                                Not Assigned
                                                            <?php else: ?>
                                                                <?php echo e($senior_manager[0]['employee_name']); ?>

                                                            <?php endif; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6 col-6 mb-3 mb-sm-0">
                                                <div class="m-0">
                                                    <div class="card-rounded position-relative mb-5">
                                                        <div class="mx-auto mb-6 bgi-no-repeat bgi-size-contain bgi-position-center rounded-circle w-125px h-125px"    
                                                            <?php if(empty($junior_manager)): ?>
                                                                style="background-image:url('<?php echo e(asset('portal_assets/images/default-img.png')); ?>')">
                                                            <?php elseif(empty($junior_manager[0]['profile_avatar'] )): ?>
                                                                style="background-image:url('<?php echo e(asset('portal_assets/images/default-img.png')); ?>')">
                                                            <?php else: ?>
                                                                <?php if(file_exists('portal_assets/profile_pictures/'.$junior_manager[0]['profile_avatar'])): ?>
                                                                    style="background-image:url('<?php echo e(asset('portal_assets/profile_pictures').'/'.$junior_manager[0]['profile_avatar']); ?> ')">
                                                                <?php else: ?>
                                                                    style="background-image:url('<?php echo e(asset('/portal_assets/images/default-img.png')); ?>')">
                                                                <?php endif; ?>
                                                               
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="m-0">
                                                        <a  class="text-gray-800 fs-3 fw-bold d-block mb-2 text-center">Junior Manager</a>
                                                        <span class="fw-bold fs-6 text-gray-400 d-block lh-1 text-center">
                                                            <?php if(empty($junior_manager)): ?>
                                                                Not Assigned
                                                            <?php else: ?>
                                                                <?php echo e($junior_manager[0]['employee_name']); ?>

                                                            <?php endif; ?>
                                                        </span>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                        <?php if(!empty($setting[0]['linked_post1']) && !empty($setting[0]['linked_post2'])): ?>
                            <?php  $linked_post1 =  substr($setting[0]['linked_post1'],0,7);
                                $linked_post2 =  substr($setting[0]['linked_post2'],0,7);
                            ?>
                          
                            <?php if($linked_post1 == '<iframe' && $linked_post2 == '<iframe' ): ?>
                                <div class="row g-5 g-xl-10 mb-5">
                                    <div class="col-md-6">
                                        <div class="card card-flush" style="height:443px;">
                                            <div class="card-body">
                                                <div class="hover-scroll-overlay-y pe-6 me-n6" style="height:370px">
                                            
                                                    <?php echo $setting[0]['linked_post1']; ?>

                                            
                                                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                    <div class="col-md-6">
                                        <div class="card card-flush" style="height:443px;">
                                            <div class="card-body">
                                                <div class="hover-scroll-overlay-y pe-6 me-n6" style="height:370px ">
                                            
                                                    <?php echo $setting[0]['linked_post2']; ?>

                                            
                                                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>  
                            <?php endif; ?>
                          
                        <?php endif; ?>
                    <?php endif; ?>

                    <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>
                    <div class="row  gy-5 g-xl-10">
                        <div class="col-md-3 col-6 mb-10">
                           
                            <div class="card card-flush">
                                <a href="<?php echo e(url('employees')); ?>" >
                                    <div class="card-header pt-5">
                                    
                                        <div class="card-title d-flex flex-column">
                                            
                                            <div class="m-0 mb-5">
                                                <span class="svg-icon svg-icon-2hx svg-icon-gray-600">
                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/ActiveEmployees.png')); ?>" />
                                                </span>
                                            </div>

                                            <div class="d-flex align-items-center">
                                                
                                                <span class="fs-2hx fw-bold text-dark me-2 lh-1 ls-n2"><?php echo e($active_employees); ?></span>
                                            
                                                <span class="badge badge-light-success fs-base">
                                        
                                                <span class="svg-icon svg-icon-5 svg-icon-success ms-n1">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="currentColor" />
                                                        <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <?php $active_employee_ratio =   ($active_employees /$total_employees)*100; ?>
                                                    <?php echo e(substr($active_employee_ratio,0,5).'%'); ?></span>
                                            
                                            </div>
                                        
                                            <span class="text-gray-400 pt-1 fw-semibold fs-6">Active Employees</span>
                                        
                                        </div>
                                    
                                    </div>
                                
                                    <div class="card-body pt-2 pb-4 d-flex flex-wrap align-items-center">
                                    
                                        <div class="d-flex flex-center me-5 pt-2">
                                            <?php $active_gender = $active_male_employees + $active_female_employees;  ?>
                                            <div id="active_male_female" style="min-width: 70px; min-height: 70px" data-kt-size="70" data-kt-line="11"></div>
                                        </div>
                                    
                                        <div class="d-flex flex-column content-justify-center flex-row-fluid">
                                    
                                            <div class="d-flex fw-semibold align-items-center">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-primary me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Male</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($active_male_employees); ?></div>
                                            
                                            </div>
                                            
                                            <div class="d-flex fw-semibold align-items-center my-3">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-success me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Female</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($active_female_employees); ?></div>
                                            
                                            </div>
                                            
                                        </div>
                                
                                    </div>
                                </a>
                              
                            </div>
                        
                            
                        </div>

                        <div class="col-md-3 col-6 mb-10 ">
                           
                            <div class="card card-flush">
                                <a href="<?php echo e(url('employees?employee_isactive=2')); ?>">
                                    <div class="card-header pt-5">
                                    
                                        <div class="card-title d-flex flex-column">
                                            
                                            <div class="m-0 mb-5">
                                                <span class="svg-icon svg-icon-2hx svg-icon-gray-600">
                                                    <img src="<?php echo e(asset('portal_assets/dashboard_icons/DeactiveEmployees.png')); ?>" />
                                                </span>
                                            </div>

                                            <div class="d-flex align-items-center">
                                                
                                                <span class="fs-2hx fw-bold text-dark me-2 lh-1 ls-n2"><?php echo e($deactive_employees); ?></span>
                                            
                                                <span class="badge badge-light-success fs-base">
                                        
                                                <span class="svg-icon svg-icon-5 svg-icon-success ms-n1">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="currentColor" />
                                                        <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <?php $deactive_employee_ratio = ($deactive_employees /$total_employees)*100; ?>
                                                <?php echo e(substr($deactive_employee_ratio,0,5).'%'); ?>

                                            
                                            </div>
                                        
                                            <span class="text-gray-400 pt-1 fw-semibold fs-6">Deactive Employees</span>
                                        
                                        </div>
                                    
                                    </div>
                                
                                    <div class="card-body pt-2 pb-4 d-flex flex-wrap align-items-center">
                                    
                                        <div class="d-flex flex-center me-5 pt-2">
                                            <div id="deactive_male_female" style="min-width: 70px; min-height: 70px" data-kt-size="70" data-kt-line="11"></div>
                                        </div>
                                    
                                        <div class="d-flex flex-column content-justify-center flex-row-fluid">
                                    
                                            <div class="d-flex fw-semibold align-items-center">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-primary me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Male</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($deactive_male_employees); ?></div>
                                            
                                            </div>
                                            
                                            <div class="d-flex fw-semibold align-items-center my-3">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-success me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Female</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($deactive_female_employees); ?></div>
                                            
                                            </div>
                                            
                                        </div>
                                
                                    </div>
                                </a>
                              
                            </div>
                        
                            
                        </div>

                        <div class="col-md-3 col-6 mb-10">
                           
                            <div class="card card-flush">
                                <a href="<?php echo e(url('employees?employee_isactive=1&employee_status=Permanent')); ?>" >
                                    <div class="card-header pt-5">
                                    
                                        <div class="card-title d-flex flex-column">
                                            
                                            <div class="m-0 mb-5">
                                                <span class="svg-icon svg-icon-2hx svg-icon-gray-600">
                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/PermanentEmployees.png')); ?>" />
                                                </span>
                                            </div>

                                            <div class="d-flex align-items-center">
                                                
                                                <span class="fs-2hx fw-bold text-dark me-2 lh-1 ls-n2"><?php echo e($permanent_employees); ?></span>
                                            
                                                <span class="badge badge-light-success fs-base">
                                        
                                                <span class="svg-icon svg-icon-5 svg-icon-success ms-n1">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="currentColor" />
                                                        <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <?php $permanent_employee_ratio =   ($permanent_employees /$active_employees)*100; ?>
                                                <?php echo e(substr($permanent_employee_ratio,0,5).'%'); ?>

                                            
                                            </div>
                                        
                                            <span class="text-gray-400 pt-1 fw-semibold fs-6">Permanent Employees (Active)</span>
                                        
                                        </div>
                                    
                                    </div>
                                
                                    <div class="card-body pt-2 pb-4 d-flex flex-wrap align-items-center">
                                    
                                        <div class="d-flex flex-center me-5 pt-2">
                                            <div id="permanent_male_female" style="min-width: 70px; min-height: 70px" data-kt-size="70" data-kt-line="11"></div>
                                        </div>
                                    
                                        <div class="d-flex flex-column content-justify-center flex-row-fluid">
                                    
                                            <div class="d-flex fw-semibold align-items-center">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-primary me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Male</div>
                                               
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($permanent_male_employees); ?></div>
                                            
                                            </div>
                                            
                                            <div class="d-flex fw-semibold align-items-center my-3">
                                            
                                                <div class="bullet w-8px h-3px rounded-2 bg-success me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Female</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($permanent_female_employees); ?></div>
                                            
                                            </div>
                                            
                                        </div>
                                
                                    </div>
                                </a>
                              
                            </div>
                        
                            
                        </div>
                        
                        <div class="col-md-3 col-6 mb-10">
                           
                            <div class="card card-flush">
                                <a href="<?php echo e(url('employees?employee_isactive=1&employee_status=Probation')); ?>">
                                    <div class="card-header pt-5">
                                    
                                        <div class="card-title d-flex flex-column">
                                            
                                            <div class="m-0 mb-5">
                                                <span class="svg-icon svg-icon-2hx svg-icon-gray-600">
                                                    <img  src="<?php echo e(asset('portal_assets/dashboard_icons/ProbationEmployees.png')); ?>" />
                                                </span>
                                            </div>

                                            <div class="d-flex align-items-center">
                                                
                                                <span class="fs-2hx fw-bold text-dark me-2 lh-1 ls-n2"><?php echo e($probation_employees); ?></span>
                                            
                                                <span class="badge badge-light-success fs-base">
                                        
                                                <span class="svg-icon svg-icon-5 svg-icon-success ms-n1">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="currentColor" />
                                                        <path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="currentColor" />
                                                    </svg>
                                                </span>
                                                <?php $probation_employee_ratio =   ($probation_employees /$active_employees)*100; ?>
                                                <?php echo e(substr($probation_employee_ratio,0,5).'%'); ?>

                                            
                                            </div>
                                        
                                            <span class="text-gray-400 pt-1 fw-semibold fs-6">Probation Employees (Active)</span>
                                        
                                        </div>
                                    
                                    </div>
                                
                                    <div class="card-body pt-2 pb-4 d-flex flex-wrap align-items-center">
                                    
                                        <div class="d-flex flex-center me-5 pt-2">
                                            <div id="probation_male_female" style="min-width: 70px; min-height: 70px" data-kt-size="70" data-kt-line="11"></div>
                                        </div>
                                    
                                        <div class="d-flex flex-column content-justify-center flex-row-fluid">
                                    
                                            <div class="d-flex fw-semibold align-items-center">
                                            
                                                <div class="bullet w-8px h-3px rounded-2  bg-primary me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Male</div>
                                               
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($probation_male_employees); ?></div>
                                            
                                            </div>
                                            
                                            <div class="d-flex fw-semibold align-items-center my-3">
                                            
                                                <div class="bullet w-8px h-3px rounded-2 bg-success me-3"></div>
                                            
                                                <div class="text-gray-500 flex-grow-1 me-4">Female</div>
                                            
                                                <div class="fw-bolder text-gray-700 text-xxl-end"><?php echo e($probation_female_employees); ?></div>
                                            
                                            </div>
                                            
                                        </div>
                                
                                    </div>
                                </a>
                              
                            </div>
                        
                            
                        </div>
                    </div>

                    <?php endif; ?>

                    <div class="row">
                        <?php if(!empty($permission) && !empty($permission[29]['permission_status'] == 1)): ?>
                            <div class="col-xl-12">
                                <div class="card card-flush overflow-hidden h-md-100">
                                    <div class="card-header py-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Expense of Month</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">Expense of Month</span>
                                        </h3>
                                        <div class="card-toolbar" >
                        
                                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                        
                                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            Filter</a>
                                        
                                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                                    <form action="<?php echo e(url('attendance')); ?>" method="GET">
                                                        <div class="px-7 py-5">
                                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                                        </div>
                                                    
                                                        <div class="separator border-gray-200"></div>
                                                        <div class="px-7 py-5">
                                                            
                                                            <div class="mb-10 row" >
                                                                <div class="col-12">
                                                                
                                                                    <label class="form-label fw-semibold">Select Month</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Month" name="m"
                                                                        required="required" id="expense_month" >
                                                                        <option value="">Select Month</option>
                                                                        <option value="01"  <?php if(date('m') == '01'): ?>  selected  <?php endif; ?>>January
                                                                        </option>
                                                                        <option value="02"  <?php if(date('m') == '02'): ?>  selected  <?php endif; ?>>February
                                                                        </option>
                                                                        <option value="03"  <?php if(date('m') == '03'): ?>  selected  <?php endif; ?>>March
                                                                        </option>
                                                                        <option value="04"  <?php if(date('m') == '04'): ?>  selected   <?php endif; ?>>April
                                                                        </option>
                                                                        <option value="05"  <?php if(date('m') == '05'): ?>  selected   <?php endif; ?>>May
                                                                        </option>
                                                                        <option value="06"  <?php if(date('m') == '06'): ?>  selected   <?php endif; ?>>June
                                                                        </option>
                                                                        <option value="07"  <?php if(date('m') == '07'): ?>  selected   <?php endif; ?>>July
                                                                        </option>
                                                                        <option value="08"  <?php if(date('m') == '08'): ?>  selected   <?php endif; ?>>August
                                                                        </option>
                                                                        <option value="09"  <?php if(date('m') == '09'): ?>  selected   <?php endif; ?>>September
                                                                        </option>
                                                                        <option value="10"  <?php if(date('m') == '10'): ?>  selected <?php endif; ?>>October
                                                                        </option>
                                                                        <option value="11"  <?php if(date('m') == '11'): ?>  selected <?php endif; ?>>November
                                                                        </option>
                                                                        <option value="12"  <?php if(date('m') == '12'): ?>  selected <?php endif; ?>>December
                                                                        </option>
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 pt-5">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Year</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required" id="expense_year" >
                                                                            <option value="">Select Year</option>
                                                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?>  selected  <?php endif; ?>>2020
                                                                            </option>
                                                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?>  selected  <?php endif; ?>>2021
                                                                            </option>
                                                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?>  selected  <?php endif; ?>>2022
                                                                            </option>
                                                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?>  selected  <?php endif; ?>>2023
                                                                            </option>
                                                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?>  selected  <?php endif; ?>>2024
                                                                            </option>
                                                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?>  selected  <?php endif; ?>>2025
                                                                            </option>
                                                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?>  selected  <?php endif; ?>>2026
                                                                            </option>
                                                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?>  selected  <?php endif; ?>>2027
                                                                            </option>
                                                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?>  selected  <?php endif; ?>>2028
                                                                            </option>
                                                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?>  selected  <?php endif; ?>>2029
                                                                            </option>
                                                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?>  selected  <?php endif; ?>>2030
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                        
                                        </div>
                                    </div>

                                    <div class="card-body d-flex justify-content-between flex-column pb-1 px-0">
                                        <div class="px-9 mb-5">
                                            <div class="d-flex mb-2">
                                                <span class="fs-4 fw-semibold text-gray-400 me-1">Rs.</span>
                                                <span class="fs-2hx fw-bold text-gray-800 me-2 lh-1 ls-n2" id="total_expense">0</span>
                                            </div>
                                        </div>

                                        <div id="expense_graph" class="min-h-auto ps-4 pe-6" style="height: 300px"></div>
                                    </div>
                                </div>
                            </div>
                            
                        <?php endif; ?>
                     
                        <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>
                            <div class="col-xl-12 mt-4">
                                <div class="card card-xl-stretch mb-5 mb-xl-8">
                                    <div class="card-header border-0 pt-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold fs-3 mb-1">Department Employee</span>
                                            <span class="text-muted fw-semibold fs-7">Department Employee</span>
                                        </h3>
                                    </div>

                                    <div class="card-body">
                                        <div id="department_employee_graph" style="height: 350px"></div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && !empty($permission[23]['permission_status'] == 1) && ($login_user[0]['employee_department'] == 1 ||  $login_user[0]['employee_department'] == 2)): ?>
                            <div class="col-xl-12 mb-5">
                                <div class="card card-flush overflow-hidden h-md-100">
                                    <div class="card-header py-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Employee Leave Request</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">Employee Leave Request</span>
                                        </h3>
                                        <div class="card-toolbar" >
                        
                                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                        
                                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            Filter</a>
                                        
                                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                                    <form action="" method="GET">
                                                        <div class="px-7 py-5">
                                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                                        </div>
                                                    
                                                        <div class="separator border-gray-200"></div>
                                                        <div class="px-7 py-5">
                                                            
                                                            <div class="mb-10 row" >
                                                                <div class="col-12">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Departments</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true"  name="department_id[]" required id="select-department">
                                                                            <option value="">Select All Department</option>
                                                                            <?php if(!empty($departments)): ?>
                                                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($department['department_id']); ?>">
                                                                                        <?php echo e($department['department_name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                    </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 mt-4">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Employee</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true" data-placeholder="Select Employee" name="employee_id" id="employees">
                                                    
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 pt-5">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Year</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required" id="leave_request_year" >
                                                                            <option value="">Select Year</option>
                                                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?>  selected  <?php endif; ?>>2020
                                                                            </option>
                                                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?>  selected  <?php endif; ?>>2021
                                                                            </option>
                                                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?>  selected  <?php endif; ?>>2022
                                                                            </option>
                                                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?>  selected  <?php endif; ?>>2023
                                                                            </option>
                                                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?>  selected  <?php endif; ?>>2024
                                                                            </option>
                                                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?>  selected  <?php endif; ?>>2025
                                                                            </option>
                                                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?>  selected  <?php endif; ?>>2026
                                                                            </option>
                                                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?>  selected  <?php endif; ?>>2027
                                                                            </option>
                                                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?>  selected  <?php endif; ?>>2028
                                                                            </option>
                                                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?>  selected  <?php endif; ?>>2029
                                                                            </option>
                                                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?>  selected  <?php endif; ?>>2030
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                        
                                        </div>
                                    </div>

                                    <div class="card-body" id="leave-request-chart">
                                        <canvas id="leave-chart" style="height:250px"></canvas>
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>

                        <?php if(!empty($permission) && !empty($permission[22]['permission_status'] == 1) && ($login_user[0]['employee_department'] == 1 ||  $login_user[0]['employee_department'] == 2)): ?>
                            <div class="col-xl-12 mb-5">
                                <div class="card card-flush overflow-hidden h-md-100">
                                    <div class="card-header py-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Employee Remote Request</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">Employee Remote Request</span>
                                        </h3>
                                        <div class="card-toolbar" >
                        
                                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                        
                                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            Filter</a>
                                        
                                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                                    <form action="" method="GET">
                                                        <div class="px-7 py-5">
                                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                                        </div>
                                                    
                                                        <div class="separator border-gray-200"></div>
                                                        <div class="px-7 py-5">
                                                            
                                                            <div class="mb-10 row" >
                                                                <div class="col-12">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Departments</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true" name="department_id[]" required id="select-department-wfh">
                                                                            <option value="">Select All Department</option>
                                                                            <?php if(!empty($departments)): ?>
                                                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($department['department_id']); ?>">
                                                                                        <?php echo e($department['department_name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                    </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 mt-4">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Employee</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true" data-placeholder="Select Employee" name="employee_id" id="employees-wfh">
                                                    
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 pt-5">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Year</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required" id="wfh_request_year" >
                                                                            <option value="">Select Year</option>
                                                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?>  selected  <?php endif; ?>>2020
                                                                            </option>
                                                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?>  selected  <?php endif; ?>>2021
                                                                            </option>
                                                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?>  selected  <?php endif; ?>>2022
                                                                            </option>
                                                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?>  selected  <?php endif; ?>>2023
                                                                            </option>
                                                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?>  selected  <?php endif; ?>>2024
                                                                            </option>
                                                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?>  selected  <?php endif; ?>>2025
                                                                            </option>
                                                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?>  selected  <?php endif; ?>>2026
                                                                            </option>
                                                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?>  selected  <?php endif; ?>>2027
                                                                            </option>
                                                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?>  selected  <?php endif; ?>>2028
                                                                            </option>
                                                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?>  selected  <?php endif; ?>>2029
                                                                            </option>
                                                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?>  selected  <?php endif; ?>>2030
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                        
                                        </div>
                                    </div>

                                    <div class="card-body" id="wfh-request-chart">
                                        <canvas id="wfh_chart_js" style="height:300px"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1) && ($login_user[0]['employee_department'] == 1 ||  $login_user[0]['employee_department'] == 2)): ?>
                            <div class="col-xl-12 mb-5">
                                <div class="card card-flush overflow-hidden h-md-100">
                                    <div class="card-header py-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Employee Monthly Strength</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">Employee Monthly Strength</span>
                                        </h3>
                                        <div class="card-toolbar" >
                        
                                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                        
                                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            Filter</a>
                                        
                                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                                    <form action="" method="GET">
                                                        <div class="px-7 py-5">
                                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                                        </div>
                                                    
                                                        <div class="separator border-gray-200"></div>
                                                        <div class="px-7 py-5">
                                                            
                                                            <div class="mb-10 row" >
                                                                <div class="col-12">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Departments</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true"  name="department_id[]" required id="select-department-employee">
                                                                            <option value="">Select All Department</option>
                                                                            <?php if(!empty($departments)): ?>
                                                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option value="<?php echo e($department['department_id']); ?>">
                                                                                        <?php echo e($department['department_name']); ?></option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php endif; ?>
                                                                    </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 mt-4">
                                                                    <label class="fs-6 fw-semibold mb-2 required">Employee</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select" data-control="select2"  data-hide-search="true" data-placeholder="Select Employee" name="employee_id" id="employee_list">
                                                    
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 pt-5">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Year</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required" id="employee_strength_year" >
                                                                            <option value="">Select Year</option>
                                                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?>  selected  <?php endif; ?>>2020
                                                                            </option>
                                                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?>  selected  <?php endif; ?>>2021
                                                                            </option>
                                                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?>  selected  <?php endif; ?>>2022
                                                                            </option>
                                                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?>  selected  <?php endif; ?>>2023
                                                                            </option>
                                                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?>  selected  <?php endif; ?>>2024
                                                                            </option>
                                                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?>  selected  <?php endif; ?>>2025
                                                                            </option>
                                                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?>  selected  <?php endif; ?>>2026
                                                                            </option>
                                                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?>  selected  <?php endif; ?>>2027
                                                                            </option>
                                                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?>  selected  <?php endif; ?>>2028
                                                                            </option>
                                                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?>  selected  <?php endif; ?>>2029
                                                                            </option>
                                                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?>  selected  <?php endif; ?>>2030
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                        
                                        </div>
                                    </div>

                                    <div class="card-body" id="employee-monthly-strength-chart">
                                        <canvas id="monthly-strength-chart" style="height:250px"></canvas>
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>
                        <?php if(!empty($permission) && !empty($permission[25]['permission_status'] == 1) && ($login_user[0]['employee_department'] == 1 ||  $login_user[0]['employee_department'] == 2)): ?>
                            <div class="col-xl-6 mb-5">
                                <div class="card card-flush overflow-hidden h-md-100">
                                    <div class="card-header py-5">
                                        <h3 class="card-title align-items-start flex-column">
                                            <span class="card-label fw-bold text-dark">Candidate Interviews</span>
                                            <span class="text-gray-400 mt-1 fw-semibold fs-6">Candidate Interviews</span>
                                        </h3>
                                        <div class="card-toolbar" >
                        
                                            <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                        
                                            <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                                                </svg>
                                            </span>
                                            Filter</a>
                                        
                                                <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                                    <form action="" method="GET">
                                                        <div class="px-7 py-5">
                                                            <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                                        </div>
                                                    
                                                        <div class="separator border-gray-200"></div>
                                                        <div class="px-7 py-5">
                                                            
                                                            <div class="mb-10 row" >
                                                                <div class="col-12 pt-2">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Month</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true"   name="m" required="required" id="interview_month" >
                                                                            <option value="">Select All Month</option>
                                                                            <option value="01" <?php if(!empty(Request::get('m')) && Request::get('m') == '01'): ?> selected <?php endif; ?>>January
                                                                            </option>
                                                                            <option value="02" <?php if(!empty(Request::get('m')) && Request::get('m') == '02'): ?> selected <?php endif; ?>>February
                                                                            </option>
                                                                            <option value="03" <?php if(!empty(Request::get('m')) && Request::get('m') == '03'): ?> selected <?php endif; ?>>March
                                                                            </option>
                                                                            <option value="04" <?php if(!empty(Request::get('m')) && Request::get('m') == '04'): ?> selected <?php endif; ?>>April
                                                                            </option>
                                                                            <option value="05" <?php if(!empty(Request::get('m')) && Request::get('m') == '05'): ?> selected <?php endif; ?>>May
                                                                            </option>
                                                                            <option value="06" <?php if(!empty(Request::get('m')) && Request::get('m') == '06'): ?> selected <?php endif; ?>>June
                                                                            </option>
                                                                            <option value="07" <?php if(!empty(Request::get('m')) && Request::get('m') == '07'): ?> selected <?php endif; ?>>July
                                                                            </option>
                                                                            <option value="08" <?php if(!empty(Request::get('m')) && Request::get('m') == '08'): ?> selected <?php endif; ?>>August
                                                                            </option>
                                                                            <option value="09" <?php if(!empty(Request::get('m')) && Request::get('m') == '09'): ?> selected  <?php endif; ?>>September
                                                                            </option>
                                                                            <option value="10" <?php if(!empty(Request::get('m')) && Request::get('m') == '10'): ?> selected <?php endif; ?>>October
                                                                            </option>
                                                                            <option value="11" <?php if(!empty(Request::get('m')) && Request::get('m') == '11'): ?>  selected  <?php endif; ?>>November
                                                                            </option>
                                                                            <option value="12" <?php if(!empty(Request::get('m')) && Request::get('m') == '12'): ?> selected  <?php endif; ?>>December
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                                <div class="col-12 pt-5">
                                                                    
                                                                    <label class="form-label fw-semibold">Select Year</label>
                                                                    
                                                                    <div>
                                                                        <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required" id="interview_year" >
                                                                            <option value="">Select Year</option>
                                                                            <option value="2020" <?php if(!empty(Request::get('y')) && Request::get('y') == '2020'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2020'): ?>  selected  <?php endif; ?>>2020
                                                                            </option>
                                                                            <option value="2021" <?php if(!empty(Request::get('y')) && Request::get('y') == '2021'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2021'): ?>  selected  <?php endif; ?>>2021
                                                                            </option>
                                                                            <option value="2022" <?php if(!empty(Request::get('y')) && Request::get('y') == '2022'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2022'): ?>  selected  <?php endif; ?>>2022
                                                                            </option>
                                                                            <option value="2023" <?php if(!empty(Request::get('y')) && Request::get('y') == '2023'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2023'): ?>  selected  <?php endif; ?>>2023
                                                                            </option>
                                                                            <option value="2024" <?php if(!empty(Request::get('y')) && Request::get('y') == '2024'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2024'): ?>  selected  <?php endif; ?>>2024
                                                                            </option>
                                                                            <option value="2025" <?php if(!empty(Request::get('y')) && Request::get('y') == '2025'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2025'): ?>  selected  <?php endif; ?>>2025
                                                                            </option>
                                                                            <option value="2026" <?php if(!empty(Request::get('y')) && Request::get('y') == '2026'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2026'): ?>  selected  <?php endif; ?>>2026
                                                                            </option>
                                                                            <option value="2027" <?php if(!empty(Request::get('y')) && Request::get('y') == '2027'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2027'): ?>  selected  <?php endif; ?>>2027
                                                                            </option>
                                                                            <option value="2028" <?php if(!empty(Request::get('y')) && Request::get('y') == '2028'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2028'): ?>  selected  <?php endif; ?>>2028
                                                                            </option>
                                                                            <option value="2029" <?php if(!empty(Request::get('y')) && Request::get('y') == '2029'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2029'): ?>  selected  <?php endif; ?>>2029
                                                                            </option>
                                                                            <option value="2030" <?php if(!empty(Request::get('y')) && Request::get('y') == '2030'): ?> selected <?php elseif(empty(Request::get('y')) && date('Y') == '2030'): ?>  selected  <?php endif; ?>>2030
                                                                            </option>
                                                                        
                                                                        </select>
                                                                    </div>
                                                                    
                                                                </div>
                                                            </div>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                        
                                        </div>
                                    </div>

                                    <div class="card-body" id="interview-chart">
                                        <canvas id="kt_chartjs_3" class="mh-300px"></canvas>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="col-xl-6">
                            <div class="card mb-5 mb-xl-8">
                                <div class="card-header border-0 pt-5">
                                    <div class="card-title">
                                        <div class="d-flex align-items-center position-relative my-1">
                                            My Attendance Summary (<?php echo e(date('F') . '-' . date('Y')); ?>)
                                        </div>
                                    </div>
                                </div> 
                
                                <div class="card-body py-3">
                                    <table class="table align-middle gs-0 gy-4 table-row-bordered">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4 min-w-100px sorting">Description</th>
                                                <th class="min-w-10px sorting">Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td class="ps-4">Absent</td>
                                                <td class="ps-8 fs-6"><?php echo e($attendance_summary['absent']); ?></td>
                                            <tr>
                                                <td class="ps-4">Present</td>
                                                <td class="ps-8 fs-6"><?php echo e($attendance_summary['present']); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="ps-4">OffDays</td>
                                                <td class="ps-8 fs-6"><?php echo e($attendance_summary['offdays']); ?></td>
                                            </tr>
                                            <tr>
                                                <td class="ps-4">Leaves</td>
                                                <td class="ps-8 fs-6"><?php echo e($attendance_summary['leave']); ?></td>
                                            </tr>
                                                <tr>
                                                <td class="ps-4 fs-6">Total</td>
                                                <?php $total = $attendance_summary['absent'] + $attendance_summary['present'] + $attendance_summary['leave'] + $attendance_summary['offdays'] ?>
                                                <td class="ps-8 text-dark fw-bold mb-1 fs-6"><?php echo e($total); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>   
                            </div>
                        </div>  
                        
                        <?php if(!empty($permission) && !empty($permission[14]['permission_status'] == 1)): ?>  
                               
                            <div class="col-xl-6">
                                <div class="card mb-5 mb-xl-8">
                                    <div class="card-header border-0 pt-5">
                                        <div class="card-title">
                                            Employees Birthday (<?php echo e(date('F - Y')); ?>)
                                        </div>
                                    </div> 
                    
                                    <div class="card-body py-3">
                                        <div class="table-responsive " style="height:297px">
                                            <?php if(!empty($birthdays)): ?>
                                                <table class="table align-middle gs-0 gy-4 table-row-bordered" >
                                                    <thead>
                                                        <tr class="fw-bold text-muted bg-light">
                                                            <th class="ps-4">Employee Name</th>
                                                            <th>Employee Department</th>
                                                            <th>Birthday</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    
                                                        <?php $__currentLoopData = $birthdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $birthday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td class="ps-4"><?php echo CustomHelper::getEmpProfileDiv($birthday['employee_id']); ?></td>
                                                                <td>
                                                                    <span class="text-dark fw-bold mb-1 fs-6"> <?php echo e($birthday['employee_department']); ?></span> - <span class="text-muted fw-semibold text-muted fs-7"><?php echo e($birthday['employee_designation']); ?></span>
                                                                </td>
                                                                <td><?php echo e(date('d, F' , strtotime($birthday['dob']))); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <div class="alert alert-primary" role="alert">
                                                    No Record Found!
                                                </div>
                                            <?php endif; ?>
                                           
                                        
                                        </div>
                                    </div>   
                                </div>
                            
                            </div>
                                
                        <?php endif; ?>

                        <div class="col-xl-6">
                            <div class="card mb-5 mb-xl-8" style="height:390px">
                                <div class="card-header border-0 pt-5">
                                    <div class="card-title">
                                        Todays Interviews (<?php echo e(date('d M, Y')); ?>)
                                    </div>
                                </div> 
                                 
                                <div class="card-body py-3">
                                    <?php if(!empty($interviews)): ?>
                                        <div class="table-responsive " style="height:297px">
                                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableInterview">
                                                <thead>
                                                    <tr class="fw-bold text-muted bg-light">
                                                        <th class="ps-6">ID</th>
                                                        <th>Candidate Name</th>
                                                        <th>Interview Timing</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $interviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr <?php if(request()->get('interview_id') != '' && $interview['interview_id'] == request()->get('interview_id')): ?> style="background-color:bisque;" <?php endif; ?>>
                                                            <td class="ps-5"><?php echo e($interview['interview_id']); ?></td>
                                                            <td ><?php echo e($interview['candidate_name']); ?></td>
                                                            <td><?php echo e($interview['interview_date']); ?> - <?php echo e(date('h:i A', strtotime($interview['interview_time']))); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(url('my-interviews')); ?>" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" data-bs-title="View Interview Detail" >
                                                                
                                                                   <i class="fa fa-eye"></i>
                                                                 </a>
                                                            </td>     
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-primary" role="alert">
                                            No Interview's For Today!
                                        </div>
                                    <?php endif; ?>  
                                </div>     
                            </div>
                        </div>

                        <?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>
                            <div class="col-xl-6">
                                <div class="card mb-5 mb-xl-8">
                                    <div class="card-header border-0 pt-5">
                                        <div class="card-title">
                                            Continuous Bad Attendance Employees
                                        </div>
                                    </div> 
                    
                                    <div class="card-body py-3">
                                        <div class="table-responsive " style="height:297px">
                                            <?php if(!empty($bad_attendance_employees)): ?>
                                                <table class="table align-middle gs-0 gy-4 table-row-bordered" >
                                                    <thead>
                                                        <tr class="fw-bold text-muted bg-light">
                                                            <th class="ps-4">Employee Name</th>
                                                            <th>Attendance Status</th>
                                                            <th>Action Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                    
                                                        <?php $__currentLoopData = $bad_attendance_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bad_attendance_employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td class="ps-4"><?php echo CustomHelper::getEmpProfileDiv($bad_attendance_employee['employee_id']); ?></td>
                                                                <td><?php echo e($bad_attendance_employee['attendance_status']); ?></td>
                                                                <td><?php echo e(date('d, F' , strtotime($bad_attendance_employee['create_date']))); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                    </tbody>
                                                </table>
                                            <?php else: ?>
                                                <div class="alert alert-primary" role="alert">
                                                    No Record Found!
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>   
                                </div>
                            
                            </div>
                        <?php endif; ?>
                     
                    </div>

                </div>
                
            </div>
            
                   
        </div>
        
       
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>

<script>
    function alert_remove(alert_id) {
        $('#alert_div'+alert_id).remove();
        $.ajax({
            url: '<?php echo e(url('remove_alert/')); ?>/'+alert_id,
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
        });
    }

    $('#select-department').change(function(e){
        e.preventDefault();
        $('#employees').html('');
       var dept = $('#select-department').val();

        $.ajax({
            url: "<?php echo e(url('/get-employee-department')); ?>",
            type: 'GET',
                            
            data: {
                department : dept
            },
            
            success: function(response) {
                $('#employees').append(response);
               
                
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
                
            }
        });

    
    })

    $('#select-department-wfh').change(function(e){
        e.preventDefault();
        $('#employees-wfh').html('');
       var dept = $('#select-department-wfh').val();

        $.ajax({
            url: "<?php echo e(url('/get-employee-department')); ?>",
            type: 'GET',
                            
            data: {
                department : dept
            },
            
            success: function(response) {
                $('#employees-wfh').append(response);
               
                
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
                
            }
        });

    
    })

    $('#select-department-employee').change(function(e){
        e.preventDefault();
        $('#employee_list').html('');
        var dept = $('#select-department-employee').val();

        $.ajax({
            url: "<?php echo e(url('/get-employee-department')); ?>",
            type: 'GET',
                            
            data: {
                department : dept
            },
            
            success: function(response) {
                $('#employee_list').append(response);
            
                
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
                
            }
        });
    })
</script>

<script src="<?php echo e(url('assets/js/widgets.bundle.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/custom/widgets.js')); ?>"></script>

<?php if(!empty($permission) && !empty($permission[29]['permission_status'] == 1)): ?>
<script src="<?php echo e(url('assets/js/dashboard-expense-charts.js')); ?>"></script>
<?php endif; ?>
<script src="<?php echo e(url('assets/js/dashboard-wfh-request-chart.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/dashboard-leave-request-chart.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/dashboard-interview-chart.js')); ?>"></script>


<?php if(!empty($permission) && !empty($permission[12]['permission_status'] == 1)): ?>
<script src="<?php echo e(url('assets/js/dashboard-department-charts.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/dashboard-employee-card-charts.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/dashboard-employee-monthly-strength-charts.js')); ?>"></script>


<script>
    var active_employees = <?php echo e($active_employees); ?>

    var active_male = <?php echo e($active_male_employees); ?>;
    var active_female = <?php echo e($active_female_employees); ?>;
  
    ActiveMaleFemaleChart.init(active_employees,active_male,active_female);

    var deactive_employees = <?php echo e($deactive_employees); ?>

    var deactive_male = <?php echo e($deactive_male_employees); ?>;
    var deactive_female = <?php echo e($deactive_female_employees); ?>;

  
    DeactiveMaleFemaleChart.init(deactive_employees,deactive_male, deactive_female);


    var permanent_employees = <?php echo e($permanent_employees); ?>

    var per_male = <?php echo e($permanent_male_employees); ?>;
    var per_female = <?php echo e($permanent_female_employees); ?>;

    PermanentMaleFemaleChart.init(permanent_employees,per_male, per_female);


    var probation_employees = <?php echo e($probation_employees); ?>

    var pro_male = <?php echo e($probation_male_employees); ?>;
    var pro_female = <?php echo e($probation_female_employees); ?>;
  
    ProbationMaleFemaleChart.init(probation_employees,pro_male, pro_female);
</script>

<?php endif; ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>