

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Manage Holidays</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                <div class="m-0">
                    <a href="javascript:void(0)" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addHoliday">											
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="currentColor"></rect>
                                <rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="currentColor"></rect>
                            </svg>
                        </span>
                        Add New Holiday</a>   
                </div>
         
            </div>
            
        </div>
       
    </div>
    
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
           
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">  
                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                </div> 
                <div class="card-body py-3">
                    
                    <div class="table-responsive popup-visible ">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer table-row-bordered"><div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer" id="system_datatable" aria-describedby="tableEmployee_info">
                               					 				
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4 min-w-100px sorting">Holiday ID
                                        </th>
                                        <th class="min-w-100px sorting">Holiday Date
                                        </th>
                                        <th class="min-w-100px sorting">Holiday Reason
                                        </th>
                                        <th class="min-w-100px sorting">Department Name
                                        </th>
                                        <th class="min-w-100px sorting">Holiday Create Date	
                                        </th>
                                      
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php if(!empty($getAllHolidays)): ?>
                                        <?php $__currentLoopData = $getAllHolidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $holiday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-8"><?php echo e($holiday['holiday_id']); ?></td>
                                                <td><?php echo e($holiday['holiday_date']); ?></td>
                                                <td><?php echo e($holiday['holiday_name']); ?></td>
                                                                                                                
                                                <td>
                                                    <?php
                                                        $department_name = explode("," , $holiday['department_name']);
                                                        $count = 0
                                                    ?>
                                                    <?php $__currentLoopData = $department_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $count ++ ; ?>
                                                            <?php echo CustomHelper::get_department_name($department); ?> 
                                                        <?php if( $count  != count($department_name)): ?>
                                                            || 
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e($holiday['holiday_created_at']); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                      
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
            
            <form id="addHolidayForm" class="form">
                <?php echo csrf_field(); ?>
                <div class="modal fade" id="addHoliday" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-scrollable mw-650px">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-header">
                                <h4 class="modal-title pl-4">Add Holiday</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                    </svg>
                                </span>
                                </button>
                            </div>
                            
                            
                            <div class="modal-body scroll-y pt-0 pb-15">
                                
                                <div class ="row">
                                    <div class="col-md-10 mb-8 mt-3 fv-row">
                                        <label class="fs-6 fw-semibold mb-2 required">Department</label>
                                            
                                            <select class="form-select" id="departments_all" data-control="select2" multiple="multiple" data-hide-search="true" data-placeholder="Select Department" name="department_name[]" required>
                                                
                                                <?php $count = 0 ?>
                                                <?php if(!empty($departments)): ?>
                                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $count ++; ?>
                                                        <option value="<?php echo e($department['department_id']); ?>">
                                                            <?php echo e($department['department_name']); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                    </div>       
                                    <div class="col-md-2 mb-8 mt-3 fv-row">
                                
                                        <label class="fs-6 fw-semibold mb-2">All Departments</label>
                                            <label class="form-check form-check-custom me-10 fs-6 fw-semibold mb-2">
                                                <input type = "hidden" name="count" value="<?php echo e($count); ?>">
                                                <input class="form-check-input h-20px w-20px" type="checkbox" id="department_all" name="select_all" value="Select All" /> 
                                        
                                            </label>
                                    </div>    
                                    
                                </div>    
                                <div class="d-flex flex-column mb-8">
                                    <label class="required fs-6 fw-semibold mb-2">Holiday Date</label>
                                    
                                    <div class="position-relative d-flex align-items-center">
                                        
                                        
                                        <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                                <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                                <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                            </svg>
                                        </span>
                                        
                                        
                                        
                                        <input class="form-control ps-12 form-datetime" autocomplete="off" placeholder="Select a date"  id="kt_daterangepicker_4" name="holiday_date" required="">
                                        
                                    </div>
                                    
                                </div>
                                    
                                
                                
                                <div class="d-flex flex-column mb-8">
                                    <label class="fs-6 fw-semibold mb-2 required">Holiday Title</label>
                                    <input type="text" class="form-control" maxlength="30" name="holiday_reason" placeholder="Enter Holiday Title" required="">
                                </div>
                                
                            </div>
                            
                            
                            <div class="modal-footer justify-content-center">
                                
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit_btn" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
            </form>
            
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>

    $('#department_all').click(function() {
         
        var checkbox = $('#department_all').prop('checked');

        if(checkbox){
            $('#departments_all option').prop('selected', true);
            $('.select2-selection__rendered').html('<span class="select2-selection__choice__display" id="select2-departments_all-container-choice-5nle-Human Resource">All Departments</span>');
            $('.select2-search__field').attr('placeholder', '');
        }else{
            $('#departments_all option').prop('selected', false);
            $('.select2-selection__rendered').html('');
            $('.select2-search__field').attr('placeholder', 'Select Department');
            $('.select2-search__field').css('width', '100%');
            
        }
          
    })

     $('#departments_all').change(function() {

            var departments = $('#departments_all').val();
            var all_length = <?php echo e($count); ?>;
            if(departments.length == all_length ){
                $('#department_all').prop('checked',true);
            }else{
                $('#department_all').prop('checked',false);

            }

        });

        $('#addHolidayForm').submit(function(e) {
        e.preventDefault();

        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        
        swal.fire({
            title: 'Confirmation Alert !',
            text: 'Are you sure to submit your Holiday ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText:'Yes',
            cancelButtonText:'Cancel',
        }).then(function (value) { 
          
            if (value.isConfirmed == true) {
                $.ajax({
                    url: '<?php echo e(url('holidays/addholiday')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: $('#addHolidayForm').serialize(),
                    success: function(data) {
                        console.log(data);
                        if (data.status == 'TRUE') {
                            Toast.fire({
                                icon: 'success',
                                title: data.msg,
                                timer: 3000,
                            })
                            setTimeout(() => {
                                location.reload();
                            }, 3000);
                        } else {
                            Toast.fire({
                                icon: 'warning',
                                title: data.msg,
                                timer: 5000,
                            })
                            $('#submit_btn').prop('disabled', false);
                            $("#submit_btn").removeAttr('data-kt-indicator');
                            $('#submit_btn').css('cursor', 'pointer');
                        }
                    },
                    error: function(jqXHR, textStatus) {
                        var errorStatus = jqXHR.status;
                        $('#submit_btn').prop('disabled', false);
                        $("#submit_btn").removeAttr('data-kt-indicator');
                        $('#submit_btn').css('cursor', 'pointer');
                        if (errorStatus == 0) {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Internet Connection Problem',
                                timer: 3000,
                            })
                        } else {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Try Again. Error Code ' + errorStatus,
                                timer: 3000,
                            })
                        }
                    }
                });
            }else{
                location.reload();
            }
        });
    });
    
    $("#kt_daterangepicker_4").daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    minYear: 1901,
    minDate: new Date(),
    maxYear: parseInt(moment().format("YYYY"),12)
    }, function(start, end, label) {
        var years = moment().diff(start, "years");
    }
    );

   
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/holiday/holiday.blade.php ENDPATH**/ ?>