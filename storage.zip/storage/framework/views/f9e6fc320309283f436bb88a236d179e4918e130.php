



<?php $__env->startPush('css-link'); ?>
table.dataTable
{
 overflow-x:hidden !important;
 overflow-y:auto !important;
}
<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
						 
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
    
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                   
                    <?php if(empty($month) && empty($year)): ?>
                        Overtime Management (<?php echo e(date('F') . '-' . date('Y')); ?>)
                    <?php else: ?>
                        Overtime Management (<?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?>)
                    <?php endif; ?>
                </h1>   
                </h1>   
            </div>
           
           

        </div>
    </div>
       
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1 me-5">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                        
                    </div>
                    
                    <div class="card-toolbar" >
                    
                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                    
                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter</a>
                          
                            <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1" >
                                <form action="<?php echo e(url('overtime-management')); ?>" method="GET">
                                    <div class="px-7 py-5">
                                        <div class="fs-5 text-dark fw-bold">Filter Options</div>
                                    </div>
                                   
                                    <div class="separator border-gray-200"></div>
                                    <div class="px-7 py-5">
                                       
                                        <div class="mb-3">
                                        
                                            <label class="form-label fw-semibold">Status</label>
                                            
                                            <div>
                                                <select class="form-select " data-kt-select2="true" data-placeholder="Select Name" name="is_active"
                                                required="" id="employee_data">
                                                <option value="1" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '1'): ?> selected <?php endif; ?>>Active
                                                    Employees</option>
                                                <option value="2" <?php if(!empty(Request::get('is_active')) && Request::get('is_active') == '2'): ?> selected <?php endif; ?>>De-active
                                                    Employees</option>
                                            </select>
                                            </div>
                                            
                                        </div>
                                        
                                        <div class="mb-3">
                                            
                                            <label class="form-label fw-semibold">
                                                <span>Employee Name</span>  
                                            </label>
                                            
                                            <div>
                                                <select class="form-select " data-kt-select2="true" data-placeholder="Select Name" name="emp_name"
                                                 id="by_name">
                                                    <?php if(!empty($all_employees)): ?>
                                                    <option value="">Select Name</option>
                                                        <?php $__currentLoopData = $all_employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($data['employee_id']); ?>"<?php if(Request::get('emp_name') == $data['employee_id']): ?> selected <?php endif; ?>><?php echo e($data['employee_code']. ' - ' .$data['employee_name']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            
                                        </div>
                                        <div class="mb-3 row" >
                                            <div class="col-6">
                                            
                                                <label class="form-label fw-semibold">Select Month</label>
                                                
                                                <div>
                                                    <select class="form-select " data-kt-select2="true" data-placeholder="Select Month" name="m" required="required">
                                                        <option value="">Select Month</option>
                                                        <option value="01" <?php if(!empty($month) && $month == '01'): ?> selected  <?php elseif(empty($month) && date('m') == '01'): ?> selected  <?php endif; ?>>January
                                                        </option>
                                                        <option value="02" <?php if(!empty($month) && $month == '02'): ?> selected <?php elseif(empty($month) && date('m') == '02'): ?> selected  <?php endif; ?>>February
                                                        </option>
                                                        <option value="03" <?php if(!empty($month) && $month == '03'): ?> selected <?php elseif(empty($month) && date('m') == '03'): ?> selected  <?php endif; ?>>March
                                                        </option>
                                                        <option value="04" <?php if(!empty($month) && $month == '04'): ?> selected <?php elseif(empty($month) && date('m') == '04'): ?> selected <?php endif; ?>>April
                                                        </option>
                                                        <option value="05" <?php if(!empty($month) && $month == '05'): ?> selected <?php elseif(empty($month) && date('m') == '05'): ?> selected <?php endif; ?>>May
                                                        </option>
                                                        <option value="06" <?php if(!empty($month) && $month == '06'): ?> selected <?php elseif(empty($month) && date('m') == '06'): ?> selected <?php endif; ?>>June
                                                        </option>
                                                        <option value="07" <?php if(!empty($month) && $month == '07'): ?> selected <?php elseif(empty($month) && date('m') == '07'): ?> selected  <?php endif; ?>>July
                                                        </option>
                                                        <option value="08" <?php if(!empty($month) && $month == '08'): ?> selected <?php elseif(empty($month) && date('m') == '08'): ?> selected  <?php endif; ?>>August
                                                        </option>
                                                        <option value="09" <?php if(!empty($month) && $month == '09'): ?> selected <?php elseif(empty($month) && date('m') == '09'): ?> selected  <?php endif; ?>>September
                                                        </option>
                                                        <option value="10" <?php if(!empty($month) && $month == '10'): ?> selected  <?php elseif(empty($month) && date('m') == '10'): ?> selected <?php endif; ?>>October
                                                        </option>
                                                        <option value="11" <?php if(!empty($month) && $month == '11'): ?> selected  <?php elseif(empty($month) && date('m') == '11'): ?> selected <?php endif; ?>>November
                                                        </option>
                                                        <option value="12" <?php if(!empty($month) && $month == '12'): ?> selected <?php elseif(empty($month) && date('m') == '12'): ?> selected <?php endif; ?>>December
                                                        </option>
                                                    </select>
                                                </div>
                                                
                                            </div>
                                            <div class="col-6">
                                                
                                                <label class="form-label fw-semibold">Select Year</label>
                                                
                                                <div>
                                                    <select class="form-select " data-kt-select2="true" data-placeholder="Select Year"  name="y" required="required">
                                                        <option value="">Select Year</option>
                                                        <option value="2020" <?php if(!empty($year) && $year == '2020'): ?> selected <?php elseif(empty($year) && date('Y') == '2020'): ?> selected  <?php endif; ?>>2020
                                                        </option>
                                                        <option value="2021" <?php if(!empty($year) && $year == '2021'): ?> selected <?php elseif(empty($year) && date('Y') == '2021'): ?> selected  <?php endif; ?>>2021
                                                        </option>
                                                        <option value="2022" <?php if(!empty($year) && $year == '2022'): ?> selected <?php elseif(empty($year) && date('Y') == '2022'): ?> selected  <?php endif; ?>>2022
                                                        </option>
                                                        <option value="2023" <?php if(!empty($year) && $year == '2023'): ?> selected <?php elseif(empty($year) && date('Y') == '2023'): ?> selected  <?php endif; ?>>2023
                                                        </option>
                                                        <option value="2024" <?php if(!empty($year) && $year == '2024'): ?> selected <?php elseif(empty($year) && date('Y') == '2024'): ?> selected  <?php endif; ?>>2024
                                                        </option>
                                                        <option value="2025" <?php if(!empty($year) && $year == '2025'): ?> selected <?php elseif(empty($year) && date('Y') == '2025'): ?> selected  <?php endif; ?>>2025
                                                        </option>
                                                        <option value="2026" <?php if(!empty($year) && $year == '2026'): ?> selected <?php elseif(empty($year) && date('Y') == '2026'): ?> selected  <?php endif; ?>>2026
                                                        </option>
                                                        <option value="2027" <?php if(!empty($year) && $year == '2027'): ?> selected <?php elseif(empty($year) && date('Y') == '2027'): ?> selected  <?php endif; ?>>2027
                                                        </option>
                                                        <option value="2028" <?php if(!empty($year) && $year == '2028'): ?> selected <?php elseif(empty($year) && date('Y') == '2028'): ?> selected  <?php endif; ?>>2028
                                                        </option>
                                                        <option value="2029" <?php if(!empty($year) && $year == '2029'): ?> selected <?php elseif(empty($year) && date('Y') == '2029'): ?> selected  <?php endif; ?>>2029
                                                        </option>
                                                        <option value="2030" <?php if(!empty($year) && $year == '2030'): ?> selected <?php elseif(empty($year) && date('Y') == '2030'): ?> selected  <?php endif; ?>>2030
                                                        </option>
                                                    
                                                    </select>
                                                </div>

                                            </div>
                                        </div>
                                        
                                        <div class="d-flex justify-content-end">
                                            <?php if(!empty($month) && !empty($year)): ?>
                                                <a href="<?php echo e(url('overtime-management')); ?>" class="btn btn-sm btn-danger btn-active-light-danger me-2 "
                                                    >Reset Filter</a>
                                             <?php endif; ?>
                                            <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" >Close</button>
                                            <button type="submit" class="btn btn-sm btn-primary">Apply</button>
                                        </div>
                                        
                                    </div>
                                 </form>
                            </div>
                       
                    </div>
                </div> 
                <div class="card-body py-3">
                  						 
                    <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="table-responsive">
                        
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableEmployeeOverTime" aria-describedby="tableEmployee_info">
                                                                                                            
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-7">Employee Name</th>
                                        <th>Daily Shift Timing</th>
                                        <th>Extra Hours Worked</th>
                                        <th>Overtime Period</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php if(!empty($all_attendaces)): ?>
                                        <?php $__currentLoopData = array_reverse($all_attendaces); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!empty($all_attendance['attendance'])): ?>
                                                <?php $__currentLoopData = $all_attendance['attendance']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$atty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php 
                                                      
                                                        $employee_shift_times =  CustomHelper::calculate_shift_timings($atty['att_shift_start_time'],$atty['att_shift_end_time']);
                                                        $employee_working_hours =  CustomHelper::calculate_shift_timings($atty['att_check_in_time'],$atty['att_check_out_time']);
                                                    
                                                    ?>
                                                    <?php if( $employee_working_hours > $employee_shift_times): ?>
                                                          
                                                        <tr>
                                                            <td class="ps-6"><?php echo CustomHelper::getEmpProfileDiv($all_attendance['employee_id']); ?></td>
                                                            <td class="ps-6">  <?php echo e($employee_shift_times); ?></td>
                                                            <td class="ps-6">  <?php echo e(CustomHelper::calculate_total_overtime_monthly($all_attendance['attendance'])); ?></td>
                                                            <td class="ps-6">  <?php echo e(date('F-Y', strtotime($atty['att_for_year'].'-'.$atty['att_for_month'] ))); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(url('overtime-management/overtime-detail')); ?>/<?php echo e($all_attendance['employee_id']); ?>?is_active=<?php echo e($all_attendance['employee_isactive']); ?>&y=<?php echo e($atty['att_for_year']); ?>&m=<?php echo e($atty['att_for_month']); ?>" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" title="View Overtime detail">
                                                                    <i class="fa fa-eye" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php break; ?>;
                                                    <?php endif; ?>
                                                   
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
								
                            
                            </table>
                        </div>
                    </div>  
                </div>
                 
            </div>
            
           
        </div>
       
        
    </div>
    

</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
    
    $(function(){
        
        dataTable = $('#tableEmployeeOverTime').DataTable({
            order: false,
            aLengthMenu: [
                [10, 25, 50, 100, 500, -1],
                [10, 25, 50, 100, 500, "All"]
            ],
            iDisplayLength: 500,
        });
	});
   
    $('#employee_data').change(function(){
        var selected_val = $('#employee_data').find(":selected").val();
        $('#by_name').text('');
        $.ajax({
            url: '<?php echo e(url('get_employees')); ?>/' + selected_val,
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                status: selected_val
            },
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#by_name').append(data);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                console.log('Error Status: ' + errorStatus);
                if (errorStatus == 0) {
                    alert("Internet Connection Problem");
                } else {
                    alert("Try Again. Error Code " + errorStatus);
                }
            }
        });
    });


        

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/overtime-management/overtime-sheet.blade.php ENDPATH**/ ?>