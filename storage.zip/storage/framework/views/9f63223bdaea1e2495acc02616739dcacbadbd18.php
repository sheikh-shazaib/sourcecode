<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Portal || SourceCode</title>
    <meta charset="utf-8" />
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="" />
    <meta property="og:url" content="<?php echo e(url('/')); ?>" />
    <meta property="og:site_name" content="Keenthemes | Metronic" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="canonical" href="https://preview.keenthemes.com/metronic8" />
    <link rel="icon" href="<?php echo e(url('portal_assets/images/fav-icons.png')); ?>"/>
    <link href="<?php echo e(url('assets/css/personal-form-style.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   
    
</head>
<body>
    
</body>
</html>

    <?php
        $companySetting = CustomHelper::hcm_default_settings();
    ?>
<section>

    <div class="container">
        <div class="row my-3">
            <div class="col-md-12">
                
                <a href="#" onclick="history.back()" class="btn btn-sm fw-bold btn-primary mt-2" style="float:right"><i class="fa-solid fa-arrow-left"></i> &nbsp; Go back</a>
                <?php if($disabled == 'TRUE'): ?>
                    <a href="<?php echo e(url('/')); ?>/print-employee-information-form/<?php echo e($employee_data[0]['employee_id']); ?>" target="_blank">
                        <button type="button" class="btn btn-sm fw-bold btn-primary m-2" style="float:right"><i class="fa fa-download"></i> &nbsp; Download Form</button>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="container mt-3">
        <div class="row">
            <div class="col-lg-3">
            </div>
            <div class="col-lg-6">
                <?php if(!empty($companySetting['company_logo'])): ?>
                    <img src="<?php echo e($companySetting['company_logo']); ?>"  alt="logo" class="logo">
                <?php else: ?>
                    <img src="<?php echo e(asset('portal_assets/images/fav-icons.png')); ?>"  alt="logo" class="logo">
                <?php endif; ?>
            </div>
            <div class="col-lg-3">
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row sec1">
            <div class="col-lg-8">
                <label for="date">Date: <small><i>(Office use)</i></small></label>
                <input type="text" id="date" name="date" value="<?php echo e(date('Y-m-d')); ?>" readonly>

            </div>
            <div class="col-lg-4">
                <p><?php echo e($companySetting['company_address']); ?></p>
                <p><a href="tel:021-34540913">Contact: 021-34540913</a></p>
                <p><a href="https://sourcecode.world//">sourcecode.world</a></p>
            </div>
        </div>
    </div>
</section>

<form id="personal_information_form">
    <input type="hidden" name="_token" value="GR7zdr6LIVB0PpYOlMuJmYAvQLSN3uA03YAjkELH">        
    <div class="container mt-3">
        <div class="row sec2">
            <div class="col-md-2">
            </div>
            <div class="col-md-8">
                <h1>EMPLOYEE INFORMATION FORM</h1>
            </div>
            <div class="col-md-2">
            </div>
        </div>


        <div class="row sec3 mt-3">
            <div class="col-md-6">


                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Employee code: <small><i>(Office use)</i></small>
                    </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="rm" placeholder="0000"
                            value="<?php echo e($employee_data[0]['employee_code']); ?>" readonly="">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Name: <small><i>(As per cnic)</i></small></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" placeholder="Name"
                            value="<?php echo e($employee_data[0]['employee_name']); ?>" readonly="">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Designation: <small><i>(Office use)</i></small> </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="designation" placeholder="designation"
                            value="<?php echo e($employee_data[0]['designation_name']); ?>" readonly="">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Department: <small><i>(Office use)</i></small></label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="dept" placeholder="department"
                            value="<?php echo e($employee_data[0]['department_name']); ?>" readonly="">
                    </div>
                </div>

                <div class="form-group row">
                    <label class="col-sm-6 col-form-label">Joining date: <small><i>(Office use)</i></small></label>
                    <div class="col-sm-6">

                        <input type="date" id="birthday" name="birthday"
                            value="<?php echo e($employee_data[0]['employee_doj']); ?>" readonly="">

                    </div>

                </div>



            </div>

            
            <div class="col-md-6">
                <div class="profile-images-card">
                    <div class="profile-images">
                       
                        <?php if(empty($information_data[0]['profile_avatar']) || $information_data[0]['profile_avatar'] == ''): ?>
                                <img src="<?php echo e(asset('portal_assets/form/img/profile.png')); ?>"  id="upload-img">
                            <?php else: ?>

                                <?php if(file_exists('portal_assets/profile_pictures/'.$information_data[0]['profile_avatar'])): ?>
                                    <img src="<?php echo e(asset('portal_assets/profile_pictures'). '/' . $information_data[0]['profile_avatar']); ?>"
                                    id="upload-img">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('portal_assets/form/img/profile.png')); ?>"  id="upload-img">
                                <?php endif; ?>
                               
                            <?php endif; ?>
                    </div>
                    <div class="custom-file">
                        <?php if(empty($information_data[0]['profile_avatar']) || $information_data[0]['profile_avatar'] == ''): ?>
                        <label for="fileupload">Upload Picture</label>
                    <?php else: ?>
                        <label for="fileupload">Change Picture</label>
                    <?php endif; ?>
                    <input type="file" id="fileupload" accept="image/*" name="profile_picture">
                    </div>
                </div>
            </div>

        </div>
    </div>


    <section>
        <div class="container">
            <div class="row mt-3 tt">


                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="4" class="pi">PERSONAL INFORMATION</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">Father's Name <span class="text-danger">*</span></th>
                                <td> <span><input type="text" class="form-control f_error" name="fathersname"
                                    value="<?php echo e($information_data[0]['fathername']); ?>"><input
                                            type="hidden" class="form-control"
                                            value="<?php echo e($employee_data[0]['employee_id']); ?>"
                                            name="employeeid"><input type="hidden" class="form-control"
                                            value="<?php echo e($information_data[0]['information_id']); ?>"
                                            name="information_id"></span></td>
                                <th scope="row">Date of Birth <span class="text-danger">*</span></th>
                                <td><input type="date" class="form-control f_error" name="birthdate"
                                    value="<?php echo e($information_data[0]['dob']); ?>"></td>
                            </tr>
                            <tr>
                                <th scope="row">Gender <span class="text-danger">*</span></th>
                                <td>

                                    <select class="form-select" name="gender">
                                    <option value="">Select Gender</option>
                                        <option value="Male" <?php if( $employee_data[0]['employee_gender'] == 'Male'): ?> selected <?php endif; ?>>
                                            Male</option>
                                        <option value="Female" <?php if( $employee_data[0]['employee_gender'] == 'Female'): ?> selected <?php endif; ?>>
                                            Female</option>
                                    </select>

                                </td>
                                <th scope="row">Marital status <span class="text-danger">*</span></th>
                                <td>
                                    
                                    <select class="form-select" name='martial_status'>
                                        <option value="">Marital status</option>
                                        <option value="Single" <?php if(empty($information_data) || ($information_data[0]['maritalsatus'] == 'Single')): ?> selected <?php endif; ?>>
                                            Single</option>
                                        <option value="Married" <?php if(empty($information_data) ||  ($information_data[0]['maritalsatus'] == 'Married')): ?> selected <?php endif; ?>>
                                            Married</option>
                                        <option value="Widowed" <?php if(empty($information_data) ||  ($information_data[0]['maritalsatus'] == 'Widowed')): ?> selected <?php endif; ?>>
                                            Widowed</option>
                                        <option value="Separated"
                                            <?php if(empty($information_data) ||  ($information_data[0]['maritalsatus'] == 'Separated')): ?> selected <?php endif; ?>>Separated</option>
                                        <option value="Divorced" <?php if(empty($information_data) ||  ($information_data[0]['maritalsatus'] == 'Divorced')): ?> selected <?php endif; ?>>
                                            Divorced</option>
                                    </select>
                                    
                                </td>

                            </tr>
                            <tr>
                                <th scope="row">CNIC# <span class="text-danger">*</span></th>
                                <td> <input type="number" class="form-control" name="cnic"
                                    value="<?php echo e($employee_data[0]['employee_cnic']); ?>" readonly>
                                    
                                    </td>

                                <th scope="row">Date of expiry</th>
                                <td>

                                    <input type="date" class="form-control" name="cnic_expiry"
                                    value="<?php echo e($information_data[0]['dateofexpiry']); ?>">

                                </td>
                            </tr>


                            <tr>
                                <th scope="row">Birth place</th>
                                <td> <input type="text" class="form-control" name="birth_place"
                                    value="<?php echo e($information_data[0]['birthplace']); ?>"></td>
                                <th scope="row">Citizenship</th>
                                <td> <input type="text" class="form-control" name="citizenship"
                                    value="<?php echo e($information_data[0]['citizenship']); ?>"></td>
                            </tr>


                            <tr>
                                <th scope="row">Passport#</th>
                                <td> <input type="text" class="form-control" name="passport"
                                        value="<?php echo e($information_data[0]['passport']); ?>"></td>
                                <th scope="row">Religion <span class="text-danger">*</span></th>
                                <td>
                                    <select class="form-select" name="religion"
                                        aria-label="Default select example">
                                        <option value="">Select Religion</option>
                                        <option value="">Select Religion</option>
                                        <option value="Atheism/Agnosticism">Atheism/Agnosticism</option>
                                        <option value="Bahai" <?php if($information_data[0]['religion'] == 'Divorced'): ?> selected <?php endif; ?>>
                                            Bahai</option>
                                        <option value="Buddhism" <?php if($information_data[0]['religion'] == 'Divorced'): ?> selected <?php endif; ?>>
                                            Buddhism</option>
                                        <option value="Christianity"
                                            <?php if($information_data[0]['religion'] == 'Divorced'): ?> selected <?php endif; ?>>Christianity</option>
                                        <option value="Confucianism"
                                            <?php if($information_data[0]['religion'] == 'Divorced'): ?> selected <?php endif; ?>>Confucianism
                                        </option>
                                        <option value="Druze" <?php if($information_data[0]['religion'] == 'Druze'): ?> selected <?php endif; ?>>
                                            Druze</option>
                                        <option value="Gnosticism"
                                            <?php if($information_data[0]['religion'] == 'Gnosticism'): ?> selected <?php endif; ?>>Gnosticism</option>
                                        <option value="Hinduism"
                                            <?php if($information_data[0]['religion'] == 'Hinduism'): ?> selected <?php endif; ?>>Hinduism</option>
                                        <option value="Islam" <?php if($information_data[0]['religion'] == 'Islam'): ?> selected <?php endif; ?>>
                                            Islam</option>
                                        <option value="Jainism"
                                            <?php if($information_data[0]['religion'] == 'Jainism'): ?> selected <?php endif; ?>>Jainism</option>
                                        <option value="Rastafarianism"
                                            <?php if($information_data[0]['religion'] == 'Rastafarianism'): ?> selected <?php endif; ?>>Rastafarianism
                                        </option>
                                        <option value="Shinto" <?php if($information_data[0]['religion'] == 'Shinto'): ?> selected <?php endif; ?>>
                                            Shinto</option>
                                        <option value="Sikhism"
                                            <?php if($information_data[0]['religion'] == 'Sikhism'): ?> selected <?php endif; ?>>Sikhism</option>
                                        <option value="Zoroastrianism"
                                            <?php if($information_data[0]['religion'] == 'Zoroastrianism'): ?> selected <?php endif; ?>>Zoroastrianism
                                        </option>
                                        <option value="Traditional African Religions"
                                            <?php if($information_data[0]['religion'] == 'Traditional African Religions'): ?> selected <?php endif; ?>>Traditional African
                                            Religions
                                        </option>
                                        <option value="African Diaspora Religions"
                                            <?php if($information_data[0]['religion'] == 'African Diaspora Religions'): ?> selected <?php endif; ?>>African Diaspora
                                            Religions</option>
                                        <option value="Indigenous American Religions"
                                            <?php if($information_data[0]['religion'] == 'Indigenous American Religions'): ?> selected <?php endif; ?>>Indigenous American
                                            Religions
                                        </option>
                                    </select>
                                </td>
                            </tr>

                            <tr>


                            </tr>

                            <tr>
                                <th scope="row">Permanent Address <span class="text-danger">*</span></th>
                                <td> <input type="text" class="form-control" name="permanentaddress"
                                    value="<?php echo e($information_data[0]['permanentaddress']); ?>"></td>
                                <th scope="row">Current Address <span class="text-danger">*</span></th>
                                <td> <input type="text" class="form-control" name="currentaddress"
                                    value="<?php echo e($information_data[0]['currentaddress']); ?>"></td>
                            </tr>

                        </tbody>
                    </table>
                </div>


                <!-- BANK DETAILS-->
                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="4" class="pi">BANK DETAILS </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">Bank Name <span class="text-danger">*</span></th>
                                <td>
                                    <select class="form-control" name="bank_names" style="width: 100%;">
                                        option>
                                        <?php if(!empty($all_banks)): ?>
                                            <?php $__currentLoopData = $all_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($all_bank['bank_name']); ?>" <?php if($information_data[0]['bankname'] == $all_bank['bank_name']): ?> selected <?php endif; ?>><?php echo e($all_bank['bank_name']); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                </td>
                                <th scope="row">Bank code <span class="text-danger">*</span></th>
                                <td> <input type="number" class="form-control" name="bankcode"
                                    value="<?php echo e($information_data[0]['bankcode']); ?>"></td>
                            </tr>
                            <tr>
                                <th scope="row">Account# <span class="text-danger">*</span></th>
                                <td> <input type="number" class="form-control" name="accounnumb"
                                    value="<?php echo e($information_data[0]['accountno']); ?>"></td>
                                <th scope="row">Account title <span class="text-danger">*</span></th>
                                <td> <input type="text" class="form-control" name="accountitle"
                                    value="<?php echo e($information_data[0]['accounttitle']); ?>"></td>
                            </tr>

                            <tr>
                                <th scope="row">IBAN number <span class="text-danger">*</span></th>
                                <td> <input type="text" class="form-control" name="ibannumb"
                                    value="<?php echo e($information_data[0]['ibannumber']); ?>"></td>
                            </tr>
                        </tbody>
                    </table>
                </div>



                <!-- History employee-->
                <div class="table-responsive-sm table-responsive-md table-responsive-lg">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="8" class="pi">EMPLOYEMENT HISTORY
                                    <small>(Starting with your current organization)</small><span
                                        class="text-danger">*</span></th>
                            </tr>
                            <tr>
                                <th scope="col">Employers's Name</th>
                                <th scope="col">Designation</th>
                                <th scope="col">Salary & Benefits</th>
                                <th scope="col">Duration(Start/End date)</th>
                                <th scope="col">Reason for leaving<span class="text-danger">*</span></th>
                            </tr>
                        </thead>
                        <?php
                            $emphistory = $information_data[0]['employementhistory'] ? json_decode($information_data[0]['employementhistory']) : '';
                            $empcount = $emphistory ? count($emphistory) : 1;
                        ?>
                        <tbody id="employee_history_container">
                            <input type="hidden" name="employement_history_length" value="<?php echo e($empcount); ?>">

                            <?php for($i = 1; $i <= $empcount; $i++): ?>
                            <?php $temp =  ($emphistory) ? $emphistory[$i-1] : '' ?>
                    
                                <tr id="employee_row<?php echo e($i); ?>">
                                    <td scope="row"><input type="text" class="form-control"
                                        name="employername<?php echo e($i); ?>"
                                        value="<?php echo e($emphistory ? $temp->employername : ''); ?>"></td>
                                    <td><input type="text" class="form-control"
                                        name="designation<?php echo e($i); ?>"
                                        value="<?php echo e($emphistory ? $temp->designation : ''); ?>"></td>
                                    <td><input type="text" class="form-control"
                                        name="salaryandbenefits<?php echo e($i); ?>"
                                        value="<?php echo e($emphistory ? $temp->salaryandbenefits : ''); ?>"></td>
                                    <td>
                                        <table>
                                            <tr>
                                                <td>

                                                    <input type="date" class="form-control"
                                                    name="durationstartdate<?php echo e($i); ?>"
                                                    value="<?php echo e($emphistory ? $temp->durationstartdate : ''); ?>">

                                                </td>
                                                <td>

                                                    <input type="date" class="form-control"
                                                    name="durationenddate<?php echo e($i); ?>"
                                                    value="<?php echo e($emphistory ? $temp->durationenddate : ''); ?>">

                                                </td>
                                            </tr>
                                        </table>

                                    </td>
                                    <td><input type="text" class="form-control"
                                        name="reasonforleaving<?php echo e($i); ?>"
                                        value="<?php echo e($emphistory ? $temp->reasonforleaving : ''); ?>"></td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                    <div class="text-center">
                        <div class="btn-group mb-3">
                            <button type="button" class="btn btn-primary" onclick="addEmployeeRow()">Add
                                More</button>
                            <button type="button" class="btn btn-dark mx-3"
                                onclick="deleteEmployeeRow()">Less One</button>
                        </div>
                    </div>
                </div>




                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="8" class="pi">ACADEMIC CREDENTIALS<span
                                        class="text-danger">*</span></th>
                            </tr>
                            <tr>
                                <th scope="col">Degree</th>
                                <th scope="col">Institution</th>
                                <th scope="col">Majors</th>
                                <th scope="col">Passing year</th>
                                <th scope="col">Grade/CGPA</th>
                            </tr>
                        </thead>
                            <?php
                                $acadcred = $information_data[0]['academiccredential'] ? json_decode($information_data[0]['academiccredential']) : '';
                                $acadcount = $acadcred ? count($acadcred) : 1;
                            ?>
                            <tbody id="academic_credential_container">
                                <input type="hidden" name="academic_credential_length" value="<?php echo e($acadcount); ?>">

                                <?php for($i = 1; $i <= $acadcount; $i++): ?>
                                    <?php $temp =  ($acadcred) ? $acadcred[$i-1] : '' ?>
                                    <tr id="academic_row<?php echo e($i); ?>">
                                        <th scope="row"><input type="text" class="form-control"
                                                name="degree<?php echo e($i); ?>"
                                                value="<?php echo e($acadcred ? $temp->degree : ''); ?>"></th>
                                        <td><input type="text" class="form-control"
                                                name="intitution<?php echo e($i); ?>"
                                                value="<?php echo e($acadcred ? $temp->intitution : ''); ?>"></td>
                                        <td><input type="text" class="form-control"
                                                name="majors<?php echo e($i); ?>"
                                                value="<?php echo e($acadcred ? $temp->majors : ''); ?>">
                                        </td>
                                        <td><input type="text" class="form-control"
                                                name="passingyear<?php echo e($i); ?>"
                                                value="<?php echo e($acadcred ? $temp->passingyear : ''); ?>">
                                        </td>
                                        <td><input type="text" class="form-control"
                                                name="grade<?php echo e($i); ?>"
                                                value="<?php echo e($acadcred ? $temp->grade : ''); ?>"></td>
                                    </tr>
                                <?php endfor; ?>

                            </tbody>
                    </table>
                    <div class="text-center">
                        <div class="btn-group mb-3">
                            <button type="button" class="btn btn-primary" onclick="addAcademicRow()">Add
                                More</button>
                            <button type="button" class="btn btn-dark mx-3"
                                onclick="deleteAcademicRow()">Less One</button>
                        </div>
                    </div>
                </div>




                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="8" class="pi">PROFESSIONAL QUALIFICATION /
                                    CERTIFICATIONS / TRAININGS (If any)</th>
                            </tr>
                            <tr>
                                <th scope="col">Type</th>
                                <th scope="col">Details</th>
                                <th scope="col">Institute</th>
                                <th scope="col">From</th>
                                <th scope="col">Till</th>
                            </tr>
                        </thead>
                        <?php
                        $profqua = $information_data[0]['professionalqualification'] ? json_decode($information_data[0]['professionalqualification']) : '';
                        $profcount = $profqua ? count($profqua) : 1;
                    ?>
                    <tbody id="professional_qualification_container">
                        <input type="hidden" name="professional_qualification_length"
                            value="<?php echo e($profcount); ?>">
                        <?php for($i = 1; $i <= $profcount; $i++): ?>
                            <?php $temp =  ($profqua) ? $profqua[$i-1] : '' ?>

                            <tr id="qualification_row<?php echo e($i); ?>">
                                <th scope="row"><input type="text" class="form-control"
                                        name="type<?php echo e($i); ?>"
                                        value="<?php echo e($profqua ? $temp->type : ''); ?>"></th>
                                <td><input type="text" class="form-control"
                                        name="details<?php echo e($i); ?>"
                                        value="<?php echo e($profqua ? $temp->details : ''); ?>"></td>
                                <td><input type="text" class="form-control"
                                        name="institute<?php echo e($i); ?>"
                                        value="<?php echo e($profqua ? $temp->institute : ''); ?>"></td>
                                <td><input type="text" class="form-control"
                                        name="from<?php echo e($i); ?>"
                                        value="<?php echo e($profqua ? $temp->from : ''); ?>"></td>
                                <td><input type="text" class="form-control"
                                        name="till<?php echo e($i); ?>"
                                        value="<?php echo e($profqua ? $temp->till : ''); ?>"></td>
                            </tr>
                        <?php endfor; ?>

                    </tbody>
                    </table>
                    <div class="text-center">
                        <div class="btn-group mb-3">
                            <button type="button" class="btn btn-primary" onclick="addQualificationRow()">Add
                                More</button>
                            <button type="button" class="btn btn-dark mx-3"
                                onclick="deleteQualificationRow()">Less One</button>
                        </div>
                    </div>
                </div>


                <!-- relatives -->
                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="4" class="pi">DO YOU HAVE ANY RELATIVES AT
                                    SOURCECODE PRIVATE LIMITED?</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th colspan="4" class="text-center">Relative 1</th>
                            </tr>
                            <tr>
                                <th scope="row">Name</th>
                                <td> <input type="text" class="form-control" name="relativename1"
                                        value="<?php echo e($information_data[0]['relativename1']); ?>"></td>
                                <th scope="row">Designation</th>
                                <td> <input type="text" class="form-control" name="relativedesignation1"
                                        value="<?php echo e($information_data[0]['relativedesignation1']); ?>"></td>
                            </tr>

                            <tr>
                                <th scope="row">Department</th>
                                <?php echo csrf_field(); ?>
                                <td> <input type="text" class="form-control" name="relativedepartment1"
                                        value="<?php echo e($information_data[0]['relativedepartment1']); ?>"></td>
                                <th scope="row">Relation type</th>
                                <td> <input type="text" class="form-control" name="relativerelationtype1"
                                        value="<?php echo e($information_data[0]['relativerelationtype1']); ?>"></td>
                            </tr>
                            <tr>
                                <th colspan="4" class="text-center">Relative 2</th>
                            </tr>
                            <tr>
                                <th scope="row">Name</th>
                                <td> <input type="text" class="form-control" name="relativename2"
                                        value="<?php echo e($information_data[0]['relativename2']); ?>"></td>
                                <th scope="row">Designation</th>
                                <td> <input type="text" class="form-control" name="relativedesignation2"
                                        value="<?php echo e($information_data[0]['relativedesignation2']); ?>"></td>
                            </tr>

                            <tr>
                                <th scope="row">Department</th>
                                <td> <input type="text" class="form-control" name="relativedepartment2"
                                        value="<?php echo e($information_data[0]['relativedepartment2']); ?>"></td>
                                <th scope="row">Relation type</th>
                                <td> <input type="text" class="form-control" name="relativerelationtype2"
                                        value="<?php echo e($information_data[0]['relativerelationtype2']); ?>"></td>
                            </tr>


                        </tbody>
                    </table>
                </div>



                <!-- relatives -->
                <div class="table-responsive-sm table-responsive-md table-responsive-lg ">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th scope="col" colspan="4" class="pi">PREVIOUS APPLICATION IN
                                    SOURCECODE?
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th scope="row">Have you applied in Sourcecode before?</th>
                                <td>
                                    <select class="form-select" name="appliedbefore" aria-label="Default select example" onchange="appliedBefore(this.value)">
                                        <option selected>Select Option</option>
                                        <option value="Yes"  <?php if($information_data[0]['appliedbefore'] == 'Yes'): ?> selected <?php endif; ?>>Yes, I've Applied</option>
                                        <option value="No"  <?php if($information_data[0]['appliedbefore'] == 'No'): ?> selected <?php endif; ?>>No, I haven't Applied</option>
                                    </select>
                                </td>
                            </tr>
                            <tr class=" <?php if($information_data[0]['appliedbefore'] == 'No'): ?> d-none <?php endif; ?> appliedBeforeDiv">
                                <th scope="row">What Position</th>
                                <td> <input type="text" class="form-control" name="whatposition"
                                        value="<?php echo e($information_data[0]['whatposition']); ?>"></td>
                            </tr>
                            <tr class=" <?php if($information_data[0]['appliedbefore'] == 'No'): ?> d-none <?php endif; ?> appliedBeforeDiv">
                                        <th scope="row">Result of Application</th>
                                <td> <input type="text" class="form-control" name="resultofapplication"
                                        value="<?php echo e($information_data[0]['resultofapplication']); ?>"></td>
                            </tr>



                        </tbody>
                    </table>
                </div>

            </div>
        </div>
        <div class="row text-center">
            <div class="col-md-12">
                <button class="btn submit-btn-form" style="background: #1076bc; color:#fff;padding: 15px 25px 15px 25px;">SAVE
                    INFORMATION</button>
            </div>
        </div>
    </section>

</form>



    
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>

    <script src="<?php echo e(url('portal_assets/form/js/main.js')); ?>"></script>
    <script src="<?php echo e(url('portal_assets/form/js/form-validation.js')); ?>"></script>
    <script src="<?php echo e(url('portal_assets/form/js/jquery-latest.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/plugins/inputmask/jquery.inputmask.min.js')); ?>" ></script>
    <script>
        $(function() {
            // $('[data-mask]').inputmask();
            $("#fileupload").change(function(event) {
                var x = URL.createObjectURL(event.target.files[0]);
                $("#upload-img").attr("src", x);
                console.log(event);
            });
        });

        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });


        function timer_ajax() {
        
            let myform = $("#personal_information_form")[0];
            $.ajax({
                url: "<?php echo e(url('savemypersonalinformation')); ?>",
                type: 'POST',
                data: new FormData(myform),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    console.log("success")},
                error: function(jqXHR, textStatus) {
                    console.log(textStatus);
                }
            });
        }

        function runner() {
            timer_ajax();
            setTimeout(function() {
                runner();
            }, 20000);
        }
        var disabled = "<?php echo e($disabled); ?>";
        if (disabled == 'TRUE') {
            $(".btn-group,.submit-btn-form,.custom-file").hide();
            $('input').attr('readonly', true);
            $('option:not(:selected)').attr('disabled', true);
        } else {
            runner();
        }


        function appliedBefore(e){
            if(e == 'Yes'){
                $(".appliedBeforeDiv").removeClass('d-none');
            }else{
                $(".appliedBeforeDiv").addClass('d-none');
            }
        }
      

        // Employement History ==============================
        var employement_history;

        function addEmployeeRow() {

            employement_history = $("input[name=employement_history_length]").val();
            if (employement_history >= 5) {
                toastFire();
                return true;
            }
            employement_history++;
            $("input[name=employement_history_length]").val(employement_history);

            $("#employee_history_container").append(`
                <tr id="employee_row${employement_history}">
                    <td scope="row"><input type="text" class="form-control" name="employername${employement_history}" value=""></td>
                    <td><input type="text" class="form-control" name="designation${employement_history}" value=""></td>
                    <td><input type="text" class="form-control" name="salaryandbenefits${employement_history}" value=""></td>
                    <td>
                        <table>
                            <tr>
                                <td>
                                        <input type="date" class="form-control" name="durationstartdate${employement_history}" value="">
                                </td>
                                <td>
                                        <input type="date" class="form-control" name="durationenddate${employement_history}" value="">
                                </td>
                            </tr>
                        </table>

                    </td>
                    <td><input type="text" class="form-control" name="reasonforleaving${employement_history}" value=""></td>
                </tr>
            `);
        }

        function deleteEmployeeRow() {
            employement_history = $("input[name=employement_history_length]").val();
            if (employement_history > 1) {
                if (confirm("Are you sure to delete this last record") == true) {
                    $("#employee_row" + employement_history).remove();
                    employement_history--;
                    $("input[name=employement_history_length]").val(employement_history);
                }

            }
        }

        // Academic Credential History ==============================
        var academic_credential;

        function addAcademicRow() {
            academic_credential = $("input[name=academic_credential_length]").val();
            if (academic_credential >= 5) {
                toastFire();
                return true;
            }
            academic_credential++;
            $("input[name=academic_credential_length]").val(academic_credential);

            $("#academic_credential_container").append(`
                <tr id="academic_row${academic_credential}">
                    <td scope="row"><input type="text" class="form-control" name="degree${academic_credential}" value=""></td>
                    <td><input type="text" class="form-control" name="intitution${academic_credential}" value=""></td>
                    <td><input type="text" class="form-control" name="majors${academic_credential}" value=""></td>
                    <td><input type="text" class="form-control" name="passingyear${academic_credential}" value=""></td>
                    <td><input type="text" class="form-control" name="grade${academic_credential}" value=""></td>

                </tr>
            `);
        }

        function deleteAcademicRow() {
            academic_credential = $("input[name=academic_credential_length]").val();
            if (academic_credential > 1) {
                if (confirm("Are you sure to delete this last record") == true) {
                    $("#academic_row" + academic_credential).remove();
                    academic_credential--;
                    $("input[name=academic_credential_length]").val(academic_credential);
                }
            }
        }



        // Professional Qualification History ==============================
        var professional_qualification;

        function addQualificationRow() {
            professional_qualification = $("input[name=professional_qualification_length]").val();

            if (professional_qualification >= 5) {
                toastFire();
                return true;
            }
            professional_qualification++;
            $("input[name=professional_qualification_length]").val(professional_qualification);

            $("#professional_qualification_container").append(`
                <tr id="qualification_row${professional_qualification}">
                    <td scope="row"><input type="text" class="form-control" name="type${professional_qualification}" value=""></td>
                    <td><input type="text" class="form-control" name="details${professional_qualification}" value=""></td>
                    <td><input type="text" class="form-control" name="institute${professional_qualification}" value=""></td>
                    <td><input type="text" class="form-control" name="from${professional_qualification}" value=""></td>
                    <td><input type="text" class="form-control" name="till${professional_qualification}" value=""></td>

                </tr>
            `);
        }

        function deleteQualificationRow() {
            professional_qualification = $("input[name=professional_qualification_length]").val();
            if (professional_qualification > 1) {
                if (confirm("Are you sure to delete this last record") == true) {
                    $("#qualification_row" + professional_qualification).remove();
                    professional_qualification--;
                    $("input[name=professional_qualification_length]").val(professional_qualification);

                }
            }
        }

        function toastFire() {
            Toast.fire({
                icon: 'warning',
                title: 'You are not allowed to enter more than 5 records',
                timer: 3000,
            })
        }


       
    </script>

<?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/personal-information/form.blade.php ENDPATH**/ ?>