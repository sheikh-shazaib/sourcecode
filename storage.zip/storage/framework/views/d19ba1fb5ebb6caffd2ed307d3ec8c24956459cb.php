

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">My Payroll  </h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">


                <div class="m-0">
                    <form id="calculateMyPayrollAmountForm" >
                        <input type="hidden" name="calculateMyPayrollAmountForm" value="calculateMyPayrollAmountForm" >
                        <button type="submit" class="btn btn-sm btn-primary">
                            <span class="svg-icon svg-icon-2">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.3" d="M3 3V17H7V21H15V9H20V3H3Z" fill="currentColor"/>
                                    <path d="M20 22H3C2.4 22 2 21.6 2 21V3C2 2.4 2.4 2 3 2H20C20.6 2 21 2.4 21 3V21C21 21.6 20.6 22 20 22ZM19 4H4V8H19V4ZM6 18H4V20H6V18ZM6 14H4V16H6V14ZM6 10H4V12H6V10ZM10 18H8V20H10V18ZM10 14H8V16H10V14ZM10 10H8V12H10V10ZM14 18H12V20H14V18ZM14 14H12V16H14V14ZM14 10H12V12H14V10ZM19 14H17V20H19V14ZM19 10H17V12H19V10Z" fill="currentColor"/>
                                </svg>
                            </span>
                            Calculate Payroll Amount
                        </button>

                    </form>
                </div>

            </div>
            
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">
            
            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                </div>
                
                <div class="card-body py-3">

                    <div class="table-responsive popup-visible ">
                        
                        <div id="tablePayroll_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="table-responsive">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="system_datatable" aria-describedby="tableEmployee_info">
                                				 				
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="text-center" >Slip No.</th>
                                        <th>Pay Period</th>
                                        <th>Total Earning</th>
                                        <th>Total Deduction</th>
                                        <th>Net Salary</th>
                                        <th>Generation Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($fetch_employee_payroll)): ?>
                                        <?php $__currentLoopData = $fetch_employee_payroll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee_payroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-8"><?php echo e($employee_payroll['pc_id']); ?></td>                                                <td><?php echo e(date('M-Y',strtotime($employee_payroll['pc_year'].'-'.$employee_payroll['pc_month'].'-'.'01'))); ?> </td>
                                                <td><?php echo e($employee_payroll['pc_employee_gross_salary']); ?></td>
                                                <td><?php echo e($employee_payroll['pc_employee_deduction']); ?></td>
                                                <td><?php echo e($employee_payroll['pc_employee_net_salary']); ?></td>
                                                <td><?php echo e(date('d-M-Y',strtotime($employee_payroll['pc_created_at']))); ?></td>
                                                
                                                        
                                                <td>
                                                    <a  href="<?php echo e(url('individual-payroll-pdf/'.$employee_payroll['pc_id'])); ?>" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="tooltip" title="View Payroll" target="_blank" > 
                                                        <i class="fas fa-file" aria-hidden="true"></i>
                                                        
                                                    </a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
        </div>
    </div>
</div>






<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>

    $('#calculateMyPayrollAmountForm').submit(function(e) {

        e.preventDefault();

        var url = "<?php echo e(url('/calculate-my-payroll')); ?>"


        $('.submit_btn').prop('disabled', true);
        $('.submit_btn').attr('data-kt-indicator', 'on');
        $('.submit_btn').css('cursor', 'not-allowed');

        let form_data = new FormData(this);

        body_data = {
    
            // Adding method type
            method: 'POST',

            // Adding body or contents to send
            // body: JSON.stringify({form_data}),
            body : form_data,
        
            // Adding headers to the request
            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }


        fetch(url,body_data)

        // Converting to JSON
        .then(response =>{
            // response.json()
            if (response.ok) {
                return response.json();
            }

            return Promise.reject(response);
        })


        // Displaying results to console
        .then(json =>{
            // console.log(json);

        if (json.status == 'TRUE') {

            $('.submit_btn').prop('disabled', false);
            $('.submit_btn').removeAttr('data-kt-indicator');
            $('.submit_btn').css('cursor', 'pointer');

            Swal.fire({
            title: json.title,
            text: json.text,
            icon: json.icon,
            buttonsStyling: false,
            confirmButtonText: "Ok, got it!",
            customClass: {
            confirmButton: "btn btn-primary"
            }

            }).then(function(result) {
                if (result.value) {
                    location.reload();
                }
            });


        } else {


            Swal.fire({
            title: json.title,
            text: json.text,
            icon: json.icon,
            buttonsStyling: false,
            confirmButtonText: "Ok, got it!",
            customClass: {
                confirmButton: "btn btn-primary"
            }
            });

            $('.submit_btn').prop('disabled', false);
            $('.submit_btn').removeAttr('data-kt-indicator');
            $('.submit_btn').css('cursor', 'pointer');

        }

        }).catch(response => {

            $('.submit_btn').prop('disabled', false);
            $('.submit_btn').removeAttr('data-kt-indicator');
            $('.submit_btn').css('cursor', 'pointer');

            Swal.fire({
                icon: 'warning',
                title: response.statusText,
                buttonsStyling: false,
                confirmButtonText: "Ok, got it!",
                customClass: {
                confirmButton: "btn btn-primary"
                }
                
            })

        });


    })
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/payroll/my-payroll.blade.php ENDPATH**/ ?>