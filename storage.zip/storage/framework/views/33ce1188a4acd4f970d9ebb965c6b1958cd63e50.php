

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Employees Work Anniversary
                    <?php if(empty(Request::get('m'))): ?>
                        (<?php echo e(date('F')); ?>)
                    <?php else: ?>
                        (<?php echo e(date("F", mktime(0, 0, 0, Request::get('m'), 10))); ?>)
                    <?php endif; ?> 
                </h1>   
            </div> 
        </div>
        
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container">

            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                    <div class="card-toolbar">
                        
                        <a href="#" class="btn btn-sm btn-flex btn-light btn-active-color-primary fw-bold" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                    
                        <span class="svg-icon svg-icon-6 svg-icon-muted me-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="currentColor"></path>
                            </svg>
                        </span>
                        Filter</a>
                        <div class="menu menu-sub menu-sub-dropdown w-250px w-md-300px" data-kt-menu="true" id="kt_menu_63347db386dd1">
                            
                            <div class="px-7 py-5">
                                <div class="fs-5 text-dark fw-bold">Filter Options</div>
                            </div>

                            <div class="separator border-gray-200"></div>
                            <div class="px-7 py-5">
                                <form action="<?php echo e(url('employee-work-anniversay')); ?>" method="GET">
                                    <div class="mb-10">
                                        
                                        <label class="form-label fw-semibold">Select Month:</label>
                                        
                                        <div>
                                            <select class="form-select " data-kt-select2="true" data-placeholder="Select Month" name="m" required="">
                                                <option value="">Select Month</option>
                                                <option value="">Select Month</option>
                                                <option value="01" <?php if(!empty(Request::get('m')) && Request::get('m') == '01'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '01'): ?> selected <?php endif; ?>>January</option>
                                                <option value="02" <?php if(!empty(Request::get('m')) && Request::get('m') == '02'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '02'): ?> selected  <?php endif; ?>>February</option>
                                                <option value="03" <?php if(!empty(Request::get('m')) && Request::get('m') == '03'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '03'): ?> selected  <?php endif; ?>>March</option>
                                                <option value="04" <?php if(!empty(Request::get('m')) && Request::get('m') == '04'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '04'): ?> selected  <?php endif; ?>>April</option>
                                                <option value="05" <?php if(!empty(Request::get('m')) && Request::get('m') == '05'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '05'): ?> selected  <?php endif; ?>>May</option>
                                                <option value="06" <?php if(!empty(Request::get('m')) && Request::get('m') == '06'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '06'): ?> selected  <?php endif; ?>>June</option>
                                                <option value="07" <?php if(!empty(Request::get('m')) && Request::get('m') == '07'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '07'): ?> selected  <?php endif; ?>>July</option>
                                                <option value="08" <?php if(!empty(Request::get('m')) && Request::get('m') == '08'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '08'): ?> selected  <?php endif; ?>>August</option>
                                                <option value="09" <?php if(!empty(Request::get('m')) && Request::get('m') == '09'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '09'): ?> selected  <?php endif; ?>>September</option>
                                                <option value="10" <?php if(!empty(Request::get('m')) && Request::get('m') == '10'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '10'): ?> selected  <?php endif; ?>>October</option>
                                                <option value="11" <?php if(!empty(Request::get('m')) && Request::get('m') == '11'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '11'): ?> selected  <?php endif; ?>>November</option>
                                                <option value="12" <?php if(!empty(Request::get('m')) && Request::get('m') == '12'): ?> selected <?php elseif(empty(Request::get('m')) && date('m') == '12'): ?> selected  <?php endif; ?>>December</option>
                                            </select>
                                            </select>
                                        </div>
                                        
                                    </div>
                                    <div class="d-flex justify-content-end">
                                        <?php if(!empty(Request::get('m'))): ?>
                                           
                                        <a href="<?php echo e(url('employee-work-anniversay')); ?>" class="btn btn-sm btn-danger btn-active-light-danger me-2 "
                                            >Reset Filter</a>
                                        <?php endif; ?>
                                        <button type="reset" class="btn btn-sm btn-light btn-active-light-primary me-2" data-kt-menu-dismiss="true">Close</button>
                                        <button type="submit" class="btn btn-sm btn-primary">Apply</button>
                                    </div>
                                </form>
                                
                            </div>
                            
                        </div>
                    </div>
                </div> 
   
                <div class="card-body py-3">
                    
                    <div class="table-responsive popup-visible ">
                        
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer"><div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableEmployeeWorkAnniversary" aria-describedby="tableEmployee_info">
                            
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4">Name</th>
                                        <th>Employee Depart & Desig</th>
                                        <th>Employee DOJ</th>
                                        <th>Duration</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($employees)): ?>
                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-4"><?php echo CustomHelper::getEmpProfileDiv($employee['employee_id']); ?></td>
                                                <td><?php echo e($employee['department_name']); ?> - <b><?php echo e($employee['designation_name']); ?></b></td>
                                                <td><?php echo e(date('d, F Y' ,strtotime($employee['employee_doj']))); ?></td>
                                                <td>
                                                    <span class="badge badge-light-success fs-7 fw-bold"><?php echo e(CustomHelper::calculate_employeement_duration_period($employee['employee_doj']  , date('Y-m-d'))); ?></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            
                            </table>
                        </div>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){
		dataTable = $('#tableEmployeeWorkAnniversary').DataTable({
            order:false,
        });
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
	});
    
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/employee/employee-work-anniversary.blade.php ENDPATH**/ ?>