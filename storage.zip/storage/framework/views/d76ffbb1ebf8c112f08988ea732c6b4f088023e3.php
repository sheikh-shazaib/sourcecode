<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" >
    <style>

        .header{
            margin-top: 5px;
        }
        .company-logo {

            margin-left: 10%;
            width: 30%;
            float: left;
            padding: 15px;
           
        }

        .company-name {
            top: 10px;
            width: 60%;
            float: left;
            padding: 15px;
          
        }
        .company-name span{
            font-size: 25px;
            font-weight: bold;
        }
       
        .td-border{
            border:1px solid;
            font-size: 11px;
        }
        .table-data{
            padding-left:100px;
            padding-top:15px;
           

        }


        .col-1 {width: 8.33%;}
        .col-2 {width: 16.66%;padding-bottom:2%}
        .col-3 {width: 25%;}
        .col-4 {width: 33.33%;}
        .col-5 {width: 41.66%;}
        .col-6 {width: 50%;}
        .col-7 {width: 58.33%;}
        .col-8 {width: 66.66%;}
        .col-9 {width: 75%;}
        .col-10 {width: 83.33%;}
        .col-11 {width: 91.66%;}
        .col-12 {width: 100%;}
    </style>
    </head>
    <body>
       
        <div class="header">
            <div class="company-logo">
                <?php if(!empty($setting[0]['company_logo'])): ?>
                    <img src="<?php echo e(public_path('/portal_assets/setting/images/'.$setting[0]['company_logo'])); ?>" draggable="false" class="img-fluid" alt="Source Code logo" style="width:50%">
                <?php else: ?>
                    <img src="<?php echo e(public_path('/portal_assets/images/default-img.png')); ?>" draggable="false" class="img-fluid" >
                <?php endif; ?>
              
            </div>

            <div class="company-name">
                <span><?php echo e($setting[0]['company_name']); ?></span>
            </div>
        </div>

        <div class="col-10" style="clear:left;margin-left:10%">
            <hr class="hr">
        </div>

        <div class="col-12" >
            <h2 class="text-center" style="margin-top:1%">Employee Attendance Sheet</h2>
        </div>

        <div class="col-10" style="margin-left:10%;">
            <table>
                <tr>
                    <td style="width:20%;padding-top:15px"><label><b>Employee Id</b></label></td>
                    <td style="width:20%" class="table-data"><span><?php echo e($employee[0]['employee_code']); ?></span></td>
                    <td style="width:20%" class="table-data"><label><b>Department</b></label></td>
                    <td style="width:20%" class="table-data"><span><?php echo e($employee[0]['department_name']); ?></span></td>
                </tr>
                <tr>
                    <td style="width:20%;padding-top:15px"><label><b>Employee Name</b></label></td>
                    <td style="width:40%;" class="table-data"><span><?php echo e($employee[0]['employee_name']); ?></span></td>
                    <td style="width:20%;padding-top:15px" class="table-data"><label><b>Designation</b></label></td>
                    <td style="width:20%" class="table-data"><span><?php echo e($employee[0]['designation_name']); ?></span></td>
                </tr>
                <tr>
                    <td style="width:20%;padding-top:15px"><label><b>Position</b></label></td>
                    <td style="width:40%" class="table-data"><span><?php echo e($employee[0]['employee_jobtitle']); ?></span></td>
                    <td style="width:10%;padding-top:15px" class="table-data"><label><b>Location</b></label></td>
                    <td style="width:50%" class="table-data"><span><?php echo e($setting[0]['company_address']); ?></span></td>
                </tr>
            </table>
        </div>
        
        <div class="col-10" style="margin-left:10%;margin-top:3%">
            
            <div class="row">
                <table>
                    <thead>
                        <tr style="background:lightgray">
                            <th rowspan="2" class="text-center td-border">Attendance Date </th>
                            <th colspan="2" class="text-center td-border">Check In</th>
                            <th colspan="2" class="text-center td-border">Check Out </th>
                            <th rowspan="2" class="text-center td-border">Work Hours</th>
                            <th rowspan="2" class="text-center td-border">Extra Hours</th>
                            <th rowspan="2" class="text-center td-border">Late Minutes</th>
                            <th rowspan="2" class="text-center td-border">Early Depar. Minutes</th>
                            <th rowspan="2" class="text-center td-border">Leave/Deputation</th>
                            <th rowspan="2" class="text-center td-border">Att Source</th>
                            <th rowspan="2" class="text-center td-border">Status </th>
                        </tr>
                        <tr style="background:lightgray">
                            <th class="text-center">Date</th>
                            <th class="text-center">Time</th>
                            <th class="text-center">Date</th>
                            <th class="text-center">Time</th>
                        </tr>
                    </thead>
    
                    <tbody>
                        <?php for($month_count = 1; $month_count <= $month_days; $month_count++): ?>
                        <?php $absent = true; ?>
                        <tr style="border:1px solid" >
                            <?php
                                $current_date = $month_count . '-' . $month . '-' . $year;
                                $nameOfDay = date("l", strtotime($current_date ));	
                            ?>
                            
                            <td class="text-center td-border" >
                                <?php echo e($current_date); ?>

                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php endif; ?>
    
                                            <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                                <?php echo e($attendance['att_check_in_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                                <?php echo e($attendance['att_check_in_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                                <?php echo e($attendance['att_check_in_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                                <?php echo e($attendance['att_check_in_time']); ?>

                                            <?php endif; ?>
    
                                            <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                                <?php echo e($current_date); ?>

                                            <?php endif; ?>
    
                                            <?php if($attendance['att_check_in_time'] == '' || $attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e($attendance['att_check_out_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e($attendance['att_check_out_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e($attendance['att_check_out_time']); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            <?php echo e($attendance['att_check_out_time']); ?>

                                            <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                               
                                            <?php endif; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>  
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                                <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                                <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                                <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                                <?php echo e(CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time'])); ?>

                                            <?php endif; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
    
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $employee_shift_times =  CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                            $employee_working_hours =   CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time']);
                                        
                                        ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            
                                            <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            
                                            <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                                
                                            <?php endif; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                    00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($employee) && $employee[0]['employee_shift_flexibilty'] != 1): ?>
                                    <?php if(!empty($attendances)): ?>
    
                                        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php 
                                                $employee_shift_times =   CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                            ?>
                                            <?php if($attendance['att_for_date'] == $month_count): ?>
                                                <?php $absent = false; ?>
                                                
                                                <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                
                                                <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                                <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                    <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                                <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                    <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                                <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                    <?php echo e(CustomHelper::late_checkIn_hour($attendance['att_shift_start_time'],$attendance['att_check_in_time'])); ?>

                                                <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                                    
                                                <?php endif; ?>
                                                <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                        00:00:00
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
    
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $employee_shift_times =  CustomHelper::calculate_shift_timings($attendance['att_shift_start_time'],$attendance['att_shift_end_time']);
                                            $employee_working_hours =   CustomHelper::calculate_shift_timings($attendance['att_check_in_time'],$attendance['att_check_out_time']);
                                        ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            
                                            <?php if($attendance['att_check_overall_status'] == 'Present' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                            
                                            <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out' && $attendance['att_check_out_time'] != '00:00:00'): ?>
                                                <?php echo e(CustomHelper::early_checkOut_hour($employee_shift_times,$employee_working_hours)); ?>

                                            <?php elseif($attendance['att_check_out_time'] == '00:00:00'): ?>
                                                
                                            <?php endif; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Casual Leave' || $attendance['att_check_overall_status'] == 'Annual Leave' || $attendance['att_check_overall_status'] == 'Sick Leave' || $attendance['att_check_overall_status'] == 'Maternity Leave' || $attendance['att_check_overall_status'] == 'Paternity Leave' || $attendance['att_check_overall_status'] == 'Bereavement Leave' || $attendance['att_check_overall_status'] == 'Compensatory Leave' || $attendance['att_check_overall_status'] == 'Absent' || substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                    00:00:00
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td  class="text-center td-border"> 
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_request_approval'] == 1): ?>
                                                Attendance Request
                                            <?php endif; ?>
                                        <?php endif; ?> 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td class="text-center td-border">
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_source'] == 1): ?>
                                                Web Application
                                            <?php elseif($attendance['att_source'] == 2): ?>
                                                Mobile Application
                                                <?php elseif($attendance['att_source'] == 3): ?>
                                                Updated Attendance
                                             <?php else: ?>
                                                 Machine Attendance
                                             <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>

                            <td class="text-center td-border"> 
                                <?php if(!empty($attendances)): ?>
                                    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($attendance['att_for_date'] == $month_count): ?>
                                            <?php $absent = false; ?>
                                            <?php if($attendance['att_check_overall_status'] == 'Present'): ?>
                                                On Time
                                            <?php elseif($attendance['att_check_overall_status'] == 'Half day'): ?>
                                                Half Day
                                            <?php elseif($attendance['att_check_overall_status'] == 'Late Coming'): ?>
                                                Late Coming
                                            <?php elseif($attendance['att_check_overall_status'] == 'Casual Leave'): ?>
                                                Casual Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Annual Leave'): ?>
                                                Annual Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Sick Leave'): ?>
                                                Sick Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Maternity Leave'): ?>
                                                Maternity Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Paternity Leave'): ?>
                                                Paternity Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Bereavement Leave'): ?>
                                                Bereavement Leave
                                            <?php elseif($attendance['att_check_overall_status'] == 'Compensatory Leave'): ?>
                                                Compensatory Leave                
                                            <?php elseif($attendance['att_check_overall_status'] == 'Absent'): ?>
                                                Absent
                                            <?php elseif($attendance['att_check_overall_status'] == 'Early out'): ?>
                                                Early out
                                            <?php elseif(substr($attendance['att_check_overall_status'] , 0, 7) == 'Holiday'): ?>
                                                Holiday
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php
                                    $date_filter = strtotime(date("Y-m-d", strtotime($year . "-" . $month . "-" . $month_count )));
                                    $today = strtotime(date("Y-m-d"));
                                ?>
                                
                                <?php if($absent ): ?>
                                    
                                    <?php if( $employee[0]['employee_offday1'] == $nameOfDay || $employee[0]['employee_offday2'] == $nameOfDay ): ?>
                                        Off Day
    
                                    <?php elseif($date_filter< $today): ?>
                                       Absent
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td> 
                        </tr>
                        <?php endfor; ?>
                    </tbody>
                </table>
    
            </div>
        </div>
       
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    </body>
</html>


<?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/attendance/download-attendance-report-pdf.blade.php ENDPATH**/ ?>