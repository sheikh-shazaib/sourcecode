

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                    Employees Devices
                   
            </div>
         
        </div>
        
    </div>
   
    <div class="app-content flex-column-fluid">
        
        <div class="app-container">

            <div class="card mb-5 mb-xl-8">

                <div class="card-header border-0 pt-5">

                    <div class="card-title">
                        <div class="d-flex align-items-center position-relative my-1">
                            <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                    <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                </svg>
                            </span>
                            <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                        </div>
                    </div>
                </div> 
   
                <div class="card-body py-3">
                    
                    <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="table-responsive popup-visible ">
                            <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="system_datatable" aria-describedby="tableEmployee_info">
                            
                                <thead>
                                    <tr class="fw-bold text-muted bg-light">
                                        <th class="ps-4">Employee Name</th>
                                        <th>Device Name</th>
                                        <th>Device Token</th>
                                        <th>Device Status</th>
                                        <th>Created At</th>
                                        <th>Updated At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($all_devices)): ?>
                                        <?php $__currentLoopData = $all_devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="ps-4"><?php echo CustomHelper::getEmpProfileDiv($all_device['device_employee_id']); ?></td>
                                                <td> <?php echo e($all_device['device_name']); ?></td>
                                                <td> <?php echo e($all_device['device_token']); ?></td>
                                                <td> 
                                                    <?php if( $all_device['device_status'] == 1): ?>
                                                        <span class="badge badge-light-success font-weight-bold">Active</span>
                                                    <?php else: ?>
                                                        <span class="badge badge-light-danger font-weight-bold">De-active</span>
                                                    
                                                    <?php endif; ?>
                                                </td>
                                                <td> <?php echo e($all_device['device_created_at']); ?></td>
                                                <td> <?php echo e($all_device['device_updated_at']); ?></td>

                                                <td>

                                                    <?php if($all_device['device_status'] == 1 ): ?>
                                                        <i class="fa-regular fa-circle-check  text-success mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                    <?php else: ?>
                                                            <a href="#."  data-bs-toggle="modal" data-bs-target="#approverequest" onclick="deviceEditModel(<?php echo e($all_device['device_id']); ?>)">  <i class="fa-regular fa-circle-check  text-info mx-2" style="font-size: 20px; cursor: pointer;" data-bs-toggle="tooltip" data-bs-placement="top"  data-bs-title="Approve request" ></i>
                                                        </a>      
                                                    <?php endif; ?>

                                                    <?php if($all_device['device_status'] == 2): ?>
                                                        <i class="fa-regular fa-circle-xmark  text-danger mx-2" style="font-size: 20px; cursor: not-allowed;" disabled></i>
                                                    <?php else: ?>
                                                        <a href="#." data-bs-toggle="modal"  data-bs-target="#disapproverequest" onclick="deviceModel(<?php echo e($all_device['device_id']); ?>)"><i class="fa-regular fa-circle-xmark   text-warning mx-2" style="font-size: 20px;cursor: pointer;" data-bs-toggle="tooltip" data-bs-placement="top"  data-bs-title="Dis-Approve request"></i></a>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            
                            </table>
                        </div>
                    
                    </div>
                    
                   
                
                </div>   
            </div>
        
        </div>
    
    </div>
</div>

      

    <div class="modal fade" id="approverequest" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <div class="modal-content rounded">
                <div class="modal-header">
                    <h4 class="modal-title pl-4">Confirmation Alert</h4>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-white" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                            </svg>
                        </span>
                    </button>
                </div>

                <form id="Approve_device_request" class="form">
                 <?php echo csrf_field(); ?>
                    <div class="modal-body pt-0">

                        <p class="pt-4 fs-6">Are you sure to active this device Request ?</p>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="device_id">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="submit-btn" class="btn btn-primary">
                            <span class="indicator-label">Yes, Approve</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>   
                </form>  
            </div>
        </div>
    </div>

    

     <div class="modal fade" id="disapproverequest" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-top">
            <div class="modal-content rounded">
                <div class="modal-header">
                    <h4 class="modal-title pl-4">Confirmation Alert</h4>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-white" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="" />
                            </svg>
                        </span>
                    </button>
                </div>

                <form id="disApprove_device_request" class="form">
                 <?php echo csrf_field(); ?>
                    <div class="modal-body pt-0">

                        <p class="pt-4 fs-6">Are you sure to De-active this device Request ?</p>
                    
                    </div>
                   <div class="modal-footer">
                        <input type="hidden" name="device_id">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="update-btn" class="btn btn-primary">
                            <span class="indicator-label">Yes, Disapprove</span>
                            <span class="indicator-progress">Please wait... 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>   
                </form>  
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js-link'); ?>
<script>

    function deviceEditModel(device_id){
        $('input[name=device_id]').val(device_id)

    }

    $('#Approve_device_request').submit(function(e) { 
            $('#submit-btn').prop('disabled', true);
            $('#submit-btn').attr('data-kt-indicator', 'on');
            $('#submit-btn').css('cursor', 'not-allowed');
            e.preventDefault();  
           $.ajax({
                url: '<?php echo e(url('employee-devices/emp-approve-request')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#submit-btn').prop('disabled', false);
                        $("#submit-btn").removeAttr('data-kt-indicator');
                        $('#submit-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#submit-btn').prop('disabled', false);
                    $("#submit-btn").removeAttr('data-kt-indicator');
                    $('#submit-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						Toast.fire({
							icon: 'warning',
							title: 'Try Again. Error Code ' + errorStatus,
							timer: 3000,
						})
                    }
                }
            });
        });


        function deviceModel(device_id){
            $('input[name=device_id]').val(device_id)

        }
        $('#disApprove_device_request').submit(function(e) {
            $('#update-btn').prop('disabled', true);
            $('#update-btn').attr('data-kt-indicator', 'on');
            $('#update-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('employee-devices/emp-disapprove-request')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 3000,
                        })
                        $('#update-btn').prop('disabled', false);
                        $("#update-btn").removeAttr('data-kt-indicator');
                        $('#update-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
					$('#update-btn').prop('disabled', false);
                    $("#update-btn").removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
						Toast.fire({
							icon: 'warning',
							title: 'Internet Connection Problem',
							timer: 3000,
						})
                    } else {
						Toast.fire({
							icon: 'warning',
							title: 'Try Again. Error Code ' + errorStatus,
							timer: 3000,
						})
                    }
                }
            });
        });

</script>
<?php $__env->stopPush(); ?>        
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/employee/employee-devices.blade.php ENDPATH**/ ?>