

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
							
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container col-12 d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Interview Detail</h1>   
            </div>
            <div class="d-flex align-items-center gap-2 gap-lg-3">
             
                <div class="m-0">
                     <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
                      
                </div>
         
            </div>
           
        </div>
       
    </div>
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
      
        <div id="kt_app_content_container" class="app-container">
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-5 mb-xl-8">
                        <div class="card-body pt-5">
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview ID</span>
                                     </div>
                                    
                                    <span class="fs-6 fw-bold text-primary">
                                        <?php if(!empty($interview[0]['interview_id'])): ?>
                                            <?php echo e($interview[0]['interview_id']); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </span>
                                   
                                    
                                </div>
                                
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Date</span>
                                     </div>
                                    
                                    
                                    <span class="fs-6 fw-bold text-primary">
                                                <?php if(!empty($interview[0]['interview_date'])): ?>
                                                    <?php echo e($interview[0]['interview_date']); ?>

                                                <?php else: ?>
                                                    N/A
                                                <?php endif; ?></span>
                                   
                                    
                                </div>
                                
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                    <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Time</span>
                                    </div>
                                        
                                    <span class="fs-6 fw-bold text-primary">
                                            <?php if(!empty($interview[0]['interview_time'])): ?>
                                            <?php echo e(date('h:i A',strtotime($interview[0]['interview_time']))); ?>

                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </span>
                                   
                                    
                                </div>
                                
                            </div>
                            
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Duration Time</span>
                                     </div>
                                    
                                    
                                    <span class="fs-6 fw-bold text-primary"><?php echo e(($interview[0]['interview_duration'] )); ?> Minutes</span>
                                   
                                    
                                </div>
                                
                            </div>
                            
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                 <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Department</span>
                                     </div>
                                    
                                    
                                        <span class="fs-6 fw-bold text-primary">
                                            <?php if(!empty($interview[0]['department_name'])): ?>
                                                <?php echo e($interview[0]['department_name']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </span>
                                    
                                 </div>
                                
                            </div>
                            
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Job Title</span>
                                     </div>
                                    
                                    
                                        <span class="fs-6 fw-bold text-primary">
                                                <?php if(!empty($interview[0]['interview_jobtitle'])): ?>
                                                <?php echo e($interview[0]['interview_jobtitle']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </span>
                                   
                                    
                                </div>
                                
                            </div>
                            
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                             
                            <div class="d-flex flex-stack">
                                 <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">1st Interviewer</span>
                                     </div>
                                    
                                    
                                        <span class="fs-6 fw-bold text-primary"><?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer1']); ?></span>
                                    
                                 </div>
                                
                            </div>
                            
                            
                            <?php if(!empty($interview[0]['interview_interviewer1']) && $interview[0]['interview_interviewer1'] == session('user_session')): ?> 
                                <div class="separator separator-dashed my-4"></div>
                                
                                
                                <div class="d-flex flex-stack">
                                    <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                        
                                        <div class="flex-grow-1 me-2">
                                            <span class="text-gray-800  fs-6 fw-bold">2nd Interviewer</span>
                                        </div>
                                        
                                        
                                        <span class="fs-6 fw-bold text-primary">
                                            <?php if(!empty($interview[0]['interview_interviewer2'])): ?>
                                                <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer2']); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                            <?php if(empty($interview[0]['interview_interviewer_remarks']) && empty($interview[0]['interview_interviewer_remarks2'])): ?>
                                                &nbsp;
                                                <i class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 edit_second_interviewer" 
                                                    data-bs-toggle="modal" data-bs-target="#secondinterviewmodal"
                                                    >
                                                    <span class="svg-icon svg-icon-3">
                                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                        </svg>
                                                    </span>
                                                </i>
                                                
                                            <?php endif; ?>
                                        </span>
                                    
                                        
                                    </div>
                                    
                                </div>
                            <?php else: ?>
                                <div class="separator separator-dashed my-4"></div>
                                
                                
                                <div class="d-flex flex-stack">
                                    <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                        <div class="flex-grow-1 me-2">
                                            <span class="text-gray-800  fs-6 fw-bold">2nd Interviewer</span>
                                        </div>
                                        <span class="fs-6 fw-bold text-primary">
                                            <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer2']); ?>

                                        </span>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Interview Round</span>
                                    </div>
                                <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_round']); ?></span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                     <div class="flex-grow-1 me-2">
                                         <span class="text-gray-800  fs-6 fw-bold">Interview Room No</span>
                                     </div>
                                    <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_room_nbr']); ?></span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Candidate Name</span>
                                    </div>
                                    <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['candidate_name']); ?></span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Candidate CV</span>
                                    </div>
                                    <a href="<?php echo e(url('download-candidate-cv?path=interviews/'.$interview[0]['interview_candidate_cv'])); ?>&title=Download Candidate CV" target="_blank" class="btn btn-success">Download File</a>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Current Salary</span>
                                    </div>
                                    <span class="fs-6 fw-bold text-primary"> <?php echo e($interview[0]['interview_current_salary']); ?> </span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Expected Salary</span>
                                    </div>
                                    <span class="fs-6 fw-bold text-primary"> <?php echo e($interview[0]['interview_expected_salary']); ?></span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                             
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Notice Period</span>
                                    </div>
                                    <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_noticepriod']); ?></span>
                                </div>
                            </div>
                            
                            <div class="separator separator-dashed my-4"></div>
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Created At</span>
                                    </div>
                                    <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_scheduled_time']); ?></span>
                                </div>
                            </div>

                            <div class="separator separator-dashed my-4"></div>
                            
                            
                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Interview Status</span>
                                    </div>
                                
                                
                                <span class="fs-6 fw-bold text-primary">N\A</span>
                                
                                
                                </div>
                            
                            </div>

                            <div class="separator separator-dashed my-4"></div>

                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Interview Type</span>
                                    </div>
                                
                                
                                    <span class="fs-6 fw-bold text-primary"><?php echo e($interview[0]['interview_type']); ?></span>
                                
                                
                                </div>
                        
                            </div>

                            <div class="separator separator-dashed my-4"></div>

                            <div class="d-flex flex-stack">
                                <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                
                                    <div class="flex-grow-1 me-2">
                                        <span class="text-gray-800  fs-6 fw-bold">Interview Link</span>
                                    </div>

                                    <div class="ms-2">
                                        <button type="button" class="btn btn-sm btn-icon btn-light btn-active-light-primary" data-kt-menu-trigger="click" data-kt-menu-placement="bottom-end">
                                            
                                            <span class="svg-icon svg-icon-5 m-0"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path opacity="0.3" d="M18.4 5.59998C18.7766 5.9772 18.9881 6.48846 18.9881 7.02148C18.9881 7.55451 18.7766 8.06577 18.4 8.44299L14.843 12C14.466 12.377 13.9547 12.5887 13.4215 12.5887C12.8883 12.5887 12.377 12.377 12 12C11.623 11.623 11.4112 11.1117 11.4112 10.5785C11.4112 10.0453 11.623 9.53399 12 9.15698L15.553 5.604C15.9302 5.22741 16.4415 5.01587 16.9745 5.01587C17.5075 5.01587 18.0188 5.22741 18.396 5.604L18.4 5.59998ZM20.528 3.47205C20.0614 3.00535 19.5074 2.63503 18.8977 2.38245C18.288 2.12987 17.6344 1.99988 16.9745 1.99988C16.3145 1.99988 15.661 2.12987 15.0513 2.38245C14.4416 2.63503 13.8876 3.00535 13.421 3.47205L9.86801 7.02502C9.40136 7.49168 9.03118 8.04568 8.77863 8.6554C8.52608 9.26511 8.39609 9.91855 8.39609 10.5785C8.39609 11.2384 8.52608 11.8919 8.77863 12.5016C9.03118 13.1113 9.40136 13.6653 9.86801 14.132C10.3347 14.5986 10.8886 14.9688 11.4984 15.2213C12.1081 15.4739 12.7616 15.6039 13.4215 15.6039C14.0815 15.6039 14.7349 15.4739 15.3446 15.2213C15.9543 14.9688 16.5084 14.5986 16.975 14.132L20.528 10.579C20.9947 10.1124 21.3649 9.55844 21.6175 8.94873C21.8701 8.33902 22.0001 7.68547 22.0001 7.02551C22.0001 6.36555 21.8701 5.71201 21.6175 5.10229C21.3649 4.49258 20.9947 3.93867 20.528 3.47205Z" fill="currentColor"></path>
                                                <path d="M14.132 9.86804C13.6421 9.37931 13.0561 8.99749 12.411 8.74695L12 9.15698C11.6234 9.53421 11.4119 10.0455 11.4119 10.5785C11.4119 11.1115 11.6234 11.6228 12 12C12.3766 12.3772 12.5881 12.8885 12.5881 13.4215C12.5881 13.9545 12.3766 14.4658 12 14.843L8.44699 18.396C8.06999 18.773 7.55868 18.9849 7.02551 18.9849C6.49235 18.9849 5.98101 18.773 5.604 18.396C5.227 18.019 5.0152 17.5077 5.0152 16.9745C5.0152 16.4413 5.227 15.93 5.604 15.553L8.74701 12.411C8.28705 11.233 8.28705 9.92498 8.74701 8.74695C8.10159 8.99737 7.5152 9.37919 7.02499 9.86804L3.47198 13.421C2.52954 14.3635 2.00009 15.6417 2.00009 16.9745C2.00009 18.3073 2.52957 19.5855 3.47202 20.528C4.41446 21.4704 5.69269 21.9999 7.02551 21.9999C8.35833 21.9999 9.63656 21.4704 10.579 20.528L14.132 16.975C14.5987 16.5084 14.9689 15.9544 15.2215 15.3447C15.4741 14.735 15.6041 14.0815 15.6041 13.4215C15.6041 12.7615 15.4741 12.108 15.2215 11.4983C14.9689 10.8886 14.5987 10.3347 14.132 9.86804Z" fill="currentColor"></path>
                                                </svg>
        
                                            </span>
                                        </button>
                                                    
                                        
                                        <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-600 menu-state-bg-light-primary fw-semibold fs-7 w-300px" data-kt-menu="true" style="">
                                            
                                            <div class="card card-flush">
                                                <div class="card-body p-5">
                                                    
                                                        <div class="d-flex flex-column text-start">
                                                            <div class="d-flex mb-3">
                                                                    
                                                                <span class="svg-icon svg-icon-2 svg-icon-success me-3"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path d="M9.89557 13.4982L7.79487 11.2651C7.26967 10.7068 6.38251 10.7068 5.85731 11.2651C5.37559 11.7772 5.37559 12.5757 5.85731 13.0878L9.74989 17.2257C10.1448 17.6455 10.8118 17.6455 11.2066 17.2257L18.1427 9.85252C18.6244 9.34044 18.6244 8.54191 18.1427 8.02984C17.6175 7.47154 16.7303 7.47154 16.2051 8.02984L11.061 13.4982C10.7451 13.834 10.2115 13.834 9.89557 13.4982Z" fill="currentColor"></path>
                                                                    </svg>
                                                                </span>
                                                                        
                                                                <div class="fs-6 text-dark">Share Link Generated</div>           
                                                            </div>  

                                                            <div class="row">
                                                            
                                                                <div class="col-md-10">
                                                                    <input type="text" id="url"  class="form-control form-control-sm" value="<?php echo e($interview[0]['interview_link'] ?? 'N\A'); ?>" />
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <button  class="btn btn-active-color-primary btn-icon btn-sm btn-outline-light" onclick="Copy();">
                                                                        
                                                                        <span class="svg-icon svg-icon-2"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                            <path opacity="0.5" d="M18 2H9C7.34315 2 6 3.34315 6 5H8C8 4.44772 8.44772 4 9 4H18C18.5523 4 19 4.44772 19 5V16C19 16.5523 18.5523 17 18 17V19C19.6569 19 21 17.6569 21 16V5C21 3.34315 19.6569 2 18 2Z" fill="currentColor"></path>
                                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M14.7857 7.125H6.21429C5.62255 7.125 5.14286 7.6007 5.14286 8.1875V18.8125C5.14286 19.3993 5.62255 19.875 6.21429 19.875H14.7857C15.3774 19.875 15.8571 19.3993 15.8571 18.8125V8.1875C15.8571 7.6007 15.3774 7.125 14.7857 7.125ZM6.21429 5C4.43908 5 3 6.42709 3 8.1875V18.8125C3 20.5729 4.43909 22 6.21429 22H14.7857C16.5609 22 18 20.5729 18 18.8125V8.1875C18 6.42709 16.5609 5 14.7857 5H6.21429Z" fill="currentColor"></path>
                                                                            </svg>
                                                                        </span>
                                                                        
                                                                    </button>
                                                                </div> 
                                                            </div> 
                                                            
                                                            <div class="text-muted fw-normal mt-2 fs-8 px-2">Copy Link.</div> 
                                                            
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                
                                        </div>
                                    </div>                                            
                    
                                </div>
                        
                            </div>

                            <div class="separator separator-dashed my-4"></div>

                            <div class="d-flex flex-stack  mt-10">
                                    <div class="d-flex align-items-center flex-row-fluid flex-wrap">
                                    
                                        <div class="flex-grow-1 me-2">
                                            <span class="text-gray-800  fs-6 fw-bold">Scheduled By</span>
                                        </div>
                                    
                                    
                                        <span class="fs-6 fw-bold text-primary">
                                        <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_created_by']); ?>

                                        </span>
                                    
                                    
                                    </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-flush mb-10">
                        <div class="card-body">
                            <div class="row g-9 mb-2">
                                <div class="col-md-12 fv-row">
                                    <label class="fw-bold">Additional Remarks By HR</label>
                                    <p class="pt-5">
                                        <?php if(!empty($interview[0]['interview_additional_remarks']) && $interview[0]['interview_additional_remarks'] != ''): ?> <?php echo e($interview[0]['interview_additional_remarks']); ?>

                                        <?php else: ?>
                                            No Remarks By HR.
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                    <?php if($interview[0]['interview_interviewer1'] == session('user_session') && $interview[0]['interview_interviewer_remarks'] == ''): ?>
                        <form id="submit_my_remarks">
                            <div class="card mb-5 mb-xxl-8">
                                
                                <div class="card-body pb-0">
                                    
                                    <div class="d-flex align-items-center mb-5">
                                        
                                        <div class="d-flex align-items-center flex-grow-1">
                                            
                                            <div class="d-flex flex-column">
                                                <a href="#" class="text-gray-900 text-hover-primary fs-6 fw-bold">Your Remarks</a>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                    
                                    <div class="mb-5">
                                        
                                        <div class="text-gray-800 fw-normal mb-5">
                                            <input type="hidden" class="form-control" name="interview_id" required="" value="<?php echo e($interview[0]['interview_id']); ?>">
                                            <textarea class="form-control bg-transparent border-0 px-0" name="my_remarks"  rows="1" placeholder="Type your message..."></textarea>
                                        </div>
                                        
                                    </div>
                                        <div class="separator mb-5"></div>
                                    
                                        <div class="my-4 text-center">
                                            <button type="submit" class="btn btn-primary" id="update-remarks-btn">Submit Remarks</button>
                                    </div>
                                </div>
                                
                            </div>
                        </form>

                      
                    <?php endif; ?>

                    <?php if($interview[0]['interview_interviewer2'] == session('user_session') && $interview[0]['interview_interviewer_remarks2'] == ''): ?>
                        <form id="submit_my_remarks2">
                            <div class="card mb-5 mb-xxl-8">
                                
                                <div class="card-body pb-0">
                                    
                                    <div class="d-flex align-items-center mb-5">
                                        
                                        <div class="d-flex align-items-center flex-grow-1">
                                            
                                            <div class="d-flex flex-column">
                                                <a href="#" class="text-gray-900 text-hover-primary fs-6 fw-bold">Your Remarks as a 2nd Interviewer</a>
                                            </div>
                                            
                                        </div>
                                        
                                    </div>
                                    
                                    
                                    <div class="mb-5">
                                        
                                        <div class="text-gray-800 fw-normal mb-5">
                                            <input type="hidden" class="form-control" name="interview_id" required="" value="<?php echo e($interview[0]['interview_id']); ?>">
                                            <textarea class="form-control bg-transparent border-0 px-0" name="my_remarks"  rows="1" placeholder="Type your message..."></textarea>
                                        </div>
                                        
                                    </div>
                                        <div class="separator mb-5"></div>
                                    
                                        <div class="my-4 text-center">
                                            <button type="submit" class="btn btn-primary" id="update-remarks-btn">Submit Remarks</button>
                                    </div>
                                </div>        
                            </div>  
                                
                        </form>    
                    <?php endif; ?>
                
                    <?php if(!empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] != ''): ?>
                        <div class="card card-flush mb-10">
                            <div class="card-body">
                                <div class="row g-9 mb-2">
                                    <div class="col-md-12 fv-row">
                                        <label class="fw-bold">Remarks by 1st interviewer ( <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer1']); ?> )</label>
                                        <p class="pt-5">
                                            <?php if(!empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] != ''): ?>
                                                <?php echo e($interview[0]['interview_interviewer_remarks']); ?>

                                            <?php else: ?>
                                                No Remarks By 1st Interviewer.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(!empty($interview[0]['interview_interviewer_remarks2']) && $interview[0]['interview_interviewer_remarks2'] != ''): ?>
                        <div class="card card-flush mb-10">
                            <div class="card-body">
                                <div class="row g-9 mb-2">
                                    <div class="col-md-12 fv-row">
                                        <label class="fw-bold">Remarks by 2nd interviewer ( <?php echo CustomHelper::getEmpProfileDiv($interview[0]['interview_interviewer2']); ?> )</label>
                                        <p class="pt-5">
                                            <?php if(!empty($interview[0]['interview_interviewer_remarks2']) && $interview[0]['interview_interviewer_remarks2'] != ''): ?>
                                                <?php echo e($interview[0]['interview_interviewer_remarks2']); ?>

                                            <?php else: ?>
                                                No Remarks By 2nd Interviewer.
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="flex-lg-row-fluid card card-flush mb-10">
                        
                        <div class="card direct-chat direct-chat-primary">
                                        
                            <div class="card-header" id="kt_chat_messenger_header">
                                
                                <div class="card-title">
                                    
                                    <div class="d-flex justify-content-center flex-column me-3">
                                        <p class="fs-4 fw-bold text-gray-900 me-1 mb-2 lh-1">Interview Chat</p>
                                        
                                    </div>
                                    
                                </div>
                                
                                
                            </div>
                            
                            
                            <div class="card-body" id="kt_chat_messenger_body">
                                
                                <div class="scroll-y me-n5 pe-5 h-300px h-lg-auto " data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-max-height="auto" data-kt-scroll-dependencies="#kt_header, #kt_app_header, #kt_app_toolbar, #kt_toolbar, #kt_footer, #kt_app_footer, #kt_chat_messenger_header, #kt_chat_messenger_footer" data-kt-scroll-wrappers="#kt_content, #kt_app_content, #kt_chat_messenger_body" data-kt-scroll-offset="5px" style="max-height: 151px;" id="interview-chat-message">
                                    <!--begin::Message(in)-->
                                    <div class="direct-chat-messages">

                                    </div>
                        
                                </div>  
                            </div>
                            
                                    
                            <div class="card-footer pt-4" >
                                <form id="sendChatMessage">
                                    

                                    
                                    <input type="hidden" name="interview_id" value="<?php echo e(Request::segment(2)); ?>">
                                    <input type="hidden" name="interviewer1" value="<?php echo e($interview[0]['interview_interviewer1']); ?>" />
                                    <input type="hidden" name="interviewer2" value="<?php echo e($interview[0]['interview_interviewer2']); ?>" />
                                    <div class="input-group">
                                        
                                        <textarea class="form-control form-control-flush mb-3" id="messageInputBox"  name="message" rows="1" data-kt-element="input" placeholder="Type a message"></textarea>
                                        
                                        
                                        <div class="d-flex flex-stack">
                                            <button type="submit" id="sendMessageBtn"class="btn btn-primary">
                                                <span class="indicator-label">Submit</span>
                                                <span class="indicator-progress">Please wait... 
                                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                            </button>
                                            
                                            
                                        </div>
                                    </div>  
                                    
                                </form>    
                            </div>
                                    
                        </div>
                        
                    </div>

                </div>
            </div>
           
            <div class="modal fade" id="secondinterviewmodal" tabindex="-1" aria-hidden="true">
                    
                    <div class="modal-dialog modal-dialog-top mw-750px">
                        
                        <div class="modal-content rounded">
                            
                            <div class="modal-content rounded">
                                
                                <div class="modal-header">
                                <h4 class="modal-title pl-4">Edit 2nd Interviewer</h4>
                                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                                    <span class="svg-icon svg-icon-1">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                        </svg>
                                    </span>
                                </button>
                                </div>
                            
                            
                            <div class="modal-body scroll-y pt-0 pb-15">
                                
                                <form id="secondinterviewform">
                                    <?php echo csrf_field(); ?>
                                    
                                    <div class="row g-9 mt-1" >
                                        
                                        <div class="col-md-6 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span class="required">Selected Interviewer Name</span>
                                            </label>
                                        
                                            
                                            <div class="d-flex align-items-center">
                                                
                                                
                                                   
                                                <input type="hidden" class="form-control  ps-12" name="interview_id"
                                                value="<?php echo e($interview[0]['interview_id']); ?>" readonly="">
                                                <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interviewer_2" required disabled>
                                                        <option value="">Select Interviwer</option>
                                                        <?php if(!empty($employees)): ?>
                                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($employee['employee_id']); ?>"
                                                                    <?php if(!empty($interview[0]['interview_interviewer2']) && $interview[0]['interview_interviewer2'] == $employee['employee_id']): ?> selected <?php endif; ?>>
                                                                    <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                </select>
                                                
                                            </div>
                                            
                                        </div>

                                        <div class="col-md-6 fv-row">
                                            <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                                <span class="required">New Interviewer </span>
                                            </label>
                                        
                                            
                                            <div class="d-flex align-items-center">
                                               <select class="form-select mySelect3" data-control="select2" data-hide-search="true" name="interviewer_2" id="depart_name" required="">
                                                    <option value="">Select New Interviewer</option>
                                                    <?php if(!empty($employees)): ?>
                                                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($employee['employee_id']); ?>">
                                                                <?php echo e($employee['employee_code'] . ' - ' . $employee['employee_name']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>        
                                            </div>
                                            
                                        </div>
                                    </div>

                                    <div class="text-center mt-5">
                                        
                                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" id="update-btn" class="btn btn-primary">
                                            <span class="indicator-label">Update</span>
                                            <span class="indicator-progress">Please wait 
                                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                        </button>
                                    </div>
                                    
                                </form>
                                
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
            </div>

            

           
        </div>
    
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    var interview_id = '<?php echo e(Request::segment(2)); ?>';
 
 </script>
 <script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-app.js"></script>
 <script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-database.js"></script>
 <script src="<?php echo e(url('/')); ?>/assets/js/firebase-interview-chat.js"></script>
<script>
     $(function(){

        $('.mySelect3').select2({
            "enable": false,
            dropdownParent: $('#secondinterviewmodal')
        })
	});

    <?php if(empty($interview[0]['interview_interviewer_remarks2'])): ?>
        
        $('.edit_second_interviewer').click(function() {
            var interviewer_name = $(this).data('interviewer_name');
            $('#interviewer_name').val(interviewer_name);
        });

        $('#secondinterviewform').submit(function(e) {
            $('#update-btn').prop('disabled', true);
            $('#update-btn').attr('data-kt-indicator', 'on');
            $('#update-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('assign_second_interviewer')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 5000,
                        })
                        $('#update-btn').prop('disabled', false);
                        $('#update-btn').removeAttr('data-kt-indicator');
                        $('#update-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
                    $('#update-btn').prop('disabled', false);
                    $('#update-btn').removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Internet Connection Problem',
                            timer: 3000,
                        })
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            });
        });
    
    <?php endif; ?>
    
    <?php if(empty($interview[0]['interview_interviewer_remarks']) && $interview[0]['interview_interviewer_remarks'] == ''): ?>
    
        $('#submit_my_remarks').submit(function(e) {
            $('#update-remarks-btn').prop('disabled', true);
            $('#update-remarks-btn').attr('data-kt-indicator', 'on');
            $('#update-remarks-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('submit_interviewer_remarks')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 5000,
                        })
                        $('#update-remarks-btn').prop('disabled', false);
                        $('#update-remarks-btn').removeAttr('data-kt-indicator');
                        $('#update-remarks-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
                    $('#update-remarks-btn').prop('disabled', false);
                    $('#update-remarks-btn').removeAttr('data-kt-indicator');
                    $('#update-remarks-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Internet Connection Problem',
                            timer: 3000,
                        })
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            });
        });
    
    <?php endif; ?>
    
    <?php if(empty($interview[0]['interview_interviewer_remarks2']) && $interview[0]['interview_interviewer_remarks2'] == ''): ?>
    
        $('#submit_my_remarks2').submit(function(e) {
            $('#update-remarks-btn').prop('disabled', true);
            $('#update-remarks-btn').attr('data-kt-indicator', 'on');
            $('#update-remarks-btn').css('cursor', 'not-allowed');
            e.preventDefault();
            $.ajax({
                url: '<?php echo e(url('submit_second_interviewer_remarks')); ?>',
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData: false,
                success: function(data) {
                    if (data.status == 'TRUE') {
                        Toast.fire({
                            icon: 'success',
                            title: data.msg,
                            timer: 3000,
                        })
                        setTimeout(() => {
                            location.reload();
                        }, 3000);
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: data.msg,
                            timer: 5000,
                        })
                        $('#update-remarks-btn').prop('disabled', false);
                        $('#update-remarks-btn').removeAttr('data-kt-indicator');
                        $('#update-remarks-btn').css('cursor', 'pointer');
                    }
                },
                error: function(jqXHR, textStatus) {
                    var errorStatus = jqXHR.status;
                    $('#update-remarks-btn').prop('disabled', false);
                    $('#update-remarks-btn').removeAttr('data-kt-indicator');
                    $('#update-remarks-btn').css('cursor', 'pointer');
                    if (errorStatus == 0) {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Internet Connection Problem',
                            timer: 3000,
                        })
                    } else {
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            });
        });
        
    <?php endif; ?>	

    function Copy(Url) {
    var Url = document.getElementById("url");
    Url.select();
    document.execCommand("copy");
    }
</script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/interview/my-interview-detail.blade.php ENDPATH**/ ?>