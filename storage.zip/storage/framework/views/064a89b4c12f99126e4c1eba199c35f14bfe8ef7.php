



<?php $__env->startPush('css-link'); ?>
table.dataTable
{
 overflow-x:hidden !important;
 overflow-y:auto !important;
}
<?php $__env->stopPush(); ?>



<?php $__env->startSection('main-section'); ?>

<div class="d-flex flex-column flex-column-fluid">
    <form id="overtime-insert-form">	
        <?php echo csrf_field(); ?> 				 
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
            <div class="app-container col-12 d-flex flex-stack">
                
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    
                    <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">
                        <?php if(empty($month) && empty($year)): ?>
                            OverTime Management Detail (<?php echo e(date('F') . '-' . date('Y')); ?>)
                        <?php else: ?>
                            OverTime Management Detail (<?php echo e(date("F", mktime(0, 0, 0, $month, 10))); ?>-<?php echo e($year); ?>)
                        <?php endif; ?>
                        
                    </h1>  
                   
                </div>
                <div class="d-flex align-items-center gap-2 gap-lg-3">
                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary"  >Go Back</a>
                </div>
            </div>
        </div>

        
        <div class="app-content flex-column-fluid">
            
            <div class="app-container">
                
                <div class="card mb-5 mb-xl-8">
                    <div class="card-header border-0 pt-5">

                        <div class="card-title">
                            <div class="d-flex align-items-center position-relative my-1 me-5">
                                <span class="svg-icon svg-icon-1 position-absolute ms-6">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <rect opacity="0.5" x="17.0365" y="15.1223" width="8.15546" height="2" rx="1" transform="rotate(45 17.0365 15.1223)" fill="currentColor"></rect>
                                        <path d="M11 19C6.55556 19 3 15.4444 3 11C3 6.55556 6.55556 3 11 3C15.4444 3 19 6.55556 19 11C19 15.4444 15.4444 19 11 19ZM11 5C7.53333 5 5 7.53333 5 11C5 14.4667 7.53333 17 11 17C14.4667 17 17 14.4667 17 11C17 7.53333 14.4667 5 11 5Z" fill="currentColor"></path>
                                    </svg>
                                </span>
                                <input type="text" class="form-control  w-250px ps-15" placeholder="Search Record ..." id="searchFilter">
                            </div>
                            <div class="d-flex align-items-center  on-check d-none">
                        
                                <?php if($login_user[0]['employee_department'] == 2 || $login_user[0]['employee_department'] == 1): ?>
    
                                    <i class="fa-regular fa-circle-check overtime_reibursment text-success mx-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Approve Reimburesement" style="font-size: 20px"></i> 
                                
                                    <i class="fa-regular fa-circle-xmark overtime_reibursment text-danger mx-2" data-value="Multiple-Remove" style="font-size: 20px;cursor: pointer;"  data-bs-toggle="tooltip" data-bs-placement="top" title="Remove Reimburesement"></i>

                                    <input type="hidden" name="title" id="title" />
                                   
                                <?php endif; ?>
                            </div>
                            
                        </div>
                    </div>
                    <div class="card-body py-3">				 
                        <div id="tableEmployee_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="table-responsive">
                            
                                <table class="table align-middle gs-0 gy-4 dataTable no-footer table-row-bordered" id="tableEmployeeOverTime" aria-describedby="tableEmployee_info">
                                                                                                                
                                    <thead>
                                        <tr class="fw-bold text-muted bg-light">
                                            <th class="ps-6"> 
                                                <div class="form-check form-check-sm form-check-custom">
                                                    <input class="form-check-input"  type="checkbox" id="parent_checkbox" />
                                                </div>     
                                            </th>
                                            <th >Employee Name</th>
                                            <th >Daily Shift Timing</th>
                                            <th>Check In Time</th>
                                            <th>Check Out Time</th>
                                            <th>Daily Extra Hours Worked</th>
                                            <th>Overtime Date</th>
                                            <th>Overtime Salary</th>
                                            <th>Amount Payable</th>
                                            <th>Reimburesement Status</th>
                                            <th>Action</th>
                                        
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                        <?php if(!empty($all_attendaces)): ?>
                                            <?php $overtime = 0; 
                                                $overtime_salary = 0;
                                                $count = 0;
                                                $amount_payable = 0;
                                            ?>
                                            <?php $__currentLoopData = $all_attendaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!empty($all_attendance['attendance'])): ?>
                                                    <?php $__currentLoopData = $all_attendance['attendance']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$atty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php 
                                                            
                                                            $employee_shift_times =  CustomHelper::calculate_shift_timings($atty['att_shift_start_time'],$atty['att_shift_end_time']);
                                                            $employee_working_hours =  CustomHelper::calculate_shift_timings($atty['att_check_in_time'],$atty['att_check_out_time']);
                                                        
                                                        ?>
                                                        <?php if($employee_working_hours > $employee_shift_times): ?>
                                                          
                                                            <?php
                                                               
                                                                $ovt_date = $atty['att_for_year'].'-'.$atty['att_for_month'].'-'.$atty['att_for_date'];
                                                                $extra_hours =  CustomHelper::extra_hours_working($employee_shift_times,$employee_working_hours);
                                                                $components = explode(":",$extra_hours);
                                                                $seconds = $components[0]*60*60 + $components[1]*60;
                                                                $overtime +=$seconds;
                                                                $salary_overtime = round(CustomHelper::calculate_total_overtime_salary($all_attendance['employee_id'],$ovt_date,$employee_shift_times, $extra_hours));
                                                                $overtime_salary+=$salary_overtime;
                                                                
                                                             
                                                            ?>
                                                           
                                                            <tr>
                                                                <td class="ps-6">
                                                                    <div class="form-check form-check-sm form-check-custom">
                                                                        <input class="form-check-input checked"  type="checkbox" name="checkbox_<?php echo e($count); ?>"  />
                                                                    </div>     
                                                                </td>
                                                                <td ><?php echo CustomHelper::getEmpProfileDiv($all_attendance['employee_id']); ?></td>
                                                                <td class="ps-6">  <?php echo e($employee_shift_times); ?></td>
                                                                <td class="ps-6">  <?php echo e($atty['att_check_in_time']); ?></td>
                                                                <td class="ps-6">  <?php echo e($atty['att_check_out_time']); ?></td>
                                                                <td class="text-center">  <?php echo e($extra_hours); ?></td>
                                                                <td class="ps-6">  <?php echo e(date('d-F-Y', strtotime($atty['att_for_year'].'-'.$atty['att_for_month'].'-'.$atty['att_for_date'] ))); ?></td>
                                                                <td class="ps-6">  RS : <?php echo e($salary_overtime); ?></td>
                                                                <td class="ps-6"> 
                                                                     <?php if(in_array($ovt_date,$checking_exits_record)): ?> 
                                                                        <?php if(!empty($overtime_record[$ovt_date]['amount_payable'])): ?>
                                                                            <?php  $amount_payable += $overtime_record[$ovt_date]['amount_payable'];?>
                                                                            RS : <?php echo e($overtime_record[$ovt_date]['amount_payable']); ?>

                                                                        <?php endif; ?>
                                                                    
                                                                     <?php endif; ?>
                                                                </td>
                                                                <td class="text-center"> 
                                                                    <?php if(in_array($ovt_date,$checking_exits_record)): ?> 
                                                                    
                                                                        <?php if($overtime_record[$ovt_date]['over_time_reibursement_status'] == 1): ?>
                                                                            <span class="badge badge-light-success text-center font-weight-bold" >Paid</span>
                                                                      
                                                                        <?php else: ?>
                                                                            <span class="badge badge-light-danger text-center font-weight-bold" >Not Paid</span>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-light-danger text-center font-weight-bold" >Not Paid</span>
                                                                  
                                                                    <?php endif; ?>
                                                               </td>
                                                                <td>  
                                                                    <input type="hidden" name="employee_id[]" value="<?php echo e($all_attendance['employee_id']); ?>" required/>
                                                                    <input type="hidden" name="extra_hours[]" value="<?php echo e($extra_hours); ?>" required/>
                                                                    <input type="hidden" name="over_time_date[]" value="<?php echo e($ovt_date); ?>" required/>
                                                                    <input type="hidden" name="salary_amount[]" value="<?php echo e($salary_overtime); ?>" required />
                                                                   
                                                                    <?php if(in_array($ovt_date,$checking_exits_record) && $overtime_record[$ovt_date]['over_time_reibursement_status'] == 1): ?>
                                                                        
                                                                        <i class="fa-regular fa-circle-check   text-success mx-2"  data-bs-toggle="tooltip" data-bs-placement="top" title="Reimburesement Overtime"  disabled style="font-size: 20px;cursor: not-allowed;"></i>
                                                                        
                                                                        <?php if(!empty($overtime_record[$ovt_date]['ovt_payroll_id'])): ?>
                                                                            <i class="fa-regular fa-circle-xmark  text-danger mx-2" disabled style="font-size: 20px;cursor:not-allowed" ></i>
                                                                        <?php else: ?>
                                                                            <a href="javascript:void(0);" onclick="remove_overtime_salary('<?php echo e($all_attendance['employee_id']); ?>','<?php echo e($ovt_date); ?>')"   data-bs-toggle="tooltip" data-bs-placement="top" title="Remove Reimburesement">
                                                                                <i class="fa-regular fa-circle-xmark  text-danger mx-2"  style="font-size: 20px;cursor: pointer;"></i>
                                                                            </a>
                                                                        <?php endif; ?>
                                                                       
                                                                       

                                                                        <a href="javascript:void(0);" class="btn-sm me-1" disabled style="font-size: 20px;cursor:not-allowed" >
                                                                            <span class="svg-icon svg-icon-3">
                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                                                </svg>
                                                                            </span>
                                                                        </a>
                                                                       
                                                                    <?php else: ?> 
                                                                      
                                                                        <i class="fa-regular fa-circle-check  text-success mx-2"  data-bs-toggle="tooltip" data-bs-placement="top" title="Reimburesement Overtime" style="font-size: 20px;cursor: pointer;" onclick="overtime(<?php echo e($all_attendance['employee_id']); ?>,'<?php echo e($extra_hours); ?>','<?php echo e($ovt_date); ?>','<?php echo e($salary_overtime); ?>')"></i>
                                                                        
                                                                        <i class="fa-regular fa-circle-xmark  text-danger mx-2" disabled style="font-size: 20px;cursor:not-allowed" ></i>
                                                                            
                                                                        <a href="javascript:void(0);" class="btn-sm me-1 edit_btn" data-bs-toggle="tooltip" title="Edit Overtime Salary" data-salary="<?php echo e($salary_overtime); ?>" data-id="<?php echo e($all_attendance['employee_id']); ?>" data-date="<?php echo e($ovt_date); ?>" data-extra-hours="<?php echo e($extra_hours); ?>" data-amount-payable="<?php echo e($overtime_record[$ovt_date]['amount_payable']?? ''); ?>" >
                                                                            <span class="svg-icon svg-icon-3">
                                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                                                                    <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                                                                </svg>
                                                                            </span>
                                                                        </a>
                                                                      
                                                                    <?php endif; ?>                                                                 
                                                                </td> 
                                                            </tr>
                                                            <?php $count++; ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="bg-light">
                                                <td class="ps-6"></td>
                                                <td class="ps-6">
                                                <td class="ps-6">
                                                <td class="ps-6">
                                                <td class="ps-6">
                                                <td class="text-center">   
                                                    <?php $overtimes = CustomHelper::calculate_total_overtime($overtime); ?>
                                                        <?php echo e($overtimes['overtime']); ?>

                                                </td>
                                                <td class="text-center"></td>
                                                <td class="ps-6">   
                                                    <b> RS:</b> <?php echo e($overtime_salary); ?>

                                                </td>
                                                <td class="ps-6"> <b> RS:</b> <?php echo e($amount_payable); ?></td>  
                                                <td class="ps-6"> </td>
                                                <td class="ps-6">  </td>
                                                <td class="ps-6"> </td>
                                
                                            </tr>
                                        
                                        <?php endif; ?>
                                    
                                    </tbody>
                                
                                </table>
                            </div>
                        </div>  
                    </div>
                </div>
            </div> 
        </div>
    </form>
    <div class="modal fade" tabindex="-1" id="modal-danger">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">Confirmation Alert</h3>
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-1 bg-white">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                </div>
                <form id="removeReimburesement" class="form" >
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                    <input type="hidden" class="form-control" name="employee_id" id="emp_id" required=""/>
                    <input type="hidden" class="form-control" name="ovt_date" id="date" required=""/>
                        <p>Are you sure to delete this Reimburesement ?</p>
                    </div>
        
                    <div class="modal-footer">
                    <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="delete-btn" class="btn btn-primary">
                                <span class="indicator-label">Remove</span>
                                <span class="indicator-progress">Please wait 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                    </div>
                </form>    
            </div>
        </div>
    </div>

    
    <form id="edit_overtime_salary" class="form">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="edit-overtime-salary" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
                <div class="modal-content rounded">
                    
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Edit OverTime Salary</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                        </button>
                    </div>
                
                    <div class="modal-body scroll-y pt-3 pb-5">
                        
                        <div class="col-md-12 mb-8 mt-3 fv-row">
                            <label class="required fs-6 fw-semibold mb-2">Amount Payable </label>
                            <div class="position-relative d-flex align-items-center"> 
                                <input type="number" class="form-control " placeholder="Enter a Amount Payable" name="amount_payable"  id="amount_payable" required="" min="0" max="99999999.99"/>
                                <input type="hidden" class="form-control" name="employee_id" id="employee_id" required=""/>
                                <input type="hidden" class="form-control" name="ovt_date" id="ovt_date" required=""/>
                                <input type="hidden" name="extra_hours" id="extra_hours" required />
                                <input type="hidden" name="salary_amount" id="salary_amount" required/>
                               
                               
                            </div>
                        </div>
                            
                    </div>
                    <div class="modal-footer justify-content-center">
                        <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                        <button type="submit" id="update-btn" class="btn btn-primary">
                            <span class="indicator-label">Submit</span>
                            <span class="indicator-progress">Please wait 
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    
    
    $(function(){
        
        dataTable = $('#tableEmployeeOverTime').DataTable({
            // order: false,
            "ordering": false,
            aLengthMenu: [
                [10, 25, 50, 100, 500, -1],
                [10, 25, 50, 100, 500, "All"]
            ],
            iDisplayLength: 500,
        });
	});
   
    function overtime(emp_id,extra_hour,date,salary_amount){
       
        $('.submit_btn').prop('disabled', true);
        $(".submit_btn").attr('data-kt-indicator', 'on');
        $('.submit_btn').css('cursor', 'not-allowed');
        
            swal.fire({
                title: 'Confirmation Alert !',
                text: 'Are you sure to submit Overtime ?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText:'Yes',
                cancelButtonText:'Cancel',
            }).then(function (value) { 
        
            if (value.isConfirmed == true) {
                $.ajax({
                    url: '<?php echo e(url('overtime-management/overtime-record-insert')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {employee_id:emp_id,extra_hour:extra_hour,date:date,salary_amount:salary_amount},
                    success: function(data) {
                       
                        if (data.status == 'TRUE') {
                            Toast.fire({
                                icon: 'success',
                                title: data.msg,
                                timer: 3000,
                            })
                            setTimeout(() => {
                                location.reload();
                            }, 3000);
                        } else {
                            Toast.fire({
                                icon: 'warning',
                                title: data.msg,
                                timer: 5000,
                            })
                            $('.submit_btn').prop('disabled', false);
                            $(".submit_btn").removeAttr('data-kt-indicator');
                            $('.submit_btn').css('cursor', 'pointer');
                        }
                    },
                    error: function(jqXHR, textStatus) {
                        var errorStatus = jqXHR.status;
                        $('.submit_btn').prop('disabled', false);
                        $(".submit_btn").removeAttr('data-kt-indicator');
                        $('.submit_btn').css('cursor', 'pointer');
                        if (errorStatus == 0) {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Internet Connection Problem',
                                timer: 3000,
                            })
                        } else {
                            if(errorStatus == 419){
                                location.reload();
                            }else{
                                Toast.fire({
                                    icon: 'warning',
                                    title: 'Try Again. Error Code ' + errorStatus,
                                    timer: 3000,
                                })
                            }
                        }
                    }
                });
            }else{
                $('.submit_btn').prop('disabled', false);
                $(".submit_btn").removeAttr('data-kt-indicator');
                $('.submit_btn').css('cursor', 'pointer');
            }
        });
    }

    function remove_overtime_salary(emp_id,date) {
        $('#modal-danger').modal('show');
        $('#emp_id').val(emp_id)
        $('#date').val(date)
       
    }

    $('.edit_btn').click(function() {
        $('#edit-overtime-salary').modal('show');
        var salary = $(this).attr('data-salary');
        var date = $(this).attr('data-date');
        var emp_id = $(this).attr('data-id');
        var extra_hours = $(this).attr('data-extra-hours');
        var amount_payable = $(this).attr('data-amount-payable');
        $('#employee_id').val(emp_id);
        $('#salary_amount').val(salary);
        $('#ovt_date').val(date);
        $('#extra_hours').val(extra_hours);
        $('#amount_payable').val(amount_payable);
        
    });
    
    var numberOfChildCheckBoxes  = $('.checked').length;
    $('.checked').on('change',function(){
       
        var checkedChildCheckBox = $('.checked:checked').length;
        console.log(checkedChildCheckBox+' '+numberOfChildCheckBoxes)

        if(checkedChildCheckBox <= 0){
           $('.on-check').addClass('d-none');
        }else{
            $('.on-check').removeClass('d-none');
        }
        if(checkedChildCheckBox == numberOfChildCheckBoxes){
           
            $('#parent_checkbox').prop('checked', true)
        }
        else{
           
            $('#parent_checkbox').prop('checked', false);
        }
       
   });

   
    $('#parent_checkbox').on('change',function () {
        
        var checkedParentCheckBox = $('#parent_checkbox:checked').length;
        
        if(checkedParentCheckBox >=1){
           $('.checked').prop('checked', true)
           $('.on-check').removeClass('d-none');
           
        }else{
          
            $('#parent_checkbox').prop('checked', false);
            $('.checked').prop('checked', false);
            $('.on-check').addClass('d-none');
        }

      
    });

    $('.overtime_reibursment').on('click', function(e) {
        
        var title = $(this).attr('data-value');
        $('#title').val(title);

        swal.fire({
            title: 'Confirmation Alert !',
            text: 'Are you sure to submit Overtime ?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText:'Yes',
            cancelButtonText:'Cancel',
        }).then(function (value) { 
         
            if (value.isConfirmed == true) {
                $.ajax({
                    url:'<?php echo e(url('overtime-management/multiple-overtime-record-insert-or-remove')); ?>',
                    type: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data:  $("#overtime-insert-form").serialize(),
                    success: function(data) {
                        if (data.status == 'TRUE') {
                            Toast.fire({
                                icon: 'success',
                                title: data.msg,
                                timer: 3000,
                            })
                            setTimeout(() => {
                                location.reload();
                            }, 3000);
                        }else {
                            Toast.fire({
                                icon: 'warning',
                                title: data.msg,
                                timer: 5000,
                            })
                            
                        }
                    },
                    error: function(jqXHR, textStatus) {
                        var errorStatus = jqXHR.status;
                        if (errorStatus == 0) {
                            Toast.fire({
                                icon: 'warning',
                                title: 'Internet Connection Problem',
                                timer: 3000,
                            })
                        } else {
                            if(errorStatus == 419){
                                location.reload();
                            }else{
                                Toast.fire({
                                    icon: 'warning',
                                    title: 'Try Again. Error Code ' + errorStatus,
                                    timer: 3000,
                                })
                            }
                        }
                    }
                });
            }else{
                $('.checked').prop('checked', false);
                $('#parent_checkbox').prop('checked', false);
                $('.on-check').addClass('d-none');
            }
        });
   
    });

    $('#removeReimburesement').submit(function(e) {
        e.preventDefault();
        $('#delete-btn').prop('disabled', true);
        $('#delete-btn').attr('data-kt-indicator', 'on');
        $('#delete-btn').css('cursor', 'not-allowed');
       
        $.ajax({
            url:'<?php echo e(url('overtime-management/delete-overtime-record-insert')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#delete-btn').prop('disabled', false);
                    $('#delete-btn').removeAttr('data-kt-indicator');
                    $('#delete-btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#delete-btn').prop('disabled', false);
                $('#delete-btn').removeAttr('data-kt-indicator');
                $('#delete-btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                    location.reload();
                }else{
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
                }
            }
        });
    });
    
    $('#edit_overtime_salary').submit(function(e) {
        $('#update-btn').prop('disabled', true);
        $('#update-btn').attr('data-kt-indicator', 'on');
        $('#update-btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('overtime-management/edit-overtime-record')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#update-btn').prop('disabled', false);
                    $('#update-btn').removeAttr('data-kt-indicator');
                    $('#update-btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#update-btn').prop('disabled', false);
                $('#update-btn').removeAttr('data-kt-indicator');
                $('#update-btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                    location.reload();
                }else{
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
                }
            }
        });
    });
    
        

</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/overtime-management/overtime-detail.blade.php ENDPATH**/ ?>