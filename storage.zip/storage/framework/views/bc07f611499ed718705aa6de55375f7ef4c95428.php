

<?php $__env->startPush('title'); ?> <?php echo e($title ?? 'Source Code'); ?> <?php $__env->stopPush(); ?>

<?php $__env->startPush('css-link'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
            
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Generate Pay Slip</h1>
                
                
                
                
            </div>
            
            
            <div class="d-flex align-items-center gap-2 gap-lg-3">
                
                
                
                
                
                
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary" >Go Back</a>
                
            </div>
            
        </div>
        
    </div>
    
    
    <div id="kt_app_content" class="app-content flex-column-fluid">
        
        <div id="kt_app_content_container" class="app-container container-xxl">
            
            <div class="card mb-5 mb-xl-8">
                
                
                <div class="card-header border-0 pt-5">
                    
                        <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bold fs-3 mb-1">Employee Details</span>
                        <span class="text-muted mt-1 fw-semibold fs-7"></span>
                    </h3>
                    
                    <div class="card-toolbar">
                        
                    </div>
                </div> 
                
                
                
                <div class="card-body py-3 ">
                    
                    <form  id="add_amployee_form" class="form" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        
                        
                        
                        

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required d-flex align-items-center fs-6 fw-semibold mb-2">Employee Name</label>
                                <select class="form-select form-select-solid" data-control="select2" data-hide-search="false" data-placeholder="Select a Employee Department" name="employee_department"
                                required="required" id="department_select">
                                    <option value="">Select Employee Department</option>
                                    <?php if(!empty($all_departments)): ?>
                                        <?php $__currentLoopData = $all_departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_department['department_name']); ?>"
                                                data-depart_id="<?php echo e($all_department['department_id']); ?>">
                                                <?php echo e($all_department['department_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                        
                                </select>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Name</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Designation</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno"/>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Employee Department</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Status</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Monthly Salary</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Bank Name</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Bank Account #</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Payroll Days</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Salary Month</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Salary Year</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        
                        <div class="card-header border-0 px-0">
                            
                                <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Details of Earning (Earnings)</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                        </div> 

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Basic Salary</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">House Rent</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Utility</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Fuel Reimbursement</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Mobile Reimbursement</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Medical Allowance</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">JD Based Allowance</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Bonus/Arrears Reimbursement</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-4 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Gross Salary</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="card-header border-0 px-0">
                            
                                <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Details of Earning (Deductions)</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                        </div>

                        <div class="row g-9 mb-8">
                            <div class="col-md-3 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Late Days</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Late Deduction Amount</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Gross Salary</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>

                            <div class="col-md-3 fv-row">
                                <label class="required fs-6 fw-semibold mb-2">Gross Salary</label>
                                <input type="text" class="form-control form-control-solid" name="employee_contactno" placeholder="Enter Contact No" required="required"/>
                            </div>
                        </div>

                        <div class="text-center">
                            
                            <button type="submit"class="btn btn-lg btn-success" id="submit_btn">
                                <span class="indicator-label">Add Employee</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span>
                                </span>
                            </button>
                        </div>
                        
                    </form>
                    
                </div>
                
            </div>
            
            
            
        </div>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){
		dataTable = $('#tableEmployee').DataTable();
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
        // $('[data-mask]').inputmask();
        $('#append_row_date').hide();
	});
    
    $('#activity_status').change(function(){
        var selectedOption = $(this).val();
        if(selectedOption == '1'){
            $('#append_row_date').hide("");
            $('#deactivate_date').removeAttr('required');
        }else{
            $('#append_row_date').show("");
            $('#deactivate_date').attr('required','required');
        }
    });

    $('#add_amployee_form').submit(function(e) {
        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('create_employee')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        window.location.href = "<?php echo e(url('employees')); ?>";
                    }, 3000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 8000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });

    $('#department_select').change(function(e) {
        e.preventDefault();
        var department = $(this).find(':selected').attr('data-depart_id');
        $('#designss').html('');
        $.ajax({
            url: '<?php echo e(url('get_desinations')); ?>/' + department,
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                department: department
            },
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#designss').append(data);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Try Again. Error Code ' + errorStatus,
                        timer: 3000,
                    })
                }
            }
        });
    });
 
</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/payslip/add-payslip.blade.php ENDPATH**/ ?>