

<?php $__env->startSection('main-section'); ?>
<div class="d-flex flex-column flex-column-fluid">
    
    <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
        
        <div class="app-container col-12 d-flex flex-stack">
            <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Edit Employee</h1>
            </div>

            <div class="d-flex align-items-center gap-2 gap-lg-3">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm fw-bold btn-primary"  >Go Back</a>
            </div>
        </div>
    </div>

    <div class="app-content flex-column-fluid">
        
        <div class="app-container">
            
            <div class="card mb-5 mb-xl-8">
                <div class="card-header border-0 pt-5">
                        <h3 class="card-title align-items-start flex-column">
                        <span class="card-label fw-bold fs-3 mb-1">Personal Detail</span>
                        <span class="text-muted mt-1 fw-semibold fs-7"></span>
                    </h3>
                    <div class="card-toolbar">
                        
                    </div>
                </div> 

                <div class="card-body py-3">
                    <form  id="edit_employee_form" class="form" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <div class="row g-9 mb-8">
                            <div class="col-md-12 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee Code</span>
                                </label>
                                <input type="text" class="form-control" placeholder="Enter Employee Code" name="employee_code" required  value="<?php echo e($employee_detail[0]['employee_code']); ?>">
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee Name</span>
                                </label>
                                <input type="text" class="form-control " placeholder="Enter Employee Name" name="employee_name" required  value="<?php echo e($employee_detail[0]['employee_name']); ?>">
                                <input type="hidden" class="form-control" name="employee_id"
                                    placeholder="Enter Employee Name" required="required"
                                    value="<?php echo e($employee_detail[0]['employee_id']); ?>">
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee Contact No <span>
                                </label>
                                <input type="number" class="form-control " name="employee_contact_no" placeholder="Enter Contact No" required="required" value="<?php echo e($employee_detail[0]['employee_contactno']); ?>"/>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee Email </span>
                                </label>
                                <input type="email" class="form-control " name="employee_email"
                                placeholder="Enter Employee Email" required="required"  value="<?php echo e($employee_detail[0]['employee_email']); ?>"/>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee NIC No </span>
                                </label>
                                <input type="text" class="form-control" name="employee_cnic" placeholder="Enter NIC No" required="required" value="<?php echo e($employee_detail[0]['employee_cnic']); ?>" />
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Employee Gender<span>
                                </label>
                                
                                <select class="form-select" data-control="select2" data-hide-search="false" data-placeholder="Select Employee Gender" name="employee_gender" required="required">
                                    <option value="">Select Employee Gender</option>
                                    <option value="Male" <?php if(!empty($employee_detail[0]['employee_gender']) && $employee_detail[0]['employee_gender'] == 'Male'): ?> selected <?php endif; ?>>Male</option>
                                    <option value="Female" <?php if(!empty($employee_detail[0]['employee_gender']) && $employee_detail[0]['employee_gender'] == 'Female'): ?> selected <?php endif; ?>>Female</option>    
                                </select>
                            </div>
                            
                        </div>

                        <div class="card-header border-0 px-0">
                            <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Company Details</span>
                            </h3>
                        </div>  
                        
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employee Department</label>
                                <select class="form-select" data-control="select2" data-hide-search="false" name="employee_department" required="required" id="department_select">
                                    <?php if(!empty($all_departments)): ?>
                                        <?php $__currentLoopData = $all_departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_department['department_id']); ?>" data-depart_id="<?php echo e($all_department['department_id']); ?>" <?php if($employee_detail[0]['employee_department'] == $all_department['department_id']): ?> selected <?php endif; ?>><?php echo e($all_department['department_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                               
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employee Designation</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" name="employee_designation"
                                id="designss" required>
                                <?php if(!empty($employee_designation_detail)): ?>
                                    <?php $__currentLoopData = $employee_designation_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($designation['designation_id']); ?>"
                                        <?php if($employee_detail[0]['employee_designation'] == $designation['designation_id'] ): ?> selected <?php endif; ?>>
                                        <?php echo e($designation['designation_name']); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>                                                      
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Job Title </span>                                                        
                                </label>
                                
                                <input type="text" class="form-control " placeholder="Enter Job Title"
                                required name="employee_jobtitle"  value="<?php echo e($employee_detail[0]['employee_jobtitle']); ?>"/>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Mark As Manager / Team Lead </span>                                                        
                                </label>
                                
                                <div class="d-flex align-items-center">
                                    
                                    <label class="form-check form-check-custom me-10">
                                        <input class="form-check-input h-20px w-20px" type="radio" id="customRadio5" name="make_ra" required="" value="1"  <?php if($employee_detail[0]['employee_can_ra'] == 1): ?> checked <?php endif; ?> />
                                        <span class="form-check-label fw-semibold">Yes, Employee's can report to him</span>
                                    </label>
                                    
                                    
                                    
                                    <label class="form-check form-check-custom">
                                        <input class="form-check-input h-20px w-20px" type="radio" id="customRadio6" name="make_ra" value="0"  <?php if($employee_detail[0]['employee_can_ra'] == 0): ?> checked <?php endif; ?> />
                                        <span class="form-check-label fw-semibold">No, Employee's can't report to him</span>
                                    </label>
                                    
                                </div>
                              
                            </div>
                            
                        </div>


                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employee's Senior Manager</label>
                                <select class="form-select " data-control="select2" data-hide-search="false" name="employee_reporting_person"
                                 required="required">
                                <option value="">Select Senior Manager </option>
                                <?php if(!empty($reporting_managers)): ?>
                                    <?php $__currentLoopData = $reporting_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporting_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!in_array($reporting_manager['employee_id'],$total_team_member)): ?>
                                            <option value="<?php echo e($reporting_manager['employee_id']); ?>"
                                                <?php if($employee_detail[0]['employee_ra'] == $reporting_manager['employee_id']): ?> selected <?php endif; ?>>
                                                <?php echo e($reporting_manager['employee_name']); ?>

                                                (<?php echo e($reporting_manager['department_name']); ?> -
                                                <?php echo e($reporting_manager['designation_name']); ?>)
                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>                                     
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2">Employee's Junior Manager</label>
                                <select class="form-select " data-control="select2" data-hide-search="false"  name="employee_reporting_person2">
                                    <option value="">Select Junior Manager </option>
                                    <?php if(!empty($reporting_managers)): ?>
                                        <?php $__currentLoopData = $reporting_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporting_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(!in_array($reporting_manager['employee_id'],$total_team_member)): ?>
                                                <option value="<?php echo e($reporting_manager['employee_id']); ?>"
                                                    <?php if($employee_detail[0]['employee_ra2'] == $reporting_manager['employee_id']): ?> selected <?php endif; ?>>
                                                    <?php echo e($reporting_manager['employee_name']); ?>

                                                    (<?php echo e($reporting_manager['department_name']); ?> -
                                                    <?php echo e($reporting_manager['designation_name']); ?>)
                                                </option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                 
                                </select>
                            </div>
                            
                        </div>
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Joining Date </span>                                                        
                                </label>
                                
                                <input type="date" class="form-control " placeholder="mm/dd/yyyy" name="employee_doj"
                                required="required"  value="<?php echo e($employee_detail[0]['employee_doj']); ?>"/>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employment Status</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" name="employee_status"
                                required="required">

                                    <option value="Internee"
                                    <?php if($employee_detail[0]['employee_status'] == 'Internee'): ?> selected <?php endif; ?>>Internee</option>
                                    
                                    <option value="Probation"
                                    <?php if($employee_detail[0]['employee_status'] == 'Probation'): ?> selected <?php endif; ?>>Probation</option>
                                    
                                    <option value="Permanent"
                                        <?php if($employee_detail[0]['employee_status'] == 'Permanent'): ?> selected <?php endif; ?>>Permanent
                                    </option>     
                                    
                                    <option value="PartTime"
                                    <?php if($employee_detail[0]['employee_status'] == 'PartTime'): ?> selected <?php endif; ?>>Part Time</option>
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-lg-4 col-md-4 col-sm-4 col-8">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Salary </span>                                                        
                                </label>
                                
                                <input type="number" class="form-control " name="employee_salary"
                                placeholder="Enter Employee Salary" required="required"  value="<?php echo e($employee_salary[0]['salary_amount'] ?? ''); ?>" readonly/>
                            </div>
                            <div class="col-lg-1 col-md-1 col-2 " style="margin-top: 60px;">
                                <a href="javascript:void(0)" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="modal" data-bs-target="#view-employee-salary-detail">	
                               
                                    <i class="fas fa-eye"  data-bs-toggle="tooltip" title="View Employee Salary"></i>
                                                                
                                </a>
                               
                            </div>
                            <div class="col-lg-1 col-md-1 col-2 " style="margin-top: 60px;">
                                <a href="javascript:void(0)" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" data-bs-toggle="modal" data-bs-target="#edit-employee-salary">
                                    <span class="svg-icon svg-icon-3" data-bs-toggle="tooltip" title="Edit Employee Salary">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="currentColor"></path>
                                            <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="currentColor"></path>
                                        </svg>
                                    </span>
                                </a>
                            </div>
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2 required">Employee Earning Type</label>
                                <select class="form-select " data-control="select2" data-hide-search="false"   name="earning_type">
                                    <option value="">Select Employee Earning Type</option>
                                    <option value="1" <?php if($employee_detail[0]['employee_earning_type'] == 1): ?> selected <?php endif; ?>>Monthly</option>
                                    <option value="2" <?php if($employee_detail[0]['employee_earning_type'] == 2): ?> selected <?php endif; ?>>Daily Wages</option>                                                                                                                                         
                                   
                                </select>
                            </div>

                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employee Job Type</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" name="employee_jobtype"
                                required="required">
                                    <option value="">Select Job Type</option>
                                    <option value="Office"
                                         <?php if($employee_detail[0]['employee_jobtype'] == 'Office'): ?> selected <?php endif; ?>>Office base
                                    </option>
                                    <option value="Home"
                                        <?php if($employee_detail[0]['employee_jobtype'] == 'Home'): ?> selected <?php endif; ?>>Home base
                                    </option>
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="required fs-6 fw-semibold mb-2">Employee Activity Status</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" name="employee_isactive"
                                required="required" id="activity_status">
                                <option value="">Select Activity Status</option>
                                <option value="1" <?php if($employee_detail[0]['employee_isactive'] == 1): ?> selected <?php endif; ?>>Active</option>
                                <option value="0" <?php if($employee_detail[0]['employee_isactive'] == 0): ?> selected <?php endif; ?>>De-Active</option>                                                                                                                                         
                                </select>
                            </div>

                        </div>

                        <div class="row g-9 mb-8">

                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span class="required">Employee Password </span>                                                        
                                </label>
                                
                                <input type="text" class="form-control "  name="employee_password"
                                placeholder="Enter Employee Password" required="required"  value="<?php echo e(Crypt::decryptString($employee_detail[0]['employee_password'])); ?>" />
                            </div>
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2">Employee Location</label>
                                <select class="form-select" data-control="select2" data-hide-search="true" name="employee_location">
                                    <option value="">Select Employee Location</option>
                                    <?php if(!empty($all_locations)): ?>
                                        <?php $__currentLoopData = $all_locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($location['location_title']); ?>"
                                                <?php if($employee_detail[0]['employee_location'] == $location['location_title']): ?> selected <?php endif; ?>>
                                                <?php echo e($location['location_title']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                          
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8" id="append_row_date">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="fs-6 fw-semibold mb-2">Employee Deactivation Date <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control " name="employee_deactivate_date" id="deactivate_date" required="required" value="<?php echo e($employee_detail[0]['employee_deactivate_date']); ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="card-header border-0 px-0">
                            
                                <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Office Shift Timing</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                            
                            <div class="card-toolbar">
                                
                            </div>
                        </div> 
                      
                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <div class="d-flex align-items-center">
                                    <label class="form-check form-check-custom me-10">
                                        <input class="form-check-input h-20px w-20px" type="checkbox" id="checkboxPrimary1"
                                        name="employee_shift_flexibilty" value="1" <?php if($employee_detail[0]['employee_shift_flexibilty'] == '1'): ?> checked="" <?php endif; ?> />
                                        <span class="form-check-label fw-semibold">Flexible Shift Timings</span>&nbsp; <i class="far fa-question-circle" data-toggle="tooltip" data-placement="right" data-title="If employee has given facility of flexible shift timings, employee can check-in at any time and has to complete their shift total hours. For e.g 8 hours or 9 hours or it can be any."></i>
                                    </label>
                                </div>
                            </div>
                            
                        </div>

                        <div class="card-header border-0 px-0">
                                <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Leave Entitlement & Off Days</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                            <div class="card-toolbar">
                                
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2 required">Employee Off Day 1</label>
                                <select class="form-select " data-control="select2" data-hide-search="true" name="offday1" required="required">
                                    <option value="">Select 1st Off Day</option>
                                    <option value="Monday" <?php if($employee_detail[0]['employee_offday1'] == 'Monday'): ?> selected <?php endif; ?>>Monday</option>
                                    <option value="Tuesday" <?php if($employee_detail[0]['employee_offday1'] == 'Tuesday'): ?> selected <?php endif; ?>>Tuesday</option>
                                    <option value="Wednesday" <?php if($employee_detail[0]['employee_offday1'] == 'Wednesday'): ?> selected <?php endif; ?>>Wednesday
                                    </option>
                                    <option value="Thursday" <?php if($employee_detail[0]['employee_offday1'] == 'Thursday'): ?> selected <?php endif; ?>>Thursday
                                    </option>
                                    <option value="Friday" <?php if($employee_detail[0]['employee_offday1'] == 'Friday'): ?> selected <?php endif; ?>>Friday</option>
                                    <option value="Saturday" <?php if($employee_detail[0]['employee_offday1'] == 'Saturday'): ?> selected <?php endif; ?>>Saturday
                                    </option>
                                    <option value="Sunday" <?php if($employee_detail[0]['employee_offday1'] == 'Sunday'): ?> selected <?php endif; ?>>Sunday</option>                                                       
                                </select>
                            </div>
                            
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2">Employee Off Day 2</label>
                                <select class="form-select " data-control="select2" data-hide-search="true"  name="offday2">
                                    <option value="">Select 2nd Off Day</option>
                                    <option value="Sunday"
                                    <?php if($employee_detail[0]['employee_offday2'] == 'Sunday'): ?> selected <?php endif; ?>>Sunday</option>
                                    <option value="Saturday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Saturday'): ?> selected <?php endif; ?>>Saturday
                                    </option>
                                    <option value="Friday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Friday'): ?> selected <?php endif; ?>>Friday</option>
                                    <option value="Thursday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Thursday'): ?> selected <?php endif; ?>>Thursday
                                    </option>
                                    <option value="Wednesday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Wednesday'): ?> selected <?php endif; ?>>Wednesday
                                    </option>
                                    <option value="Tuesday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Tuesday'): ?> selected <?php endif; ?>>Tuesday</option>
                                    <option value="Monday"
                                        <?php if($employee_detail[0]['employee_offday2'] == 'Monday'): ?> selected <?php endif; ?>>Monday</option>                                                              
                                </select>
                            </div>
                            
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Casual Leaves </span>
                                </label>
                                <input type="number" class="form-control" max="50" placeholder="0" name="casual_leaves"  value="<?php echo e($employee_detail[0]['total_casual_leaves']); ?>"
                                placeholder="Enter Casual Leaves" required="required">
                                <input type="hidden" class="form-control" name="leave_id"
                                    value="<?php echo e($employee_detail[0]['leaves_id']); ?>"
                                    placeholder="Enter Casual Leaves" required="required">
                            </div>
                            
                            
                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Annual Leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="annual_leaves" value="<?php echo e($employee_detail[0]['total_annual_leaves']); ?>"
                                placeholder="Enter Annual Leaves" required="required"/>
                            </div>
                            
                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Sick Leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="sick_leaves" value="<?php echo e($employee_detail[0]['total_sick_leaves']); ?>"
                                placeholder="Enter Sick Leaves" required="required"/>
                            </div>

                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Maternity leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="maternity_leaves" value="<?php echo e($employee_detail[0]['total_maternity_leaves']); ?>"
                                placeholder="Enter Maternity Leaves" required="required"/>
                            </div>
                        </div>

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Paternity leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="paternity_leaves" value="<?php echo e($employee_detail[0]['total_paternity_leaves']); ?>"
                                placeholder="Enter Paternity Leaves" required="required"/>
                            </div>
                            
                            <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Bereavement leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="bereavement_leaves" value="<?php echo e($employee_detail[0]['total_bereavement_leaves']); ?>"
                                placeholder="Enter Bereavement leaves" required="required"/>
                            </div>

                              <div class="col-md-3 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                    <span class="required">Compensatory leaves</span>
                                </label>
                                
                                <input type="number" class="form-control" max="50" placeholder="0" name="compensatory_leaves" value="<?php echo e($employee_detail[0]['total_compensatory_leaves']); ?>"
                                placeholder="Enter Compensatory leaves" required="required"/>
                            </div>
                           
                        </div>


                        <div class="card-header border-0 px-0">
                                <h3 class="card-title align-items-start flex-column">
                                <span class="card-label fw-bold fs-3 mb-1">Bank Account Detail (Optional)</span>
                                <span class="text-muted mt-1 fw-semibold fs-7"></span>
                            </h3>
                            <div class="card-toolbar">
                                
                            </div>
                        </div> 

                        <div class="row g-9 mb-8">
                            
                            <div class="col-md-6 ">
                                <label class="fs-6 fw-semibold mb-2">Bank Name</label>
                                    <input type="hidden" class="form-control" name="information_id" value="<?php echo e($employee_bank[0]['information_id'] ?? 'N/A'); ?>"/>
                                <select class="form-select " data-control="select2" data-hide-search="true" name="bank_name">
                                    <option value="">Select Bank Name</option>
                                    <?php if(!empty($all_banks)): ?>
                                        <?php $__currentLoopData = $all_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($all_bank['bank_name']); ?>"
                                                <?php if($employee_bank[0]['bankname'] == $all_bank['bank_name']): ?> selected <?php endif; ?>>
                                                <?php echo e($all_bank['bank_name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>                                                          
                                </select>
                            </div>
                            
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span >Account Title</span>
                                </label>
                                
                                <input type="text" class="form-control " name="account_title" placeholder="Enter Account Title" value="<?php echo e($employee_bank[0]['accounttitle'] ?? 'N/A'); ?>"/>
                            </div>
                            
                        </div>


                        <div class="row g-9 mb-8">
                        
                            
                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span >Account No </span>                                                        
                                </label>
                                
                                <input type="text" class="form-control " name="account_number" placeholder="Enter Account No" value="<?php echo e($employee_bank[0]['accountno'] ?? 'N/A'); ?>" />
                            </div>

                            <div class="col-md-6 ">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span >Account IBAN </span>                                                       
                                </label>
                                
                                <input type="text" class="form-control " name="account_iban" placeholder="Enter Account IBAN" value="<?php echo e($employee_bank[0]['ibannumber'] ?? 'N/A'); ?>"/>
                            </div>
                            
                        </div>   

                        <div class="row g-9 mb-8">
                            <div class="col-md-6 fv-row">
                                <label class="d-flex align-items-center fs-6 fw-semibold mb-2">
                                <span>Bank Code</span>
                                </label>
                                
                                <input type="text" class="form-control " name="bank_code" placeholder="Enter Bank Code" value="<?php echo e($employee_bank[0]['bankcode'] ?? 'N/A'); ?>"/>
                            </div>
                        </div>   
                        <?php if(!empty($get_modules)): ?>
                           
                            <div class="row mb-8">
                               
                                <div class="col-md-12">
                                    
                                    <table class="table table-row-bordered">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Basic Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($module['module_type'] == '0'): ?>
                                                    
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom">
                                                                <input class="form-check-input" type="checkbox"  checked disabled>
                                                                <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>" value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                        
                                                    </tr>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </tbody>
                                    </table>

                                    <table class="table table-row-bordered mb-2">
                                        <thead>
                                            <tr class="fw-bold text-muted bg-light">
                                                <th class="ps-4">Other Modules</th>
                                                <th>Access Right</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $get_modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($module['module_type'] == '1'): ?>
                                                    <?php $checked = '';$disabled = ''; $class = ''; ?>
                                                    <?php if(in_array($module['module_url'],$get_permissions)): ?>
                                                        <?php $checked = 'checked'; ?>
                                                    <?php endif; ?>
                                                    
                                                    <?php if(in_array($module['module_url'],['/attendance','/attendance-requests','/employees-leaves','/wfh-requests','/all-salary-request','/resignations','/my-requisition','/all-loan-request','/shift-management','/employee-expense'])): ?>
                                                         <?php $class = 'checked'; ?>
                                                    <?php endif; ?>

                                                   
                                                    <?php if(in_array($module['module_url'],['/my-expense','/permissions'])): ?>
                                                        <?php $disabled = 'disabled'; ?>
                                                    <?php endif; ?>
                                                    <tr>
                                                        <td class="ps-4"><?php echo e($module['module_title']); ?></td>
                                                        <td>
                                                            <div class="form-check form-check-sm form-check-custom">
                                                                <input class="form-check-input <?php echo e($class); ?>"  type="checkbox"  value="1" <?php echo e($checked); ?>  name="permission_status_<?php echo e($key); ?>"  <?php if(!empty($disabled)): ?> checked disabled <?php endif; ?>>
                                                                <?php if(!empty($disabled)): ?>
                                                                    <input type="hidden" name="permission_status_<?php echo e($key); ?>" value="1">
                                                                <?php endif; ?>
                                                                <input type="hidden" name="module_url_<?php echo e($key); ?>"  value="<?php echo e($module['module_url']); ?>">
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <input type="hidden" name="total_count" value="<?php echo e(count($get_modules)); ?>">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        
                        <?php endif; ?>
                        <div class="text-center">
                            <button type="submit"class="btn btn-lg btn-success" id="submit_btn">
                                <span class="indicator-label">Update Employee</span>
                                <span class="indicator-progress">Please wait... 
                                <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                            </button>
                        </div>
                        
                    </form>
                    
                </div>
                
            </div>
            
            
            
        </div>
        

        
    </div>
   
    
    <div class="modal fade" id="view-employee-salary-detail" tabindex="-1" aria-hidden="true">
       
        <div class="modal-dialog modal-dialog-top mw-650px">
          
            <div class="modal-content rounded">
                
                <div class="modal-content rounded">
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Employee Salary Detail</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                        </button>
                    </div>
                </div>
              
                <div class="modal-body" style="overflow-y:scroll;overflow-x:hidden;max-height: 500px;">
                    <table class="table table-row-bordered me-5">
                        <thead>
                            <tr class="fw-bold text-muted bg-light">
                                <th class="ps-7">Employee Name</th>
                                <th >Salary</th>
                                <th >Effectecd Date</th>
                                <th >Modified Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($employee_salary_detail)): ?>
                                <?php $__currentLoopData = $employee_salary_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="ps-8"><?php echo e($salary['employee_name']); ?></td>
                                        <td><?php echo e($salary['salary_amount']); ?></td>
                                        <td><?php echo e($salary['salary_effected_date'] ?? 'N\A'); ?></td>
                                        <td><?php echo e($salary['salary_created_date'] ?? 'N\A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
              
            </div>
         
        </div>
       
    </div>
    

    
        
        <div class="modal fade" id="edit-employee-salary" tabindex="-1" aria-hidden="true">
            
            <div class="modal-dialog modal-dialog-top mw-650px">
                
                <div class="modal-content rounded">
                    
                    <div class="modal-content rounded">
                        
                        <div class="modal-header">
                          <h4 class="modal-title pl-4">Edit Employee Salary</h4>
                          <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                              <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                          </button>
                        </div>
                        
                    </div>
                    
                    
                    <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
                        
                        <form id="edit_employee_salary" class="form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" class="form-control" name="employee_id"
                                    required="required"
                                    value="<?php echo e($employee_detail[0]['employee_id']); ?>">
                            
                            <div class="col-md-12 mb-8 mt-3 ">
                                <label class="required fs-6 fw-semibold mb-2">Effected Date</label>
                                
                                <div class="position-relative d-flex align-items-center">
                                    
                                    
                                    <span class="svg-icon svg-icon-2 position-absolute mx-4">
                                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="currentColor" />
                                            <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="currentColor" />
                                            <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="currentColor" />
                                        </svg>
                                    </span>
                                    
                                    
                                    
                                    <input type="date" class="form-control  ps-12" placeholder="Select a date" name="effected_date"  required/>
                                    
                                </div>
                                
                            </div>
                            
                            
                            
                            <div class="d-flex flex-column mb-8">
                                <label class="fs-6 fw-semibold mb-2 required">Salary Amount</label>
                                <input type="number" class="form-control" min="0" name="salary_amount" placeholder="Enter Employee Salary" value="<?php echo e($employee_salary[0]['salary_amount'] ?? ''); ?>" required />
                            </div>
                            
                            
                            <div class="text-center">
                               
                                <button type="reset" class="btn btn-light me-3" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="submit_btn_salary" class="btn btn-primary">
                                    <span class="indicator-label">Submit</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                            
                        </form>
                        
                    </div>
                    
                </div>
                
            </div>
            
        </div>
          
        


        <div class="modal fade" id="check-employee-name" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog  modal-dialog-scrollable modal-dialog-top mw-950px">
                <div class="modal-content rounded">
                    <div class="modal-header">
                        <h4 class="modal-title pl-4">Employees Reporting</h4>
                        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary close_btn" data-bs-dismiss="modal" aria-label="Close">
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor"/>
                                </svg>
                            </span>
                        </button>
                    </div>
                    <div class="modal-body scroll-y pt-0 pb-15">
                        <form id="update_employee_can_ra" class="form">
                            <?php echo csrf_field(); ?>  
                            <input type="hidden" name="old_reporting_emp_id" id="old_reporting"/>
                            <input type="hidden" name="emp_deactivate_date" id="emp_deactivate_date"/>
                            <div class="card card-flush pt-3 mb-5 mb-lg-10" data-kt-subscriptions-form="pricing">
                                <div class="card-body pt-0">
                                    <div class="row pt-3 mb-4">
                                        <div id="employee-manager">

                                        </div>
                                    </div>
                                    <div id="kt_create_new_payment_method">
                                      
                                        <table class="table table-row-bordered">
                                            <thead>
                                                <tr class="fw-bold text-muted bg-light">
                                                    <th class="ps-7">Employee Name</th>
                                                    <th >Department</th>
                                                    <th >Designation</th>
                                                    <th >Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="employee-data">
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer justify-content-center">
                                <button type="reset" class="btn btn-light me-3 close_btn" data-bs-dismiss="modal">Close</button>
                                <button type="submit" id="employees_reporting_submit_btn" class="btn btn-success">
                                    <span class="indicator-label">Update</span>
                                    <span class="indicator-progress">Please wait... 
                                    <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                                </button>
                            </div>
                           
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startPush('js-link'); ?>
<script>
    $(function(){
		dataTable = $('#tableEmployee').DataTable();
		$('#searchFilter').keyup(function(){
			dataTable.search($(this).val()).draw();
		})
        $('[data-toggle="tooltip"]').tooltip();
        var Employee_status = '<?php echo e($employee_detail[0]['employee_isactive']); ?>';
        if(Employee_status == '1'){
            $('#append_row_date').addClass("d-none");
            $('#deactivate_date').removeAttr('required');
        }else{
            $('#append_row_date').removeClass("d-none");
            $('#deactivate_date').attr('required','required');
        }

       
	});

    $('#customRadio5').click(function(){
        reporting_authority_given =  $('#customRadio5').val();
        if(reporting_authority_given){
            $('.checked').prop('checked',true);
          
        }
    })
   
    $('#customRadio6').click(function(){
      
        reporting_authority_not_given =  $('#customRadio6').val();
      
        if(reporting_authority_not_given){
            $('.checked').prop('checked',false);
           
        }
       
    })

    

    $('#activity_status').change(function(){
        var selectedOption = $(this).val();
        if(selectedOption == '1'){
            $('#append_row_date').addClass("d-none");
            $('#deactivate_date').removeAttr('required');
        }else{
            $('#append_row_date').removeClass("d-none");
            $('#deactivate_date').attr('required','required');
        }
    });

    $('#edit_employee_form').submit(function(e) {
        var previous_url  = '<?php echo e(url()->previous()); ?>';
        previous_url = previous_url.replace("amp;",'');
        $('#submit_btn').prop('disabled', true);
        $("#submit_btn").attr('data-kt-indicator', 'on');
        $('#submit_btn').css('cursor', 'not-allowed');
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('employees/update_employee')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                response = JSON.parse(JSON.stringify(data));
                    console.log(response);
                if (response.status == 'TRUE') {

                    if(response.total_employee > 0){
                        employee_name_list();
                    
                        $('#emp_deactivate_date').val(response.deactivate_date)
                    }
                    else{
                        Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                        })
                        setTimeout(() => {
                            window.location.href = previous_url;
                        }, 3000);
                      
                    }
                   
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    $('#department_select').change(function(e) {
        e.preventDefault();
        var department = $(this).find(':selected').attr('data-depart_id');
        $('#designss').html('');
        $.ajax({
            url: '<?php echo e(url('employees/get_desinations')); ?>/' + department,
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: {
                department: department
            },
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                $('#designss').append(data);
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    $('#edit_employee_salary').submit(function(e) {
        $('#submit_btn_salary').prop('disabled', true);
        $("#submit_btn_salary").attr('data-kt-indicator', 'on');
        $('#submit_btn_salary').css('cursor', 'pointer');
        
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('employees/submit_edit_salary_request')); ?>',
            type: 'POST',
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
                console.log(data);
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 5000,
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 5000);
                } else {
                    Toast.fire({
                        icon: 'warning',
                        title: data.msg,
                        timer: 5000,
                    })
                    $('#submit_btn_salary').prop('disabled', false);
                    $('#submit_btn_salary').css('cursor', 'pointer');
                    $("#submit_btn_salary").removeAttr('data-kt-indicator');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn_salary').prop('disabled', false);
                $('#submit_btn_salary').css('cursor', 'pointer');
                $("#submit_btn_salary").removeAttr('data-kt-indicator');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

    function employee_name_list(){
        
        $.ajax({
            url: "<?php echo e(url('employees/check-employee-name-list')); ?>",
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data:$("#edit_employee_form").serialize(),
           
            success: function(data) {
                if (data.status == 'TRUE') {
                    $('#employee-data').html('');
                    $('#employee-manager').html('');
                    employee_record = data.reporting_employee;
                    employee_record_can_ra =  employee_can_ra(data.employee_can_ra);
                    employeeArray = [];
                    $.each(employee_record, function(key, employee) {
                        if(employee){
                            employeeArray.push(employee_reporting_authorties(key,employee));

                                $('#employee-data').html(employeeArray);
                                $('.employee_reporting_manager_select2').select2({
                                    dropdownParent: $('#check-employee-name')
                                });
                        }
                    });

                   $('#employee-manager').html(parent_employee_can_ra(data.employee_can_ra));
                    $('#parent_employee_reporting_manager').select2({
                        dropdownParent: $('#check-employee-name')
                    });
                    
                    $('#parent_employee_reporting_manager').change(function(){
                        var selectedOption = $(this).val();
                        $('.employee_reporting_manager_select2').val(selectedOption).change();
                    });

                    $('#old_reporting').val(data.old_reporting_manager);
                    
                    $('#check-employee-name').modal('show');
                   

                  
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                } else {
                   
                    $('#submit_btn').prop('disabled', false);
                    $("#submit_btn").removeAttr('data-kt-indicator');
                    $('#submit_btn').css('cursor', 'pointer');
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#submit_btn').prop('disabled', false);
                $("#submit_btn").removeAttr('data-kt-indicator');
                $('#submit_btn').css('cursor', 'pointer');
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    }

    function employee_reporting_authorties(key=Null,data=Null){
        var record = '';
        record +=`<tr>
                <td class="ps-7"><b>${data.employee_name}</b><input type="hidden" value="${data.employee_id}" name="employees[]" /></td>
                <td>${data.department_name}</td>
                <td>${data.designation_name}</td>
                <td>${employee_record_can_ra}</td>
               
            </tr>`;

        return record;
    }

    function parent_employee_can_ra(employee_record_can_ra){


        var can_ra = '';
        can_ra +=`<div class="col-md-12 ">
            <select class="form-select" data-control="select2" id="parent_employee_reporting_manager"  data-hide-search="true">
                <option value="">Select Reporting Manager</option>`;
                $.each(employee_record_can_ra, function(key, data) {
                can_ra +=`<option value="${data.employee_id}">${data.employee_code}-${data.employee_name} (${data.department_name}- ${data.designation_name})</option>`;
            });
                                                                    
                can_ra +=`</select>
        </div>`;

        return can_ra;
    }

    function employee_can_ra(employee_record_can_ra){


         var can_ra = '';
         can_ra +=`<div class="col-md-12 ">
             <select class="form-select employee_reporting_manager_select2" data-control="select2"  data-hide-search="true" name="employee_reporting_manager[]" required>
                 <option value="">Select Reporting Manager</option>`;
                 $.each(employee_record_can_ra, function(key, data) {
                    can_ra +=`<option value="${data.employee_id}">${data.employee_code}-${data.employee_name} (${data.department_name}- ${data.designation_name})</option>`;
                });
                                                                     
                 can_ra +=`</select>
         </div>`;
 
         return can_ra;
    }

    $('#update_employee_can_ra').submit(function(e) {
        $('#employees_reporting_submit_btn').prop('disabled', true);
        $("#employees_reporting_submit_btn").attr('data-kt-indicator', 'on');
        $('#employees_reporting_submit_btn').css('cursor', 'not-allowed');
      
        e.preventDefault();
        $.ajax({
            url: '<?php echo e(url('employees/update-employee-can-ra')); ?>',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data) {
               
                if (data.status == 'TRUE') {
                    Toast.fire({
                        icon: 'success',
                        title: data.msg,
                        timer: 3000,
                    })
                    setTimeout(() => {
                        window.location.href = "<?php echo e(url('employees')); ?>";
                    }, 3000);
                   

                } else {
           
                    $('#employees_reporting_submit_btn').prop('disabled', false);
                    $("#employees_reporting_submit_btn").removeAttr('data-kt-indicator');
                    $('#employees_reporting_submit_btn').css('cursor', 'pointer');
                  
                }
            },
            error: function(jqXHR, textStatus) {
                var errorStatus = jqXHR.status;
                $('#employees_reporting_submit_btn').prop('disabled', false);
                $("#employees_reporting_submit_btn").removeAttr('data-kt-indicator');
                $('#employees_reporting_submit_btn').css('cursor', 'pointer');
              
                if (errorStatus == 0) {
                    Toast.fire({
                        icon: 'warning',
                        title: 'Internet Connection Problem',
                        timer: 3000,
                    })
                } else {
                    if(errorStatus == 419){
                        location.reload();
                    }else{
                        Toast.fire({
                            icon: 'warning',
                            title: 'Try Again. Error Code ' + errorStatus,
                            timer: 3000,
                        })
                    }
                }
            }
        });
    });

   
    $('.close_btn').click(function(){
        $('#submit_btn').prop('disabled', false);
        $("#submit_btn").removeAttr('data-kt-indicator');
        $('#submit_btn').css('cursor', 'pointer');
    });
   



</script>


    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Source-Code-HRM-NEW-TEMP\resources\views/employee/edit-employee.blade.php ENDPATH**/ ?>